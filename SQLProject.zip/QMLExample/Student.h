#ifndef STUDENT_H
#define STUDENT_H

#include <QString>

class Student
{
    friend class StudentList;

private:

    int m_id;
    QString personSt;
    int numberBibl;
    int countBooks;
    bool isChanged;

public:
    Student(const int id);
    QString getPersonSt() const;
    int getNumberBibl() const;
    int getCountBooks() const;
    int getID() const;
    bool getIsChanged() const;
    void setPersonSt(const QString &St);
    void setNumberBibl(const int number);
    void setCountBooks(const int books);
   };

#endif // STUDENT_H
