#ifndef STUDENTLIST_H
#define STUDENTLIST_H

#include <QAbstractListModel>
#include <QVariant>
#include <QList>
#include <QModelIndex>
#include <QItemSelectionModel>
#include "Student.h"
#include "DbConnection.h"



class StudentList : public QAbstractListModel
{
    Q_OBJECT

    Q_PROPERTY(QAbstractListModel* studentModel READ getModel CONSTANT)  /* первый параметр - тип свойства (property)
                                                                     второй параметр - имя свойства, по которому будем обращаться к реальной модели в qml-файле
                                                                     третий параметр - метод С++ для получения значения свойства (получим саму модель)
                                                                     CONSTANT - qml получит свойство однократно, и в процессе работы это свойство изменяться не будет */
private:
    QList<Student> listOfStudents; // непосредственно данные
    QList<int> listOfDeletedId;  // список ID элементов, удаляемых из БД
    QAbstractListModel *getModel();
    DbConnection* m_connection;

public:
    StudentList(const QString& path, QObject *parent = nullptr);
    ~StudentList();

    // количество колонок
    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

     // возвращение данных модели по указанному индексу и роли
    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const override;

    enum ResentRoles {
            name = Qt::DisplayRole,
            number = Qt::UserRole + 1,
            count = Qt::UserRole + 2
       };

    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE void add(const QString& nameSt, const int numberSt, const int countSt, const int id = 0);  // макрос указывает, что к методу можно обратиться из QML
    Q_INVOKABLE void del(const int index);
    Q_INVOKABLE void edit(const QString& nameSt, const int numberSt, const int countSt, const int index);
    Q_INVOKABLE void saveAll();
};

#endif // STUDENTLIST_H
