#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include <QSqlDatabase>
#include <memory> // библиотека для работы с памятью
#include <QString>
#include <QSqlQuery>

class DbConnection
{
private:
   QSqlDatabase m_dbConnection;

public:
    DbConnection(const QString& dbFilePath, const QString& connectionName);
    std::shared_ptr<QSqlQuery> openTable(const QString& tableName);
    void close();
    bool save(const QString& sql);
    bool isValid() const;
    int getLastId() const;
};

#endif // DBCONNECTION_H
