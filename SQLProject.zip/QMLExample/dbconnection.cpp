#include "DbConnection.h"
#include <QStringList>
#include <QDebug>
#include <QSqlError>

DbConnection::DbConnection(const QString &dbFilePath, const QString &connectionName)
{
//   m_dbConnection = QSqlDatabase::addDatabase("QSQLITE", connectionName); //первый параметр - тип драйвера для соответствующей СУБД
//                                                                          // второй параметр - имя соединения, должно быть униккльным в пределах приложения
//   m_dbConnection.setDatabaseName(dbFilePath);
//   m_dbConnection.open();

    m_dbConnection = QSqlDatabase::addDatabase("QPSQL");
    m_dbConnection.setHostName("127.0.0.1");
    m_dbConnection.setDatabaseName("sergey_db");
    m_dbConnection.setUserName("postgres");
    m_dbConnection.setPassword("Varlonec2Veyder");
    m_dbConnection.open();

}

std::shared_ptr<QSqlQuery> DbConnection::openTable(const QString& tableName)
{
       if (isValid())
        {
            if (m_dbConnection.tables().contains(tableName))
            {
                auto result = std::make_shared<QSqlQuery>(m_dbConnection);  // в качестве параметров передается то,
                                                                            //что необходимо конструктору
                                                                            //для создания экземпляра указанного типа


                /* Выполнить запрос на выборку всех записей из таблицы tableName */

                if (result->exec(QString("select * from %1").arg(tableName)))
                {
                    return result;
                }
                else  // если запрос не выполнен
                {
                    qDebug()<<"Ошибка выполнения запроса: \"select * from "  << tableName << "\"";
                 }
            }
            else
            {
               qDebug()<<" Таблица " << tableName << " не найдена";
             }
        }
        return nullptr;
}

void DbConnection::close()
{
    if (m_dbConnection.isOpen())
        m_dbConnection.close();
}

/*  сохранение данных в БД  */
bool DbConnection::save(const QString& sql)
{
    QSqlQuery query(m_dbConnection);
        auto result = query.exec(sql);
        if (!result)
            qDebug()<<" Ошибка выполнения запроса: "<< sql << " "<<query.lastError();
        return result && m_dbConnection.commit();
}

 bool DbConnection::isValid() const
 {
     return m_dbConnection.isValid() && m_dbConnection.isOpen();
 }

 int DbConnection::getLastId() const
 {
     QString sqlForGetIndex("SELECT last_insert_rowid()");
     QSqlQuery query(m_dbConnection);
     return query.exec(sqlForGetIndex) && query.next() ? query.value(0).toInt() : 0;
 }
