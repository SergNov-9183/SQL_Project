#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <StudentList.h>
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    /* Модель для приложения:
       из каталога приложения взять файл Students.sqlite3  :
       QGuiApplication::applicationDirPath()+"/Students.sqlite3" - формируется путь к файлу БД */

    //StudentList viewModel(QGuiApplication::applicationDirPath()+"/Students.sqlite3");
    StudentList viewModel("d:/Documents/Qt/SQLiteTest/Students.sqlite3");

     QQmlApplicationEngine engine;  // движок для QML

    QQmlContext *context = engine.rootContext();    // получить корневой контекст модели
    context->setContextObject(&viewModel);          // установить в качестве корневой модели созданную модель для приложения
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}
