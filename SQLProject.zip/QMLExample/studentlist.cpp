#include "StudentList.h"
#include <QDebug>

StudentList::StudentList(const QString &path, QObject* parent):QAbstractListModel(parent)
{
  m_connection = new DbConnection(path, "myConnection");

   if (m_connection->isValid())
  {
      if (auto query = m_connection->openTable("students"))
      {
            qDebug()<<"База открыта";
            while (query->next())
            {
                auto fieldPerson = query->value("person");
                auto fieldNumber = query->value("number");
                auto fieldCount = query->value("count");
                auto fieldId = query->value("id");
                add(fieldPerson.toString(), fieldNumber.toInt(), fieldCount.toInt(), fieldId.toInt());

            }
      }
  }
}

StudentList::~StudentList()
{
  m_connection->close();
  delete m_connection;
}

int StudentList::rowCount(const QModelIndex&) const
{
    return listOfStudents.size();
}


QVariant StudentList::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= listOfStudents.size())
            return QVariant();
      {
        switch (role) {
                case name:
                    return QVariant(listOfStudents.at(index.row()).getPersonSt());
                case number:
                    return QVariant(listOfStudents.at(index.row()).getNumberBibl());

                case count:
                    return QVariant(listOfStudents.at(index.row()).getCountBooks());

                default:
                    return QVariant();
            }

    }
      return QVariant();

}

QHash<int, QByteArray> StudentList::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[name] = "nameOfStudent";
    roles[number] = "numberOfStudent";
    roles[count] = "countOfBooksForStudent";
       return roles;
}

void StudentList::add(const QString& nameSt, const int numberSt, const int countSt, const int id){
     Student student(id);
     student.setPersonSt(nameSt);
     student.setNumberBibl(numberSt);
     student.setCountBooks(countSt);
     if (id > 0)
         student.isChanged = false;

     beginInsertRows(QModelIndex(),listOfStudents.size(),listOfStudents.size());
     listOfStudents.append(student);  //добавление в конец списка
     endInsertRows();

}

QAbstractListModel* StudentList::getModel(){
    return this;
}

void StudentList::del(const int index){

     if (index >= 0 && index < listOfStudents.size())
     {

    // сообщение модели о процессе удаления данных
    beginRemoveRows(QModelIndex(), index, index);

        if (listOfStudents.at(index).getID()>0)
           listOfDeletedId.append(listOfStudents.at(index).getID());

        listOfStudents.removeAt(index);
              endRemoveRows();
     }
     else qDebug() << "Error index";
}

void StudentList::edit(const QString& nameSt, const int numberSt, const int countSt, const int index) {
     if(index >= 0 && index < listOfStudents.size() )
     {
        auto& currentStudent = listOfStudents[index];
        if (currentStudent.getPersonSt().compare(nameSt)!=0 || currentStudent.getNumberBibl() != numberSt || currentStudent.getCountBooks() != countSt)
        {
            currentStudent.setPersonSt(nameSt);
            currentStudent.setNumberBibl(numberSt);
            currentStudent.setCountBooks(countSt);

            auto modelIndex = createIndex(index, 0);
            emit dataChanged(modelIndex, modelIndex);
            qDebug() << "Изменена запись с ID: " << listOfStudents[index].getID();
        }

     }
     else qDebug() << "Error index";
}

void StudentList::saveAll()
{
   /* Выполнить все удаления. Предварительно сформирован список id удаляемых элементов */
    QString sqlDelete("delete from Students where ID=%1");
    for (auto j: listOfDeletedId)
    {
        m_connection->save(sqlDelete.arg(j));
    }
    listOfDeletedId.clear();

    /* Выполнить вставку в таблицу БД всех вновь созданных (при вызове add()) и измененных (при вызове edit()) записей */
    QString sqlInsert("insert into Students (PERSON, NUMBER, COUNT) values ('%1', %2, %3)");
    QString sqlUpdate("update Students set PERSON='%1', NUMBER=%2, COUNT=%3 where id = %4");

    for(auto& student: listOfStudents)
    {

        if (student.getID()==0)  // если текущий элемент списка - вновь созданный, и в таблице БД отсутствует,
                                 // то необходимо его добавить в таблицу БД и получить его ID
        {
            m_connection->save(sqlInsert.arg(student.getPersonSt()).arg(student.getNumberBibl()).arg(student.getCountBooks()));
            auto newId = m_connection->getLastId();
            qDebug() << "Вставлена запись с ID: " << newId;
            student.m_id = newId; // можно обратиться непосредственно к закрытому полю класса Student,
                                                      // т.к. класс StudentList является дружественным для класса Student
        }
        else  // если текущий элемент списка уже присутствует в таблице БД,
              // то требуется его обновление в таблице БД
        {
            if (student.getIsChanged())
            {
                qDebug() << "Обновлена запись с ID: " << student.getID();
                m_connection->save(sqlUpdate.arg(student.getPersonSt()).arg(student.getNumberBibl()).arg(student.getCountBooks()).arg(student.getID()));
            }
        }
        student.isChanged = false;
    }
}
