#include "Student.h"

Student::Student(const int id) : m_id(id), personSt(""), numberBibl(0), countBooks(0), isChanged(false)
{

}

QString Student::getPersonSt() const
{
   return personSt;
}

int Student::getNumberBibl() const
{
   return numberBibl;
}

int Student::getCountBooks() const
{
    return countBooks;
}

int Student::getID() const
{
    return m_id;
}

bool Student::getIsChanged() const
{
   return isChanged;
}

void Student::setPersonSt(const QString &St)
{
   if ( personSt.compare(St)!=0 )
   {
     personSt = St;
     isChanged = true;
   }
}

void Student::setNumberBibl(const int number)
{
    if ( numberBibl !=number )
    {
      numberBibl = number;
      isChanged = true;
    }
}

void Student::setCountBooks(const int books)
{
     if ( countBooks != books )
     {
       countBooks = books;
       isChanged = true;
     }
}
