#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QDebug>
#include <QQuickView>
#include <QQmlContext>
#include <QSqlTableModel>
#include <QString>
#include <QDebug>

#include "customsqlmodel.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QQuickView view;

    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");
    db.setHostName("127.0.0.1");
    db.setDatabaseName("real_estate_app_database_v2");
    db.setUserName("postgres");
    db.setPassword("Varlonec2Veyder");
    qDebug() << (db.open() ? "connected" : "can not connect");

    CustomSqlModel *model = new CustomSqlModel();
    model->setQuery("select * from \"Houses\"");

    view.rootContext()->setContextProperty("lolmodel", model);
    view.setSource(QUrl(QStringLiteral("qrc:/main.qml")));
    view.show();

    //QSqlQuery query;

    return app.exec();
}
