#include "customsqlmodel.h"

#include <QSqlRecord>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>

CustomSqlModel::CustomSqlModel(QObject *parent) :
    QSqlQueryModel(parent)
{

}

void CustomSqlModel::setQuery(const QString &query, const QSqlDatabase &db)
{
    QSqlQueryModel::setQuery(query, db);
    generateRoleNames();
}

void CustomSqlModel::setQuery(const QSqlQuery & query)
{
    QSqlQueryModel::setQuery(query);
    generateRoleNames();
}

void CustomSqlModel::generateRoleNames()
{
    qDebug() << "generate data:" << lastError().text();
    m_roleNames.clear();
    for(int i = 0; i < record().count(); i ++) {
        qDebug() << i << " - " << record().fieldName(i);
        m_roleNames.insert(Qt::UserRole + i + 1, record().fieldName(i).toUtf8());
    }
}

QVariant CustomSqlModel::data(const QModelIndex &index, int role) const
{
    QVariant value;

    if(role < Qt::UserRole) {
        value = QSqlQueryModel::data(index, role);
    }
    else {
        int columnIdx = role - Qt::UserRole - 1;
        QModelIndex modelIndex = this->index(index.row(), columnIdx);
        value = QSqlQueryModel::data(modelIndex, Qt::DisplayRole);
    }
    return value;
}
