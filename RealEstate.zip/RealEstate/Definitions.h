#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include <QString>

// common
const QString QPSQL_DB_TYPE  = "QPSQL";
const QString SQLITE_DB_TYPE = "QSQLITE";
const QString FIELD_ID       = "id";
const QString FIELD_NEXTVAL  = "nextval";

const QString SQL_GET_ID = "select nextval('\"%1_ID_seq\"'::regclass)";

// SQLite generate id
const QString SQLITE_ID_GET = "select id from ids where table_name='%1'";
const QString SQLITE_ID_SET = "update ids set id=%1 where table_name='%2'";
const QString SQLITE_ID_FLD = "id";

// configuration file
const QString CONFIG_FILENAME           = "%1/RealEstate.config";
const QString CONFIG_SECTION            = "Configuration";
const QString CONFIG_DB_TYPE            = "DBType";
const QString CONFIG_IP                 = "IP";
const QString CONFIG_DATABASENAME       = "DatabaseName";
const QString CONFIG_CONNECTIONUSER     = "ConnectionUser";
const QString CONFIG_CONNECTIONPASSWORD = "ConnectionPassword";

// people
const QString TABLE_PEOPLE = "People";

const QString FIELD_PEOPLE_SURNAME     = "surname";
const QString FIELD_PEOPLE_NAME        = "name";
const QString FIELD_PEOPLE_PARTRONYMIC = "patronymic";
const QString FIELD_PEOPLE_PHONE       = "phone";
const QString FIELD_PEOPLE_EMAIL       = "email";
const QString FIELD_PEOPLE_PASSWORD    = "password";
const QString FIELD_ADMIN_ID           = "adminId";

const QString LOGGED_IN     = "Вход выполнен\nФамилия: %1\nИмя: %2\nОтчество: %3\nТелефон: %4\nE-Mail: %5";
const QString NOT_SIGNED_IN = "Не выполнен вход ";

const QString SQL_GET_USER = "select * from people where phone='%1'";
const QString SQL_ADD_USER = "insert into people (id, surname, name, patronymic, phone, email, password) values (%1, '%2', '%3', '%4', '%5', '%6', '%7')";
const QString SQL_MIN_USER = "select min(id) as adminId from people";

// settlements
const QString TABLE_LOCALITIES = "Settlement";

const QString FIELD_LOCALITY_TYPE = "type";
const QString FIELD_LOCALITY_NAME = "name";

const QString SQL_INSERT_LOCALITY   = "insert into settlements (id, type, name) values (%1, %2, '%3')";
const QString SQL_REMOVE_LOCALITY   = "delete from settlements where id=%1";
const QString SQL_SELECT_LOCALITIES = "select * from settlements";
const QString SQL_UPDATE_LOCALITY   = "update settlements set type=%1, name='%2' where id=%3";

const QByteArray ROLE_LOCALITY_TYPE = "localityType";
const QByteArray ROLE_LOCALITY_NAME = "localityName";

const int DATA_COUNT_LOCALITY      = 2;
const int DATA_INDEX_LOCALITY_TYPE = 0;
const int DATA_INDEX_LOCALITY_NAME = 1;

// streets
const QString TABLE_STREETS = "Streets";

const QString FIELD_STREET_SETTLEMENT_ID = "settlement_id";
const QString FIELD_STREET_NAME          = "name";

const QString SQL_INSERT_STREET  = "insert into streets (id, settlement_id, name) values (%1, %2, '%3')";
const QString SQL_REMOVE_STREET  = "delete from streets where id=%1";
const QString SQL_SELECT_STREETS = "select * from streets where settlement_id=%1";
const QString SQL_UPDATE_STREET  = "update streets set name='%1' where id=%2";

const QByteArray ROLE_STREET_SETTLEMENT_ID = "streetSettlementId";
const QByteArray ROLE_STREET_NAME          = "streetName";

const int DATA_COUNT_STREET               = 2;
const int DATA_INDEX_STREET_SETTLEMENT_ID = 0;
const int DATA_INDEX_STREET_NAME          = 1;

// houses
const QString TABLE_HOUSES = "Houses";

const QString FIELD_HOUSE_STREET_ID      = "street_id";
const QString FIELD_HOUSE_TYPE           = "type";
const QString FIELD_HOUSE_NUMBER         = "number";
const QString FIELD_HOUSE_HOUSING_NUMBER = "housing_number";
const QString FIELD_HOUSE_LAND_AREA      = "land_area";

const QString SQL_INSERT_HOUSE  = "insert into houses (id, street_id, type, number, housing_number, land_area) values (%1, %2, %3, '%4', '%5', %6)";
const QString SQL_REMOVE_HOUSE  = "delete from houses where id=%1";
const QString SQL_SELECT_HOUSES = "select * from houses where street_id=%1";
const QString SQL_UPDATE_HOUSE  = "update houses set type=%1, number='%2', housing_number='%3', land_area=%4 where id=%5";

const QByteArray ROLE_HOUSES_STREET_ID      = "houseSreetId";
const QByteArray ROLE_HOUSES_TYPE           = "houseType";
const QByteArray ROLE_HOUSES_NUMBER         = "houseNumber";
const QByteArray ROLE_HOUSES_HOUSING_NUMBER = "houseHousingNumber";
const QByteArray ROLE_HOUSES_LAND_AREA      = "houseLandArea";

const int DATA_COUNT_HOUSE                = 5;
const int DATA_INDEX_HOUSE_STREET_ID      = 0;
const int DATA_INDEX_HOUSE_TYPE           = 1;
const int DATA_INDEX_HOUSE_NUMBER         = 2;
const int DATA_INDEX_HOUSE_HOUSING_NUMBER = 3;
const int DATA_INDEX_HOUSE_LAND_AREA      = 4;

// announcement
const QString TABLE_ANNOUNCEMENTS = "Ads";

const QString FIELD_ANNOUNCEMENT_PEOPLE_ID                  = "people_id";
const QString FIELD_ANNOUNCEMENT_HOUSE_ID                   = "house_id";
const QString FIELD_ANNOUNCEMENT_SETTLEMENT_ID              = "settlement_id";
const QString FIELD_ANNOUNCEMENT_TYPE                       = "type";
const QString FIELD_ANNOUNCEMENT_ROOMS_COUNT                = "rooms_count";
const QString FIELD_ANNOUNCEMENT_TOTAL_AREA                 = "total_area";
const QString FIELD_ANNOUNCEMENT_LIVING_AREA                = "living_area";
const QString FIELD_ANNOUNCEMENT_KITCHEN_AREA               = "kitchen_area";
const QString FIELD_ANNOUNCEMENT_WATER_PIPES                = "water_pipes";
const QString FIELD_ANNOUNCEMENT_GAS                        = "gas";
const QString FIELD_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QString FIELD_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroom_type";
const QString FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "ads_text";
const QString FIELD_ANNOUNCEMENT_PRICE                      = "price";
const QString FIELD_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publication_or_update_time";
const QString FIELD_ANNOUNCEMENT_ADDITION_INFORMATION       = "addition_information";
const QString FIELD_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = "settlement_house_type";

const QString FIELD_ANNOUNCEMENT_PEOPLE_NAME          = "user_name";
const QString FIELD_ANNOUNCEMENT_PEOPLE_PHONE         = "phone";
const QString FIELD_ANNOUNCEMENT_PEOPLE_EMAIL         = "email";
const QString FIELD_ANNOUNCEMENT_HOUSE_TYPE           = "house_type";
const QString FIELD_ANNOUNCEMENT_HOUSE_NUMBER         = "number";
const QString FIELD_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = "housing_number";
const QString FIELD_ANNOUNCEMENT_HOUSE_LAND_AREA      = "land_area";
const QString FIELD_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = "settlements_type_buy";
const QString FIELD_ANNOUNCEMENT_LOCALITY_BUY_NAME    = "settlements_name_buy";
const QString FIELD_ANNOUNCEMENT_STREET_NAME          = "streets_name";
const QString FIELD_ANNOUNCEMENT_LOCALITY_TYPE        = "settlements_type";
const QString FIELD_ANNOUNCEMENT_LOCALITY_NAME        = "settlements_name";

const QString SQL_INSERT_ANNOUNCEMENT  = "insert into ads (id, people_id, house_id, settlement_id, type, rooms_count, total_area, living_area, \
       kitchen_area, water_pipes, gas, sewerage, bathroom_type, ads_text, price, publication_or_update_time, \
       addition_information, settlement_house_type) values (%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17', %18)";
const QString SQL_REMOVE_ANNOUNCEMENT  = "delete from ads where id=%1";
const QString SQL_SELECT_ANNOUNCEMENTS = "select A.*, \
       B.name as user_name, B.phone, B.email, \
       C.type as house_type, C.number, C.housing_number, C.land_area, \
       D.type as settlements_type_buy, D.name as settlements_name_buy, \
       E.name as streets_name, \
       F.type as settlements_type, F.name as settlements_name \
       from ads A \
       left join people B on B.id=A.people_id \
       left join houses C on C.id=A.house_id \
       left join settlements D on D.id=A.settlement_id \
       left join streets E on E.id=C.street_id \
       left join settlements F on F.id=E.settlement_id \
       where A.type=%1";
const QString SQL_UPDATE_ANNOUNCEMENT  = "update ads set house_id=%1, settlement_id=%2, rooms_count=%3, total_area=%4, living_area=%5, kitchen_area=%6, \
       water_pipes=%7, gas=%8, sewerage=%9, bathroom_type=%10, ads_text='%11', price=%12, publication_or_update_time='%13', addition_information='%14', settlement_house_type=%15 where id=%16";

const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_ID                  = "peopleId";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_ID                   = "houseId";
const QByteArray ROLE_ANNOUNCEMENT_SETTLEMENT_ID              = "settlementId";
const QByteArray ROLE_ANNOUNCEMENT_TYPE                       = "type";
const QByteArray ROLE_ANNOUNCEMENT_ROOMS_COUNT                = "roomsCount";
const QByteArray ROLE_ANNOUNCEMENT_TOTAL_AREA                 = "totalArea";
const QByteArray ROLE_ANNOUNCEMENT_LIVING_AREA                = "livingArea";
const QByteArray ROLE_ANNOUNCEMENT_KITCHEN_AREA               = "kitchenArea";
const QByteArray ROLE_ANNOUNCEMENT_WATER_PIPES                = "waterPipes";
const QByteArray ROLE_ANNOUNCEMENT_GAS                        = "gas";
const QByteArray ROLE_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QByteArray ROLE_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroomType";
const QByteArray ROLE_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "announcementText";
const QByteArray ROLE_ANNOUNCEMENT_PRICE                      = "price";
const QByteArray ROLE_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publicationOrUpdateTime";
const QByteArray ROLE_ANNOUNCEMENT_ADDITION_INFORMATION       = "additionInformation";
const QByteArray ROLE_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = "settlementHouseType";

const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_NAME          = "userName";
const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_PHONE         = "phone";
const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_EMAIL         = "email";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_TYPE           = "houseType";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_NUMBER         = "number";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = "housingNumber";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_LAND_AREA      = "landArea";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = "settlementsTypeBuy";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_BUY_NAME    = "settlementsNameBuy";
const QByteArray ROLE_ANNOUNCEMENT_STREET_NAME          = "streetsName";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_TYPE        = "settlementsType";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_NAME        = "settlementsName";

const int DATA_COUNT_ANNOUNCEMENT                            = 29;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID                  = 0;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_ID                   = 1;
const int DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID              = 2;
const int DATA_INDEX_ANNOUNCEMENT_TYPE                       = 3;
const int DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT                = 4;
const int DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA                 = 5;
const int DATA_INDEX_ANNOUNCEMENT_LIVING_AREA                = 6;
const int DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA               = 7;
const int DATA_INDEX_ANNOUNCEMENT_WATER_PIPES                = 8;
const int DATA_INDEX_ANNOUNCEMENT_GAS                        = 9;
const int DATA_INDEX_ANNOUNCEMENT_SEWERAGE                   = 10;
const int DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE              = 11;
const int DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = 12;
const int DATA_INDEX_ANNOUNCEMENT_PRICE                      = 13;
const int DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = 14;
const int DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION       = 15;
const int DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = 16;

const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_NAME          = 17;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_PHONE         = 18;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_EMAIL         = 19;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_TYPE           = 20;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_NUMBER         = 21;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = 22;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_LAND_AREA      = 23;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = 24;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_NAME    = 25;
const int DATA_INDEX_ANNOUNCEMENT_STREET_NAME          = 26;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_TYPE        = 27;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_NAME        = 28;

const QString SQL_ADS_GET_HOUSE_INFO = "select H.type, H.number, H.housing_number, H.land_area, \
       S.name as street_name, L.name as settlements_name, L.type as settlements_type from houses H \
       left join streets S on S.id=H.street_id \
       left join settlements L on L.id=S.settlement_id where H.id=%1";
const QString FIELD_ADS_GET_HOUSE_INFO_TYPE           = "type";
const QString FIELD_ADS_GET_HOUSE_INFO_NUMBER         = "number";
const QString FIELD_ADS_GET_HOUSE_INFO_HOUSING_NUMBER = "housing_number";
const QString FIELD_ADS_GET_HOUSE_INFO_LAND_AREA      = "land_area";
const QString FIELD_ADS_GET_HOUSE_STREET_NAME         = "street_name";
const QString FIELD_ADS_GET_HOUSE_LOCALITY_NAME       = "settlements_name";
const QString FIELD_ADS_GET_HOUSE_LOCALITY_TYPE       = "settlements_type";

const QString SQL_ADS_GET_LOCALITY_INFO = "select * from settlements where id=%1";

const QString FIELD_ADS_GET_LOCALITY_LOCALITY_TYPE = "type";
const QString FIELD_ADS_GET_LOCALITY_LOCALITY_NAME = "name";


#endif // DEFINITIONS_H
