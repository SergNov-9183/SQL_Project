#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include <QString>

const QString QUERY_NOT_DEFINED = "Query isn't defined";

// common
const QString FIELD_ID       = "id";

// configuration file
const QString CONFIG_FILENAME           = "%1/RealEstate.config";
const QString CONFIG_SECTION            = "Configuration";
const QString CONFIG_DB_TYPE            = "DBType";
const QString CONFIG_IP                 = "IP";
const QString CONFIG_DATABASENAME       = "DatabaseName";
const QString CONFIG_CONNECTIONUSER     = "ConnectionUser";
const QString CONFIG_CONNECTIONPASSWORD = "ConnectionPassword";

// people
const QString TABLE_PEOPLE = "people";

const QString FIELD_PEOPLE_SURNAME     = "surname";
const QString FIELD_PEOPLE_NAME        = "name";
const QString FIELD_PEOPLE_PARTRONYMIC = "patronymic";
const QString FIELD_PEOPLE_PHONE       = "phone";
const QString FIELD_PEOPLE_EMAIL       = "email";
const QString FIELD_PEOPLE_PASSWORD    = "password";
const QString FIELD_ADMIN_ID           = "adminId";

const QString LOGGED_IN     = "Вход выполнен\nФамилия: %1\nИмя: %2\nОтчество: %3\nТелефон: %4\nE-Mail: %5";
const QString NOT_SIGNED_IN = "Не выполнен вход ";

// settlements
const QString TABLE_LOCALITIES = "settlements";

const QString FIELD_LOCALITY_TYPE = "type";
const QString FIELD_LOCALITY_NAME = "name";

const QByteArray ROLE_LOCALITY_TYPE = "localityType";
const QByteArray ROLE_LOCALITY_NAME = "localityName";

const int DATA_COUNT_LOCALITY      = 2;
const int DATA_INDEX_LOCALITY_TYPE = 0;
const int DATA_INDEX_LOCALITY_NAME = 1;

// streets
const QString TABLE_STREETS = "streets";

const QString FIELD_STREET_SETTLEMENT_ID = "settlement_id";
const QString FIELD_STREET_NAME          = "name";

const QByteArray ROLE_STREET_SETTLEMENT_ID = "streetSettlementId";
const QByteArray ROLE_STREET_NAME          = "streetName";

const int DATA_COUNT_STREET               = 2;
const int DATA_INDEX_STREET_SETTLEMENT_ID = 0;
const int DATA_INDEX_STREET_NAME          = 1;

// houses
const QString TABLE_HOUSES = "houses";

const QString FIELD_HOUSE_STREET_ID      = "street_id";
const QString FIELD_HOUSE_TYPE           = "type";
const QString FIELD_HOUSE_NUMBER         = "number";
const QString FIELD_HOUSE_HOUSING_NUMBER = "housing_number";
const QString FIELD_HOUSE_LAND_AREA      = "land_area";

const QByteArray ROLE_HOUSES_STREET_ID      = "houseSreetId";
const QByteArray ROLE_HOUSES_TYPE           = "houseType";
const QByteArray ROLE_HOUSES_NUMBER         = "houseNumber";
const QByteArray ROLE_HOUSES_HOUSING_NUMBER = "houseHousingNumber";
const QByteArray ROLE_HOUSES_LAND_AREA      = "houseLandArea";

const int DATA_COUNT_HOUSE                = 5;
const int DATA_INDEX_HOUSE_STREET_ID      = 0;
const int DATA_INDEX_HOUSE_TYPE           = 1;
const int DATA_INDEX_HOUSE_NUMBER         = 2;
const int DATA_INDEX_HOUSE_HOUSING_NUMBER = 3;
const int DATA_INDEX_HOUSE_LAND_AREA      = 4;

// announcement
const QString TABLE_ANNOUNCEMENTS = "ads";

const QString FIELD_ANNOUNCEMENT_PEOPLE_ID                  = "people_id";
const QString FIELD_ANNOUNCEMENT_HOUSE_ID                   = "house_id";
const QString FIELD_ANNOUNCEMENT_SETTLEMENT_ID              = "settlement_id";
const QString FIELD_ANNOUNCEMENT_TYPE                       = "type";
const QString FIELD_ANNOUNCEMENT_ROOMS_COUNT                = "rooms_count";
const QString FIELD_ANNOUNCEMENT_TOTAL_AREA                 = "total_area";
const QString FIELD_ANNOUNCEMENT_LIVING_AREA                = "living_area";
const QString FIELD_ANNOUNCEMENT_KITCHEN_AREA               = "kitchen_area";
const QString FIELD_ANNOUNCEMENT_WATER_PIPES                = "water_pipes";
const QString FIELD_ANNOUNCEMENT_GAS                        = "gas";
const QString FIELD_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QString FIELD_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroom_type";
const QString FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "ads_text";
const QString FIELD_ANNOUNCEMENT_PRICE                      = "price";
const QString FIELD_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publication_or_update_time";
const QString FIELD_ANNOUNCEMENT_ADDITION_INFORMATION       = "addition_information";
const QString FIELD_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = "settlement_house_type";
const QString FIELD_ANNOUNCEMENT_PRICE_PER_SQ_M             = "price_per_sq_m";

const QString FIELD_ANNOUNCEMENT_PEOPLE_NAME          = "user_name";
const QString FIELD_ANNOUNCEMENT_PEOPLE_PHONE         = "phone";
const QString FIELD_ANNOUNCEMENT_PEOPLE_EMAIL         = "email";
const QString FIELD_ANNOUNCEMENT_HOUSE_TYPE           = "house_type";
const QString FIELD_ANNOUNCEMENT_HOUSE_NUMBER         = "number";
const QString FIELD_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = "housing_number";
const QString FIELD_ANNOUNCEMENT_HOUSE_LAND_AREA      = "land_area";
const QString FIELD_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = "settlements_type_buy";
const QString FIELD_ANNOUNCEMENT_LOCALITY_BUY_NAME    = "settlements_name_buy";
const QString FIELD_ANNOUNCEMENT_STREET_NAME          = "streets_name";
const QString FIELD_ANNOUNCEMENT_LOCALITY_TYPE        = "settlements_type";
const QString FIELD_ANNOUNCEMENT_LOCALITY_NAME        = "settlements_name";

const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_ID                  = "peopleId";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_ID                   = "houseId";
const QByteArray ROLE_ANNOUNCEMENT_SETTLEMENT_ID              = "settlementId";
const QByteArray ROLE_ANNOUNCEMENT_TYPE                       = "type";
const QByteArray ROLE_ANNOUNCEMENT_ROOMS_COUNT                = "roomsCount";
const QByteArray ROLE_ANNOUNCEMENT_TOTAL_AREA                 = "totalArea";
const QByteArray ROLE_ANNOUNCEMENT_LIVING_AREA                = "livingArea";
const QByteArray ROLE_ANNOUNCEMENT_KITCHEN_AREA               = "kitchenArea";
const QByteArray ROLE_ANNOUNCEMENT_WATER_PIPES                = "waterPipes";
const QByteArray ROLE_ANNOUNCEMENT_GAS                        = "gas";
const QByteArray ROLE_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QByteArray ROLE_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroomType";
const QByteArray ROLE_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "announcementText";
const QByteArray ROLE_ANNOUNCEMENT_PRICE                      = "price";
const QByteArray ROLE_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publicationOrUpdateTime";
const QByteArray ROLE_ANNOUNCEMENT_ADDITION_INFORMATION       = "additionInformation";
const QByteArray ROLE_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = "settlementHouseType";
const QByteArray ROLE_ANNOUNCEMENT_PRICE_PER_SQ_M             = "pricePerSqM";

const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_NAME          = "userName";
const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_PHONE         = "phone";
const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_EMAIL         = "email";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_TYPE           = "houseType";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_NUMBER         = "number";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = "housingNumber";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_LAND_AREA      = "landArea";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = "settlementsTypeBuy";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_BUY_NAME    = "settlementsNameBuy";
const QByteArray ROLE_ANNOUNCEMENT_STREET_NAME          = "streetsName";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_TYPE        = "settlementsType";
const QByteArray ROLE_ANNOUNCEMENT_LOCALITY_NAME        = "settlementsName";

const int DATA_COUNT_ANNOUNCEMENT                            = 30;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID                  = 0;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_ID                   = 1;
const int DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID              = 2;
const int DATA_INDEX_ANNOUNCEMENT_TYPE                       = 3;
const int DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT                = 4;
const int DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA                 = 5;
const int DATA_INDEX_ANNOUNCEMENT_LIVING_AREA                = 6;
const int DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA               = 7;
const int DATA_INDEX_ANNOUNCEMENT_WATER_PIPES                = 8;
const int DATA_INDEX_ANNOUNCEMENT_GAS                        = 9;
const int DATA_INDEX_ANNOUNCEMENT_SEWERAGE                   = 10;
const int DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE              = 11;
const int DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = 12;
const int DATA_INDEX_ANNOUNCEMENT_PRICE                      = 13;
const int DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = 14;
const int DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION       = 15;
const int DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE      = 16;

const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_NAME          = 17;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_PHONE         = 18;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_EMAIL         = 19;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_TYPE           = 20;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_NUMBER         = 21;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER = 22;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_LAND_AREA      = 23;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_TYPE    = 24;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_NAME    = 25;
const int DATA_INDEX_ANNOUNCEMENT_STREET_NAME          = 26;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_TYPE        = 27;
const int DATA_INDEX_ANNOUNCEMENT_LOCALITY_NAME        = 28;
const int DATA_INDEX_ANNOUNCEMENT_PRICE_PER_SQ_M       = 29;

// service commands
const QString FIELD_ADS_GET_HOUSE_INFO_TYPE           = "type";
const QString FIELD_ADS_GET_HOUSE_INFO_NUMBER         = "number";
const QString FIELD_ADS_GET_HOUSE_INFO_HOUSING_NUMBER = "housing_number";
const QString FIELD_ADS_GET_HOUSE_INFO_LAND_AREA      = "land_area";
const QString FIELD_ADS_GET_HOUSE_STREET_NAME         = "street_name";
const QString FIELD_ADS_GET_HOUSE_LOCALITY_NAME       = "settlements_name";
const QString FIELD_ADS_GET_HOUSE_LOCALITY_TYPE       = "settlements_type";

const QString FIELD_ADS_GET_LOCALITY_LOCALITY_TYPE = "type";
const QString FIELD_ADS_GET_LOCALITY_LOCALITY_NAME = "name";

#endif // DEFINITIONS_H
