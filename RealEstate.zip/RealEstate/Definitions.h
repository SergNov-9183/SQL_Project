#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include <QString>

// common
const QString QPSQL_DB_TYPE = "QPSQL";
const QString FIELD_ID      = "id";
const QString FIELD_NEXTVAL = "nextval";

const QString SQL_GET_ID = "select nextval('\"%1_ID_seq\"'::regclass)";

// configuration file
const QString CONFIG_FILENAME           = "%1/RealEstate.config";
const QString CONFIG_SECTION            = "Configuration";
const QString CONFIG_IP                 = "IP";
const QString CONFIG_DATABASENAME       = "DatabaseName";
const QString CONFIG_CONNECTIONUSER     = "ConnectionUser";
const QString CONFIG_CONNECTIONPASSWORD = "ConnectionPassword";



// people
const QString TABLE_PEOPLE = "People";

const QString FIELD_PEOPLE_SURNAME     = "surname";
const QString FIELD_PEOPLE_NAME        = "name";
const QString FIELD_PEOPLE_PARTRONYMIC = "patronymic";
const QString FIELD_PEOPLE_PHONE       = "phone";
const QString FIELD_PEOPLE_EMAIL       = "e-mail";
const QString FIELD_PEOPLE_PASSWORD    = "password";

const QString LOGGED_IN     = "Вход выполнен\nФамилия: %1\nИмя: %2\n Отчество: %3\nТелефон: %4\nE-Mail: %5";
const QString NOT_SIGNED_IN = "Не выполнен вход ";

const QString SQL_GET_USER = "select * from people where phone='%1'";
const QString SQL_ADD_USER = "insert into people (id, surname, name, patronymic, phone, \"e-mail\", password) values (%1, '%2', '%3', '%4', '%5', '%6', '%7')";

// settlements
const QString TABLE_LOCALITIES = "Settlement";

const QString FIELD_LOCALITY_TYPE = "type";
const QString FIELD_LOCALITY_NAME = "name";

const QString SQL_INSERT_LOCALITY   = "insert into settlements (id, type, name) values (%1, %2, '%3')";
const QString SQL_REMOVE_LOCALITY   = "delete from settlements where id=%1";
const QString SQL_SELECT_LOCALITIES = "select * from settlements";
const QString SQL_UPDATE_LOCALITY   = "update settlements set type=%1, name='%2' where id=%3";

const QByteArray ROLE_LOCALITY_TYPE = "localityType";
const QByteArray ROLE_LOCALITY_NAME = "localityName";

const int DATA_COUNT_LOCALITY      = 2;
const int DATA_INDEX_LOCALITY_TYPE = 0;
const int DATA_INDEX_LOCALITY_NAME = 1;

// streets
const QString TABLE_STREETS = "Streets";

const QString FIELD_STREET_SETTLEMENT_ID = "settlement_id";
const QString FIELD_STREET_NAME          = "name";

const QString SQL_INSERT_STREET  = "insert into streets (id, settlement_id, name) values (%1, %2, '%3')";
const QString SQL_REMOVE_STREET  = "delete from streets where id=%1";
const QString SQL_SELECT_STREETS = "select * from streets where settlement_id=%1";
const QString SQL_UPDATE_STREET  = "update streets set name='%1' where id=%2";

const QByteArray ROLE_STREET_SETTLEMENT_ID = "streetSettlementId";
const QByteArray ROLE_STREET_NAME          = "streetName";

const int DATA_COUNT_STREET               = 2;
const int DATA_INDEX_STREET_SETTLEMENT_ID = 0;
const int DATA_INDEX_STREET_NAME          = 1;

// houses
const QString TABLE_HOUSES = "Houses";

const QString FIELD_HOUSE_STREET_ID      = "street_id";
const QString FIELD_HOUSE_TYPE           = "type";
const QString FIELD_HOUSE_NUMBER         = "number";
const QString FIELD_HOUSE_HOUSING_NUMBER = "housing_number";
const QString FIELD_HOUSE_LAND_AREA      = "land_area";

const QString SQL_INSERT_HOUSE  = "insert into houses (id, street_id, type, number, housing_number, land_area) values (%1, %2, %3, '%4', '%5', %6)";
const QString SQL_REMOVE_HOUSE  = "delete from houses where id=%1";
const QString SQL_SELECT_HOUSES = "select * from houses where street_id=%1";
const QString SQL_UPDATE_HOUSE  = "update houses set type=%1, number='%2', housing_number='%3', land_area=%4 where id=%5";

const QByteArray ROLE_HOUSES_STREET_ID      = "houseSreetId";
const QByteArray ROLE_HOUSES_TYPE           = "houseType";
const QByteArray ROLE_HOUSES_NUMBER         = "houseNumber";
const QByteArray ROLE_HOUSES_HOUSING_NUMBER = "houseHousingNumber";
const QByteArray ROLE_HOUSES_LAND_AREA      = "houseLandArea";

const int DATA_COUNT_HOUSE                = 5;
const int DATA_INDEX_HOUSE_STREET_ID      = 0;
const int DATA_INDEX_HOUSE_TYPE           = 1;
const int DATA_INDEX_HOUSE_NUMBER         = 2;
const int DATA_INDEX_HOUSE_HOUSING_NUMBER = 3;
const int DATA_INDEX_HOUSE_LAND_AREA      = 4;

// announcement
const QString TABLE_ANNOUNCEMENTS = "Ads";

const QString FIELD_ANNOUNCEMENT_PEOPLE_ID                  = "people_id";
const QString FIELD_ANNOUNCEMENT_HOUSE_ID                   = "house_id";
const QString FIELD_ANNOUNCEMENT_SETTLEMENT_ID              = "settlement_id";
const QString FIELD_ANNOUNCEMENT_TYPE                       = "type";
const QString FIELD_ANNOUNCEMENT_ROOMS_COUNT                = "rooms_count";
const QString FIELD_ANNOUNCEMENT_TOTAL_AREA                 = "total_area";
const QString FIELD_ANNOUNCEMENT_LIVING_AREA                = "living_area";
const QString FIELD_ANNOUNCEMENT_KITCHEN_AREA               = "kitchen_area";
const QString FIELD_ANNOUNCEMENT_WATER_PIPES                = "water_pipes";
const QString FIELD_ANNOUNCEMENT_GAS                        = "gas";
const QString FIELD_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QString FIELD_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroom_type";
const QString FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "ads_text";
const QString FIELD_ANNOUNCEMENT_PRICE                      = "price";
const QString FIELD_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publication_or_update_time";
const QString FIELD_ANNOUNCEMENT_ADDITION_INFORMATION       = "addition_information";

const QString SQL_INSERT_ANNOUNCEMENT  = "insert into ads (id, people_id, house_id, settlement_id, type, rooms_count, total_area, living_area, kitchen_area, water_pipes, gas, sewerage, bathroom_type, ads_text, price, publication_or_update_time, addition_information) values (%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17')";
const QString SQL_REMOVE_ANNOUNCEMENT  = "delete from ads where id=%1";
const QString SQL_SELECT_ANNOUNCEMENTS = "select * from ads where type=%1";
const QString SQL_UPDATE_ANNOUNCEMENT  = "update ads set house_id=%1, settlement_id=%2, rooms_count=%3, total_area=%4, living_area=%5, kitchen_area=%6, water_pipes=%7, gas=%8, sewerage=%9, bathroom_type=%10, ads_text='%11', price=%12, publication_or_update_time='%13', addition_information=%14' where id=%15";

const QByteArray ROLE_ANNOUNCEMENT_PEOPLE_ID                  = "peopleId";
const QByteArray ROLE_ANNOUNCEMENT_HOUSE_ID                   = "houseId";
const QByteArray ROLE_ANNOUNCEMENT_SETTLEMENT_ID              = "settlementId";
const QByteArray ROLE_ANNOUNCEMENT_TYPE                       = "type";
const QByteArray ROLE_ANNOUNCEMENT_ROOMS_COUNT                = "roomsCount";
const QByteArray ROLE_ANNOUNCEMENT_TOTAL_AREA                 = "totalArea";
const QByteArray ROLE_ANNOUNCEMENT_LIVING_AREA                = "livingArea";
const QByteArray ROLE_ANNOUNCEMENT_KITCHEN_AREA               = "kitchenArea";
const QByteArray ROLE_ANNOUNCEMENT_WATER_PIPES                = "waterPipes";
const QByteArray ROLE_ANNOUNCEMENT_GAS                        = "gas";
const QByteArray ROLE_ANNOUNCEMENT_SEWERAGE                   = "sewerage";
const QByteArray ROLE_ANNOUNCEMENT_BATHROOM_TYPE              = "bathroomType";
const QByteArray ROLE_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = "announcementText";
const QByteArray ROLE_ANNOUNCEMENT_PRICE                      = "price";
const QByteArray ROLE_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = "publicationOrUpdateTime";
const QByteArray ROLE_ANNOUNCEMENT_ADDITION_INFORMATION       = "additionInformation";

const int DATA_COUNT_ANNOUNCEMENT                            = 16;
const int DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID                  = 0;
const int DATA_INDEX_ANNOUNCEMENT_HOUSE_ID                   = 1;
const int DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID              = 2;
const int DATA_INDEX_ANNOUNCEMENT_TYPE                       = 3;
const int DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT                = 4;
const int DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA                 = 5;
const int DATA_INDEX_ANNOUNCEMENT_LIVING_AREA                = 6;
const int DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA               = 7;
const int DATA_INDEX_ANNOUNCEMENT_WATER_PIPES                = 8;
const int DATA_INDEX_ANNOUNCEMENT_GAS                        = 9;
const int DATA_INDEX_ANNOUNCEMENT_SEWERAGE                   = 10;
const int DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE              = 11;
const int DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT          = 12;
const int DATA_INDEX_ANNOUNCEMENT_PRICE                      = 13;
const int DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME = 14;
const int DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION       = 15;

#endif // DEFINITIONS_H
