#include "sqliteQuery.h"

// database type
const QString SQLITE_DB_TYPE = "QSQLITE";

// people
const QString SQLITE_SQL_GET_USER = "select * from people where phone='%1'";
const QString SQLITE_SQL_ADD_USER = "insert into people (id, surname, name, patronymic, phone, email, password) values (%1, '%2', '%3', '%4', '%5', '%6', '%7')";
const QString SQLITE_SQL_MIN_USER = "select min(id) as adminId from people";

// settlements
const QString SQLITE_SQL_INSERT_LOCALITY   = "insert into settlements (id, type, name) values (%1, %2, '%3')";
const QString SQLITE_SQL_REMOVE_LOCALITY   = "delete from settlements where id=%1";
const QString SQLITE_SQL_SELECT_LOCALITIES = "select * from settlements where name like '%1%'";
const QString SQLITE_SQL_UPDATE_LOCALITY   = "update settlements set type=%1, name='%2' where id=%3";

// streets
const QString SQLITE_SQL_INSERT_STREET  = "insert into streets (id, settlement_id, name) values (%1, %2, '%3')";
const QString SQLITE_SQL_REMOVE_STREET  = "delete from streets where id=%1";
const QString SQLITE_SQL_SELECT_STREETS = "select * from streets where name like '%1%' and settlement_id=%2";
const QString SQLITE_SQL_UPDATE_STREET  = "update streets set name='%1' where id=%2";

// houses
const QString SQLITE_SQL_INSERT_HOUSE  = "insert into houses (id, street_id, type, number, housing_number, land_area) values (%1, %2, %3, '%4', '%5', %6)";
const QString SQLITE_SQL_REMOVE_HOUSE  = "delete from houses where id=%1";
const QString SQLITE_SQL_SELECT_HOUSES = "select * from houses where number like '%1%' and street_id=%2";
const QString SQLITE_SQL_UPDATE_HOUSE  = "update houses set type=%1, number='%2', housing_number='%3', land_area=%4 where id=%5";

// announcement
const QString SQLITE_SQL_INSERT_ANNOUNCEMENT  = "insert into ads (id, people_id, house_id, settlement_id, type, rooms_count, total_area, living_area, \
       kitchen_area, water_pipes, gas, sewerage, bathroom_type, ads_text, price, publication_or_update_time, \
       addition_information, settlement_house_type) values (%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17', %18)";
const QString SQLITE_SQL_REMOVE_ANNOUNCEMENT  = "delete from ads where id=%1";
const QString SQLITE_SQL_SELECT_ANNOUNCEMENTS = "select A.*, \
       B.name as user_name, B.phone, B.email, \
       C.type as house_type, C.number, C.housing_number, C.land_area, \
       D.type as settlements_type_buy, D.name as settlements_name_buy, \
       E.name as streets_name, \
       F.type as settlements_type, F.name as settlements_name \
       from ads A \
       left join people B on B.id=A.people_id \
       left join houses C on C.id=A.house_id \
       left join settlements D on D.id=A.settlement_id \
       left join streets E on E.id=C.street_id \
       left join settlements F on F.id=E.settlement_id \
        where (F.name like '%1%' or D.name like '%1%') and A.type=%2 and (%3<1 or %3=A.people_id or %3=(select min(id) as adminId from people))";
const QString SQLITE_SQL_UPDATE_ANNOUNCEMENT  = "update ads set house_id=%1, settlement_id=%2, rooms_count=%3, total_area=%4, living_area=%5, kitchen_area=%6, \
       water_pipes=%7, gas=%8, sewerage=%9, bathroom_type=%10, ads_text='%11', price=%12, publication_or_update_time='%13', addition_information='%14', settlement_house_type=%15 where id=%16";

// service commands
const QString SQLITE_SQL_ADS_GET_HOUSE_INFO = "select H.type, H.number, H.housing_number, H.land_area, \
       S.name as street_name, L.name as settlements_name, L.type as settlements_type from houses H \
       left join streets S on S.id=H.street_id \
       left join settlements L on L.id=S.settlement_id where H.id=%1";
const QString SQLITE_SQL_ADS_GET_LOCALITY_INFO = "select * from settlements where id=%1";

// generate id
const QString SQLITE_SQL_GET_ID = "select id from ids where table_name='%1'";
const QString SQLITE_SQL_SET_ID = "update ids set id=%2 where table_name='%1'";
const QString SQLITE_SQL_FLD_ID = "id";

// clear database
const QString SQLITE_SQL_CLEAR_ADS        = "delete from ads";
const QString SQLITE_SQL_CLEAR_HOUSES     = "delete from houses";
const QString SQLITE_SQL_CLEAR_STREETS    = "delete from streets";
const QString SQLITE_SQL_CLEAR_LOCALITIES = "delete from settlements";
const QString SQLITE_SQL_CLEAR_PEOPLE     = "delete from people";

const QString& sqliteQuery::sql(RecordType recordType, SQLType sqlType) {
    switch (recordType) {
    case RecordType::LocalityRecord: switch (sqlType) {
        case SQLType::Select: return SQLITE_SQL_SELECT_LOCALITIES;
        case SQLType::Insert: return SQLITE_SQL_INSERT_LOCALITY;
        case SQLType::Update: return SQLITE_SQL_UPDATE_LOCALITY;
        case SQLType::Remove: return SQLITE_SQL_REMOVE_LOCALITY;
        }
    case RecordType::StreetRecord: switch (sqlType) {
        case SQLType::Select: return SQLITE_SQL_SELECT_STREETS;
        case SQLType::Insert: return SQLITE_SQL_INSERT_STREET;
        case SQLType::Update: return SQLITE_SQL_UPDATE_STREET;
        case SQLType::Remove: return SQLITE_SQL_REMOVE_STREET;
        }
    case RecordType::HouseRecord: switch (sqlType) {
        case SQLType::Select: return SQLITE_SQL_SELECT_HOUSES;
        case SQLType::Insert: return SQLITE_SQL_INSERT_HOUSE;
        case SQLType::Update: return SQLITE_SQL_UPDATE_HOUSE;
        case SQLType::Remove: return SQLITE_SQL_REMOVE_HOUSE;
        }
    case RecordType::AnnouncementRecord: switch (sqlType) {
        case SQLType::Select: return SQLITE_SQL_SELECT_ANNOUNCEMENTS;
        case SQLType::Insert: return SQLITE_SQL_INSERT_ANNOUNCEMENT;
        case SQLType::Update: return SQLITE_SQL_UPDATE_ANNOUNCEMENT;
        case SQLType::Remove: return SQLITE_SQL_REMOVE_ANNOUNCEMENT;
        }
    }
    return EMPTY_STRING;
}

const QString& sqliteQuery::dbType() {
    return SQLITE_DB_TYPE;
}

const QString& sqliteQuery::sqlUser(SQLUser sqlUser) {
    switch (sqlUser) {
    case SQLUser::Add: return SQLITE_SQL_ADD_USER;
    case SQLUser::Get: return SQLITE_SQL_GET_USER;
    case SQLUser::Min: return SQLITE_SQL_MIN_USER;
    }
    return EMPTY_STRING;
}

const QString& sqliteQuery::sqlInfo(SQLInfo sqlInfo) {
    switch (sqlInfo) {
    case SQLInfo::Locality: return SQLITE_SQL_ADS_GET_LOCALITY_INFO;
    case SQLInfo::House:    return SQLITE_SQL_ADS_GET_HOUSE_INFO;
    }
    return EMPTY_STRING;
}

void sqliteQuery::idGenerator(const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId) {
    sqlGetId = SQLITE_SQL_GET_ID.arg(tableName);
    sqlSetId = SQLITE_SQL_SET_ID.arg(tableName);
    fieldId  = SQLITE_SQL_FLD_ID;
}

QList<QString> sqliteQuery::clearSqls() {
    return QList<QString>({SQLITE_SQL_CLEAR_ADS, SQLITE_SQL_CLEAR_HOUSES, SQLITE_SQL_CLEAR_STREETS, SQLITE_SQL_CLEAR_LOCALITIES, SQLITE_SQL_CLEAR_PEOPLE});
}
