#ifndef SQLITEIMPL_H
#define SQLITEIMPL_H

#include <QList>

class DbConnection;

namespace SQLiteImpl {
    // database type
    const QString DB_TYPE         = "QSQLITE";
    const QString CONNECTION_NAME = "QSQLITERealEstate";

    // people
    const QString QUERY_ADD_USER = "insert into people (id, surname, name, patronymic, phone, email, password) values (%1, '%2', '%3', '%4', '%5', '%6', '%7')";
    const QString QUERY_GET_USER = "select * from people where phone='%1'";
    const QString QUERY_MIN_USER = "select min(id) as adminId from people";

    // settlements
    const QString QUERY_DELETE_LOCALITY   = "delete from settlements where id=%1";
    const QString QUERY_INSERT_LOCALITY   = "insert into settlements (id, type, name) values (%1, %2, '%3')";
    const QString QUERY_SELECT_LOCALITIES = "select * from settlements where name like '%1%'";
    const QString QUERY_UPDATE_LOCALITY   = "update settlements set type=%1, name='%2' where id=%3";

    // streets
    const QString QUERY_DELETE_STREET  = "delete from streets where id=%1";
    const QString QUERY_INSERT_STREET  = "insert into streets (id, settlement_id, name) values (%1, %2, '%3')";
    const QString QUERY_SELECT_STREETS = "select * from streets where name like '%1%' and settlement_id=%2";
    const QString QUERY_UPDATE_STREET  = "update streets set name='%1' where id=%2";

    // houses
    const QString QUERY_DELETE_HOUSE  = "delete from houses where id=%1";
    const QString QUERY_INSERT_HOUSE  = "insert into houses (id, street_id, type, number, housing_number, land_area) values (%1, %2, %3, '%4', '%5', %6)";
    const QString QUERY_SELECT_HOUSES = "select * from houses where number like '%1%' and street_id=%2";
    const QString QUERY_UPDATE_HOUSE  = "update houses set type=%1, number='%2', housing_number='%3', land_area=%4 where id=%5";

    // announcement
    const QString QUERY_DELETE_ANNOUNCEMENT  = "delete from ads where id=%1";
    const QString QUERY_INSERT_ANNOUNCEMENT  = "insert into ads (id, people_id, house_id, settlement_id, type, rooms_count, total_area, living_area, \
           kitchen_area, water_pipes, gas, sewerage, bathroom_type, ads_text, price, publication_or_update_time, \
           addition_information, settlement_house_type) values (%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17', %18)";
    const QString QUERY_SELECT_ANNOUNCEMENTS = "select A.*, \
           B.name as user_name, B.phone, B.email, \
           C.type as house_type, C.number, C.housing_number, C.land_area, \
           D.type as settlements_type_buy, D.name as settlements_name_buy, \
           E.name as streets_name, \
           F.type as settlements_type, F.name as settlements_name \
           from ads A \
           left join people B on B.id=A.people_id \
           left join houses C on C.id=A.house_id \
           left join settlements D on D.id=A.settlement_id \
           left join streets E on E.id=C.street_id \
           left join settlements F on F.id=E.settlement_id \
            where (F.name like '%1%' or D.name like '%1%') and A.type=%2 and (%3<1 or %3=A.people_id or %3=(select min(id) as adminId from people))";
    const QString QUERY_UPDATE_ANNOUNCEMENT  = "update ads set house_id=%1, settlement_id=%2, rooms_count=%3, total_area=%4, living_area=%5, kitchen_area=%6, \
           water_pipes=%7, gas=%8, sewerage=%9, bathroom_type=%10, ads_text='%11', price=%12, publication_or_update_time='%13', addition_information='%14', settlement_house_type=%15 where id=%16";

    // service commands
    const QString QUERY_HOUSE_INFO = "select H.type, H.number, H.housing_number, H.land_area, \
           S.name as street_name, L.name as settlements_name, L.type as settlements_type from houses H \
           left join streets S on S.id=H.street_id \
           left join settlements L on L.id=S.settlement_id where H.id=%1";
    const QString QUERY_LOCALITY_INFO = "select * from settlements where id=%1";

    bool getId(DbConnection* db, const QString& tableName, int& id);
    QList<QString> clearQueries();
    bool createDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword);
    bool dropDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword);
}

#endif // SQLITEIMPL_H
