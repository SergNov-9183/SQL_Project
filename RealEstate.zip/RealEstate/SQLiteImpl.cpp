#include "SQLiteImpl.h"

#include "DbConnection.h"
#include "DBUtils.h"

namespace {
    // generate id
    const QString FIELD_GET_ID = "id";
    const QString QUERY_GET_ID = "select id from ids where table_name='%1'";
    const QString QUERY_SET_ID = "update ids set id=%2 where table_name='%1'";

    // clear database
    const QString QUERY_CLEAR_ADS        = "delete from ads";
    const QString QUERY_CLEAR_HOUSES     = "delete from houses";
    const QString QUERY_CLEAR_STREETS    = "delete from streets";
    const QString QUERY_CLEAR_LOCALITIES = "delete from settlements";
    const QString QUERY_CLEAR_PEOPLE     = "delete from people";
}

bool SQLiteImpl::getId(DbConnection* db, const QString& tableName, int& id) {
    if (auto query = db->exec(QUERY_GET_ID.arg(tableName))) {
        if (query->next()) {
            id = toInt(query, FIELD_GET_ID);
         }
        id += 1;
        db->call(QUERY_SET_ID.arg(id).arg(tableName));
        return true;
    }
    id = -1;
    return false;
}

QList<QString> SQLiteImpl::clearQueries() {
    return QList<QString>({QUERY_CLEAR_ADS, QUERY_CLEAR_HOUSES, QUERY_CLEAR_STREETS, QUERY_CLEAR_LOCALITIES, QUERY_CLEAR_PEOPLE});
}

bool SQLiteImpl::createDatabase(DbConnection*, const QString&, const QString&, const QString&, const QString&, const QString&, const QString&) {
    return false;
}

bool SQLiteImpl::dropDatabase(DbConnection*, const QString&, const QString&, const QString&, const QString&) {
    return false;
}
