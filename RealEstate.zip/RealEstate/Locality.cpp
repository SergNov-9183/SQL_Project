#include "Locality.h"

#include <QDebug>

#include "Definitions.h"

enum LocalityRoles {
    localityType = Qt::DisplayRole,
    localityName = Qt::UserRole + 1
};

Locality::Locality(int id, const DbConnection& db) : Record(id, db) {
}

Locality::~Locality() {
}

QString Locality::insertQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::LocalityRecord, SQLType::Insert);
    return sql.arg(id()).arg(m_type).arg(m_name);
}

QString Locality::removeQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::LocalityRecord, SQLType::Remove);
    return sql.arg(id());
}

QString Locality::updateQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::LocalityRecord, SQLType::Update);
    return sql.arg(m_type).arg(m_name).arg(id());
}

bool Locality::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_LOCALITY &&
           (values[DATA_INDEX_LOCALITY_TYPE].toInt()    != m_type ||
            values[DATA_INDEX_LOCALITY_NAME].toString() != m_name);
}

void Locality::update(const std::shared_ptr<QSqlQuery>& query) {
    m_type = DbConnection::toInt(query, FIELD_LOCALITY_TYPE);
    m_name = DbConnection::toString(query, FIELD_LOCALITY_NAME);
}

void Locality::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_type = values[DATA_INDEX_LOCALITY_TYPE].toInt();
        m_name = values[DATA_INDEX_LOCALITY_NAME].toString();
    }
}

QVariant Locality::value(int role) const {
    switch (role) {
    case localityType: return QVariant(m_type);
    case localityName: return QVariant(m_name);
    default:           return QVariant();
    }
}

QList<QVariant> Locality::values() const {
    return QList<QVariant>({m_type, m_name});
}

void Locality::print() const {
    qDebug() << FIELD_LOCALITY_TYPE << ": " << m_type << "; " << FIELD_LOCALITY_NAME << ": " << m_name;
}

int Locality::generateId(DbConnection& db) {
    int id;
    return db.getId(TABLE_LOCALITIES, id) ? id : -1;
}

QHash<int, QByteArray> Locality::roleNames() {
    QHash<int, QByteArray> roles;
    roles[localityType] = ROLE_LOCALITY_TYPE;
    roles[localityName] = ROLE_LOCALITY_NAME;
    return roles;
}
