#include "Locality.h"

#include <QDebug>

#include "Definitions.h"

enum LocalityRoles {
    localityType = Qt::DisplayRole,
    localityName = Qt::UserRole + 1
};

Locality::Locality(int id) : Record(id) {
}

Locality::~Locality() {
}

QString Locality::insertQuery() {
    return SQL_INSERT_LOCALITY.arg(id()).arg(m_type).arg(m_name);
}

QString Locality::removeQuery() {
    return SQL_REMOVE_LOCALITY.arg(id());
}

QString Locality::updateQuery() {
    return SQL_UPDATE_LOCALITY.arg(m_type).arg(m_name).arg(id());
}

bool Locality::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_LOCALITY &&
           (values[DATA_INDEX_LOCALITY_TYPE].toInt()    != m_type ||
            values[DATA_INDEX_LOCALITY_NAME].toString() != m_name);
}

void Locality::update(const std::shared_ptr<QSqlQuery>& query) {
    m_type = DbConnection::toInt(query, FIELD_LOCALITY_TYPE);
    m_name = DbConnection::toString(query, FIELD_LOCALITY_NAME);
}

void Locality::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_type = values[DATA_INDEX_LOCALITY_TYPE].toInt();
        m_name = values[DATA_INDEX_LOCALITY_NAME].toString();
    }
}

QVariant Locality::value(int role) const {
    switch (role) {
    case localityType: return QVariant(m_type);
    case localityName: return QVariant(m_name);
    default:           return QVariant();
    }
}

QList<QVariant> Locality::values() const {
    return QList<QVariant>({m_type, m_name});
}

void Locality::print() const {
    qDebug() << FIELD_LOCALITY_TYPE << ": " << m_type << "; " << FIELD_LOCALITY_NAME << ": " << m_name;
}

int Locality::generateId(DbConnection& db) {
    int id;
    return db.getId(TABLE_LOCALITIES, id) ? id : -1;
}

QHash<int, QByteArray> Locality::roleNames() {
    QHash<int, QByteArray> roles;
    roles[localityType] = ROLE_LOCALITY_TYPE;
    roles[localityName] = ROLE_LOCALITY_NAME;
    return roles;
}

QString Locality::selectQuery() {
    return SQL_SELECT_LOCALITIES;
}
