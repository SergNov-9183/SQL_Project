#ifndef PGSQLIMPL_H
#define PGSQLIMPL_H

#include <QList>

class DbConnection;

namespace PGSqlImpl {
    // database type
    const QString DB_TYPE         = "QPSQL";
    const QString CONNECTION_NAME = "QPSQLRealEstate";

    // people
    const QString QUERY_ADD_USER  = "select * from add_user(%1, '%2', '%3', '%4', '%5', '%6', '%7')";
    const QString QUERY_GET_USER  = "select * from get_user('%1')";
    const QString QUERY_MIN_USER  = "select * from min_user()";

    // settlements
    const QString QUERY_DELETE_LOCALITY   = "select * from remove_settlements(%1)";
    const QString QUERY_INSERT_LOCALITY   = "select * from insert_settlements(%1, %2, '%3')";
    const QString QUERY_SELECT_LOCALITIES = "select * from select_settlements('%1%')";
    const QString QUERY_UPDATE_LOCALITY   = "select * from update_settlements(%1, '%2', %3)";

    // streets
    const QString QUERY_DELETE_STREET  = "select * from remove_streets(%1)";
    const QString QUERY_INSERT_STREET  = "select * from insert_streets(%1, %2, '%3')";
    const QString QUERY_SELECT_STREETS = "select * from select_streets('%1%', %2)";
    const QString QUERY_UPDATE_STREET  = "select * from update_streets('%1', %2)";

    // houses
    const QString QUERY_DELETE_HOUSE  = "select * from remove_houses(%1)";
    const QString QUERY_INSERT_HOUSE  = "select * from insert_houses(%1, %2, %3, '%4', '%5', %6)";
    const QString QUERY_SELECT_HOUSES = "select * from select_houses('%1%', %2)";
    const QString QUERY_UPDATE_HOUSE  = "select * from update_houses(%1, '%2', '%3', %4, %5)";

    // announcement
    const QString QUERY_DELETE_ANNOUNCEMENT  = "select * from remove_ads(%1)";
    const QString QUERY_INSERT_ANNOUNCEMENT  = "select * from insert_ads(%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17', %18)";
    const QString QUERY_SELECT_ANNOUNCEMENTS = "select * from select_ads('%1', %2, %3)";
    const QString QUERY_UPDATE_ANNOUNCEMENT  = "select * from update_ads(%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, '%11', %12, '%13', '%14', %15, %16)";

    // service commands
    const QString QUERY_HOUSE_INFO    = "select * from get_house_info(%1)";
    const QString QUERY_LOCALITY_INFO = "select * from get_settlement_info(%1)";

    bool getId(DbConnection* db, const QString& tableName, int& id);
    QList<QString> clearQueries();
    bool createDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword);
    bool dropDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword);
};

#endif // PGSQLIMPL_H
