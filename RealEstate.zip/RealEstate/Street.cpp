#include "Street.h"

#include <QDebug>

#include "Definitions.h"

enum StreetRoles {
    streetSettlementId = Qt::DisplayRole,
    streetName         = Qt::UserRole + 1
};

Street::Street(int id, const DbConnection& db) : Record(id, db) {
}

Street::~Street() {
}

QString Street::insertQuery() {
    return m_db[Query::insertStreet].arg(id()).arg(m_settlement_id).arg(m_name);
}

QString Street::removeQuery() {
    return m_db[Query::deleteStreet].arg(id());
}

QString Street::updateQuery() {
    return m_db[Query::updateStreet].arg(m_name).arg(id());
}

bool Street::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_STREET &&
           (values[DATA_INDEX_STREET_SETTLEMENT_ID].toInt() != m_settlement_id ||
            values[DATA_INDEX_STREET_NAME].toString()       != m_name);
}

void Street::update(const std::shared_ptr<QSqlQuery>& query) {
    m_settlement_id = toInt(query, FIELD_STREET_SETTLEMENT_ID);
    m_name          = toString(query, FIELD_STREET_NAME);
}

void Street::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_settlement_id = values[DATA_INDEX_STREET_SETTLEMENT_ID].toInt();
        m_name          = values[DATA_INDEX_STREET_NAME].toString();
    }
}

QVariant Street::value(int role) const {
    switch (role) {
    case streetSettlementId: return QVariant(m_settlement_id);
    case streetName:         return QVariant(m_name);
    default:                 return QVariant();
    }
}

QList<QVariant> Street::values() const {
    return QList<QVariant>({m_settlement_id, m_name});
}

void Street::print() const {
    qDebug() << FIELD_STREET_SETTLEMENT_ID << ": " << m_settlement_id << "; " << FIELD_STREET_NAME << ": " << m_name;
}

QHash<int, QByteArray> Street::roleNames() {
    QHash<int, QByteArray> roles;
    roles[streetSettlementId] = ROLE_STREET_SETTLEMENT_ID;
    roles[streetName]         = ROLE_STREET_NAME;
    return roles;
}
