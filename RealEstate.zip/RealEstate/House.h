#ifndef HOUSE_H
#define HOUSE_H

#include "Record.h"

class House : public Record {

public:
    House(int id, const DbConnection& db);
    ~House();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;

    void print() const override;

    static QHash<int, QByteArray> roleNames();

private:
    int m_street_id;
    int m_type;
    QString m_number;
    QString m_housing_number;
    int m_land_area;
};

#endif // HOUSE_H
