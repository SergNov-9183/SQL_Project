#include <QtWidgets/QApplication>

#include "RealEstate.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    RealEstate mainWindow;
    mainWindow.show();
    return a.exec();
}
