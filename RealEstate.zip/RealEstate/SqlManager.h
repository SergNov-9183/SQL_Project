#ifndef SQLMANAGER_H
#define SQLMANAGER_H

#include <QList>
#include <QString>

class DbConnection;

const QString CONNECTION_NAME = "RealEstate";
const QString EMPTY_STRING    = "";

enum class RecordType {
    LocalityRecord = 0,
    StreetRecord,
    HouseRecord,
    AnnouncementRecord
};

enum class DbType {
    PostgreSQL = 0,
    SQLite
};

enum class SQLType {
    Select = 0,
    Insert,
    Update,
    Remove
};

enum class SQLUser {
    Get = 0,
    Add,
    Min
};

enum class SQLInfo {
    Locality = 0,
    House
};

namespace sqlManager {
    const QString& dbType(DbType dbType);
    const QString& sql(DbType dbType, RecordType recordType, SQLType sqlType);
    const QString& sqlUser(DbType dbType, SQLUser sqlUser);
    const QString& sqlInfo(DbType dbType, SQLInfo sqlInfo);
    void idGenerator(DbType dbType, const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId);
    QList<QString> clearSqls(DbType dbType);
    const QString selectQuery(DbType dbType, RecordType recordType, const QString& findString, int id, int userId);

};

#endif // SQLMANAGER_H
