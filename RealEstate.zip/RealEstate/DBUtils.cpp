#include "DBUtils.h"

#include <QVariant>

QString toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toString();
}

int toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toInt();
}

float toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toFloat();
}

bool toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toBool();
}
