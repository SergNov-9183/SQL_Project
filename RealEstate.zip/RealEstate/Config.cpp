#include "Config.h"

#include <QApplication>
#include <QFile>
#include <QXmlStreamWriter>

#include "Definitions.h"
#include "Enqript.h"

QString getStringAttribute(const QXmlStreamAttributes& attributes, const QString& attributeName) {
    return attributes.hasAttribute(attributeName) ? attributes.value(attributeName).toString() : QString();
}

QString getEncryptStringAttribute(const QXmlStreamAttributes& attributes, const QString& attributeName) {
    return attributes.hasAttribute(attributeName) ? decrypt(attributes.value(attributeName).toString()) : QString();
}

void loadConfig(DbConnection& db) {
    QFile file(CONFIG_FILENAME.arg(QApplication::applicationDirPath()));
    if (file.exists() && file.open(QFile::ReadOnly | QFile::Text)) {
        QXmlStreamReader xml(&file);
        while (!xml.atEnd() && !xml.hasError()) {
            if (xml.readNext() == QXmlStreamReader::StartElement && xml.name() == CONFIG_SECTION) {
                auto attributes         = xml.attributes();
                auto dbType             = getStringAttribute(attributes, CONFIG_DB_TYPE).toInt();
                auto ip                 = getStringAttribute(attributes, CONFIG_IP);
                auto databaseName       = getStringAttribute(attributes, CONFIG_DATABASENAME);
                auto connectionUser     = getEncryptStringAttribute(attributes, CONFIG_CONNECTIONUSER);
                auto connectionPassword = getEncryptStringAttribute(attributes, CONFIG_CONNECTIONPASSWORD);
                db.open(dbType, ip, databaseName, connectionUser, connectionPassword);
            }
        }
        file.close();
    }
}

void saveConfig(const DbConnection& db) {
    QFile file(CONFIG_FILENAME.arg(QApplication::applicationDirPath()));
    if (file.open(QIODevice::WriteOnly)) {
        QXmlStreamWriter xml(&file);
        xml.setAutoFormatting(true);
        xml.writeStartDocument();
        xml.writeStartElement(CONFIG_SECTION);
        xml.writeAttribute(CONFIG_DB_TYPE, QString::number(db.dbType()));
        xml.writeAttribute(CONFIG_IP, db.ip());
        xml.writeAttribute(CONFIG_DATABASENAME, db.databaseName());
        xml.writeAttribute(CONFIG_CONNECTIONUSER, encrypt(db.connectionUser()));
        xml.writeAttribute(CONFIG_CONNECTIONPASSWORD, encrypt(db.connectionPassword()));
        xml.writeEndElement();
        file.close();
    }
}
