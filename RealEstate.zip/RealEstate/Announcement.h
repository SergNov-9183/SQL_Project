#ifndef ANNOUNCEMENT_H
#define ANNOUNCEMENT_H

#include "Record.h"

class Announcement : public Record {

public:
    Announcement(int id, const DbConnection& db);
    ~Announcement();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;


    void print() const override;

    static QHash<int, QByteArray> roleNames();

private:
    int m_people_id;
    int m_house_id;
    int m_settlement_id;
    int m_type;
    int m_rooms_count;
    float m_total_area;
    float m_living_area;
    float m_kitchen_area;
    bool m_water_pipes;
    bool m_gas;
    bool m_sewerage;
    int m_bathroom_type;
    QString m_announcement_text;
    int m_price;
    QString m_publication_or_update_time;
    QString m_addition_information;
    int m_settlementHouseType;
    int m_pricePerSqM;

    QString m_userName;
    QString m_phone;
    QString m_email;
    int m_houseType;
    QString m_number;
    QString m_housingNumber;
    int m_landArea;
    int m_settlementsTypeBuy;
    QString m_settlementsNameBuy;
    QString m_streetsName;
    int m_settlementsType;
    QString m_settlementsName;
};

#endif // ANNOUNCEMENT_H
