#ifndef ANNOUNCEMENT_H
#define ANNOUNCEMENT_H

#include "Record.h"

class Announcement : public Record {

public:
    Announcement(int id);
    ~Announcement();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;


    void print() const override;

    static int generateId(DbConnection& db);
    static QHash<int, QByteArray> roleNames();
    static QString selectQuery(int id);

private:
    int m_people_id;
    int m_house_id;
    int m_settlement_id;
    int m_type;
    int m_rooms_count;
    float m_total_area;
    float m_living_area;
    float m_kitchen_area;
    bool m_water_pipes;
    bool m_gas;
    bool m_sewerage;
    int m_bathroom_type;
    QString m_announcement_text;
    int m_price;
    QString m_publication_or_update_time;
    QString m_addition_information;
};

#endif // ANNOUNCEMENT_H
