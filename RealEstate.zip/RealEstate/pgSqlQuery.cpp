#include "pgSqlQuery.h"

#include "DbConnection.h"
#include "pgSqlScript.h"

// database type
const QString PGSQL_DB_TYPE   = "QPSQL";
const QString PGSQL_DB_MASTER = "postgres";

// people
const QString PGSQL_SQL_GET_USER  = "select * from get_user('%1')";
const QString PGSQL_SQL_ADD_USER  = "select * from add_user(%1, '%2', '%3', '%4', '%5', '%6', '%7')";
const QString PGSQL_SQL_MIN_USER  = "select * from min_user()";

// settlements
const QString PGSQL_SQL_INSERT_LOCALITY   = "select * from insert_settlements(%1, %2, '%3')";
const QString PGSQL_SQL_REMOVE_LOCALITY   = "select * from remove_settlements(%1)";
const QString PGSQL_SQL_SELECT_LOCALITIES = "select * from select_settlements('%1%')";
const QString PGSQL_SQL_UPDATE_LOCALITY   = "select * from update_settlements(%1, '%2', %3)";

// streets
const QString PGSQL_SQL_INSERT_STREET  = "select * from insert_streets(%1, %2, '%3')";
const QString PGSQL_SQL_REMOVE_STREET  = "select * from remove_streets(%1)";
const QString PGSQL_SQL_SELECT_STREETS = "select * from select_streets('%1%', %2)";
const QString PGSQL_SQL_UPDATE_STREET  = "select * from update_streets('%1', %2)";

// houses
const QString PGSQL_SQL_INSERT_HOUSE  = "select * from insert_houses(%1, %2, %3, '%4', '%5', %6)";
const QString PGSQL_SQL_REMOVE_HOUSE  = "select * from remove_houses(%1)";
const QString PGSQL_SQL_SELECT_HOUSES = "select * from select_houses('%1%', %2)";
const QString PGSQL_SQL_UPDATE_HOUSE  = "select * from update_houses(%1, '%2', '%3', %4, %5)";

// announcement
const QString PGSQL_SQL_INSERT_ANNOUNCEMENT  = "select * from insert_ads(%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, '%14', %15, '%16', '%17', %18)";
const QString PGSQL_SQL_REMOVE_ANNOUNCEMENT  = "select * from remove_ads(%1)";
const QString PGSQL_SQL_SELECT_ANNOUNCEMENTS = "select * from select_ads('%1', %2, %3)";
const QString PGSQL_SQL_UPDATE_ANNOUNCEMENT  = "select * from update_ads(%1, %2, %3, %4, %5, %6, %7, %8, %9, %10, '%11', %12, '%13', '%14', %15, %16)";

// service commands
const QString PGSQL_SQL_ADS_GET_HOUSE_INFO    = "select * from get_house_info(%1)";
const QString PGSQL_SQL_ADS_GET_LOCALITY_INFO = "select * from get_settlement_info(%1)";

// generate id
const QString PGSQL_SQL_GET_ID = "select nextval('%1_ID_seq'::regclass)";
const QString PGSQL_SQL_FLD_ID = "nextval";

// clear database
const QString PGSQL_SQL_CLEAR_LOCALITIES = "delete from settlements";
const QString PGSQL_SQL_CLEAR_PEOPLE     = "delete from people";

// drop database
const QString PGSQL_SQL_DROP_DB_1 = "update pg_database set datallowconn = 'false' where datname = '%1';";
const QString PGSQL_SQL_DROP_DB_2 = "select pg_terminate_backend(pg_stat_activity.pid) from pg_stat_activity where pg_stat_activity.datname = '%1' and pid <> pg_backend_pid();";
const QString PGSQL_SQL_DROP_DB_3 = "drop database %1;";

// create database
const QString PGSQL_SQL_CREATE_DB = "CREATE DATABASE %1;";

// create database user
const QString PGSQL_SQL_DB_USER_GET        = "SELECT usename FROM pg_user where usename='%1';";
const QString PGSQL_SQL_DB_USER_CREATE     = "CREATE USER %1 WITH PASSWORD '%2';";
const QString PGSQL_SQL_DB_USER_PRIVILEGES = "GRANT ALL PRIVILEGES ON DATABASE %1 to %2;";

const QString& pgSqlQuery::dbType() {
    return PGSQL_DB_TYPE;
}

const QString& pgSqlQuery::sql(RecordType recordType, SQLType sqlType) {
    switch (recordType) {
    case RecordType::LocalityRecord: switch (sqlType) {
        case SQLType::Select: return PGSQL_SQL_SELECT_LOCALITIES;
        case SQLType::Insert: return PGSQL_SQL_INSERT_LOCALITY;
        case SQLType::Update: return PGSQL_SQL_UPDATE_LOCALITY;
        case SQLType::Remove: return PGSQL_SQL_REMOVE_LOCALITY;
        }
    case RecordType::StreetRecord: switch (sqlType) {
        case SQLType::Select: return PGSQL_SQL_SELECT_STREETS;
        case SQLType::Insert: return PGSQL_SQL_INSERT_STREET;
        case SQLType::Update: return PGSQL_SQL_UPDATE_STREET;
        case SQLType::Remove: return PGSQL_SQL_REMOVE_STREET;
        }
    case RecordType::HouseRecord: switch (sqlType) {
        case SQLType::Select: return PGSQL_SQL_SELECT_HOUSES;
        case SQLType::Insert: return PGSQL_SQL_INSERT_HOUSE;
        case SQLType::Update: return PGSQL_SQL_UPDATE_HOUSE;
        case SQLType::Remove: return PGSQL_SQL_REMOVE_HOUSE;
        }
    case RecordType::AnnouncementRecord: switch (sqlType) {
        case SQLType::Select: return PGSQL_SQL_SELECT_ANNOUNCEMENTS;
        case SQLType::Insert: return PGSQL_SQL_INSERT_ANNOUNCEMENT;
        case SQLType::Update: return PGSQL_SQL_UPDATE_ANNOUNCEMENT;
        case SQLType::Remove: return PGSQL_SQL_REMOVE_ANNOUNCEMENT;
        }
    }
    return EMPTY_STRING;
}

const QString& pgSqlQuery::sqlUser(SQLUser sqlUser) {
    switch (sqlUser) {
    case SQLUser::Add: return PGSQL_SQL_ADD_USER;
    case SQLUser::Get: return PGSQL_SQL_GET_USER;
    case SQLUser::Min: return PGSQL_SQL_MIN_USER;
    }
    return EMPTY_STRING;
}

const QString& pgSqlQuery::sqlInfo(SQLInfo sqlInfo) {
    switch (sqlInfo) {
    case SQLInfo::Locality: return PGSQL_SQL_ADS_GET_LOCALITY_INFO;
    case SQLInfo::House:    return PGSQL_SQL_ADS_GET_HOUSE_INFO;
    }
    return EMPTY_STRING;
}

void pgSqlQuery::idGenerator(const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId) {
    sqlGetId = PGSQL_SQL_GET_ID.arg(tableName);
    sqlSetId = EMPTY_STRING;
    fieldId  = PGSQL_SQL_FLD_ID;
}

QList<QString> pgSqlQuery::clearSqls() {
    return QList<QString>({PGSQL_SQL_CLEAR_LOCALITIES, PGSQL_SQL_CLEAR_PEOPLE});
}

QList<QString> pgSqlQuery::dropDatabaseQueries() {
    return QList<QString>({PGSQL_SQL_DROP_DB_1, PGSQL_SQL_DROP_DB_2, PGSQL_SQL_DROP_DB_3});
}

const QString& pgSqlQuery::createDatabaseQuery() {
    return PGSQL_SQL_CREATE_DB;
}

const QString& pgSqlQuery::masterTable() {
    return PGSQL_DB_MASTER;
}

const QString& pgSqlQuery::createTabliesScript() {
    return PGSQL_SQL_CREATE_TABLES_SCRIPT;
}

const QString& pgSqlQuery::dbUserQuery(DbUserQuery dbUserQuery) {
    switch (dbUserQuery) {
    case DbUserQuery::Get:         return PGSQL_SQL_DB_USER_GET;
    case DbUserQuery::Create:      return PGSQL_SQL_DB_USER_CREATE;
    case DbUserQuery::Privilegies: return PGSQL_SQL_DB_USER_PRIVILEGES;
    }
    return EMPTY_STRING;
}
