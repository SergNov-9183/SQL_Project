#include "Enqript.h"

#include <iomanip>
#include <sstream>

std::string encryptDecrypt(const std::string& value) {
    std::string key = "KCQ"; //Any chars will work, in an array of any size
    std::string output = value;

    for (unsigned int i = 0; i < value.size(); i++) {
        output[i] = value[i] ^ key[i % (key.size() / sizeof(char))];
    }

    return output;
}

QString toHexString(const std::string& value) {
     std::stringstream ss;
     ss << std::hex;

     for (unsigned int i = 0 ; i < value.size(); ++i ) {
         ss << std::setw(2) << std::setfill('0') << static_cast<unsigned int>(value[i]);
     }

     auto result = ss.str();

     for (unsigned int i = 0 ; i < result.size(); ++i ) {
         result[i] = std::toupper(result[i]);
     }

     return QString::fromStdString(result);
}

unsigned int charToUInt(char value) {
    return value >= '0' && value <= '9' ? value - '0' :
                                          value >= 'A' && value <= 'F' ? value - 'A' + 10 : 0;
}

std::string toCharString(const QString& qvalue) {
    auto value = qvalue.toStdString();
    for (unsigned int i = 0 ; i < value.size(); ++i ) {
        value[i] = std::toupper(value[i]);
    }

    std::string result;
    const char* hex = value.c_str();
    while(*hex && hex[1]) {
        result.push_back(charToUInt(*hex)*16 + charToUInt(hex[1]));
        hex += 2;
    }
    return result;
}

QString encrypt(const QString& value) {
    return value.isEmpty() ? QString() : toHexString(encryptDecrypt(value.toStdString()));
}

QString decrypt(const QString& value) {
    return QString::fromStdString(encryptDecrypt(toCharString(value)));
}
