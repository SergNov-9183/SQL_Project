#ifndef STREET_H
#define STREET_H

#include "Record.h"

class Street : public Record {

public:
    Street(int id);
    ~Street();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;

    void print() const override;

    static int generateId(DbConnection& db);
    static QHash<int, QByteArray> roleNames();
    static QString selectQuery(int id = -1);

private:
    int m_settlement_id;
    QString m_name;
};

#endif // STREET_H
