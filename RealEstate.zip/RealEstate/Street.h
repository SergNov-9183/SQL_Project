#ifndef STREET_H
#define STREET_H

#include "Record.h"

class Street : public Record {

public:
    Street(int id, const DbConnection& db);
    ~Street();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;

    void print() const override;

    static QHash<int, QByteArray> roleNames();

private:
    int m_settlement_id;
    QString m_name;
};

#endif // STREET_H
