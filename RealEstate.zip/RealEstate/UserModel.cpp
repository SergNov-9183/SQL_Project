#include "UserModel.h"

#include <QDebug>

#include "Definitions.h"
#include "Enqript.h"

UserModel::UserModel(DbConnection& db, QObject* parent) : QObject(parent), m_db(db),  m_userInfo(NOT_SIGNED_IN), m_isAuthorized(false), m_userId(-1) {
}

void UserModel::login(const QString& login, const QString& password) {
    qDebug() << "login: " << login << "; password: " << password;
    if (auto query = m_db.execQuery(SQL_GET_USER.arg(login))) {
        if (query->next() && m_db.toString(query, FIELD_PEOPLE_PHONE) == login && m_db.toString(query, FIELD_PEOPLE_PASSWORD) == encrypt(password)) {
            auto suname     = m_db.toString(query, FIELD_PEOPLE_SURNAME);
            auto name       = m_db.toString(query, FIELD_PEOPLE_NAME);
            auto patronymic = m_db.toString(query, FIELD_PEOPLE_PARTRONYMIC);
            auto email      = m_db.toString(query, FIELD_PEOPLE_EMAIL);
            m_userInfo      = LOGGED_IN.arg(suname, name, patronymic, login, email);
            m_isAuthorized  = true;
            m_userId        = m_db.toInt(query, FIELD_ID);
            emit userChanged();
         }
   }
}

void UserModel::addUserAndLogin(const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password) {
    qDebug() << "suname: " << suname << "; name: " << name << "; patronymic: " << patronymic << "; phone: " << phone << "; email: " << email << "; password: " << password << ".";
    if (auto query = m_db.execQuery(SQL_GET_USER.arg(phone))) {
        int id;
        if (!query->next() && m_db.getId(TABLE_PEOPLE, id) && m_db.save(SQL_ADD_USER.arg(id).arg(suname, name, patronymic, phone, email, encrypt(password)))) {
            qDebug() << "id for new user: " << id;
            m_userInfo     = LOGGED_IN.arg(suname, name, patronymic, phone, email);
            m_isAuthorized = true;
            m_userId       = id;
            emit userChanged();
         }
   }
}

void UserModel::logout() {
    m_userInfo     = NOT_SIGNED_IN;
    m_isAuthorized = false;
    m_userId       = -1;
    emit userChanged();
}

int UserModel::userId() const {
    return m_userId;
}

QString UserModel::userInfo() const {
    return m_userInfo;
}

bool UserModel::isAuthorized() const {
    return m_isAuthorized;
}

bool UserModel::canEdit() const {
    return m_db.isValid() && m_userId == 0;
}

bool UserModel::isAdmin() const {
    return true; //m_db.isValid() && m_userId == 0;
}
