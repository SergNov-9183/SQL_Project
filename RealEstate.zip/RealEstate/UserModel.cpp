#include "UserModel.h"

#include <QDebug>

#include "Definitions.h"
#include "Enqript.h"

UserModel::UserModel(DbConnection& db, QObject* parent)
    : QObject(parent), m_db(db),  m_userInfo(NOT_SIGNED_IN), m_isAuthorized(false), m_userId(-1), m_name(QString()), m_phone(QString()), m_email(QString()) {
}

void UserModel::login(const QString& login, const QString& password) {
    qDebug() << "login: " << login << "; password: " << password;
    if (auto query = m_db.exec(m_db[Query::getUser].arg(login))) {
        if (query->next()) {
            auto phone = toString(query, FIELD_PEOPLE_PHONE);
            if (phone == login && toString(query, FIELD_PEOPLE_PASSWORD) == encrypt(password)) {
                m_phone         = phone;
                auto suname     = toString(query, FIELD_PEOPLE_SURNAME);
                m_name          = toString(query, FIELD_PEOPLE_NAME);
                auto patronymic = toString(query, FIELD_PEOPLE_PARTRONYMIC);
                m_email         = toString(query, FIELD_PEOPLE_EMAIL);
                m_userInfo      = LOGGED_IN.arg(suname, m_name, patronymic, login, m_email);
                m_isAuthorized  = true;
                m_userId        = toInt(query, FIELD_ID);
                emit userChanged();
            }
        }
    }
}

void UserModel::addUserAndLogin(const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password) {
    int id;
    if (m_db.addUser(id, suname, name, patronymic, phone, email, password)) {
        m_userInfo     = LOGGED_IN.arg(suname, name, patronymic, phone, email);
        m_isAuthorized = true;
        m_userId       = id;
        m_name         = name;
        m_phone        = phone;
        m_email        = email;
        emit userChanged();
    }
}

void UserModel::logout() {
    m_userInfo     = NOT_SIGNED_IN;
    m_isAuthorized = false;
    m_userId       = -1;
    m_name         = QString();
    m_phone        = QString();
    m_email        = QString();
    emit userChanged();
}

int UserModel::userId() const {
    return m_userId;
}

QString UserModel::userInfo() const {
    return m_userInfo;
}

bool UserModel::isAuthorized() const {
    return m_isAuthorized;
}

bool UserModel::isAdmin() const {
    auto adminId = m_db.adminId();
    return adminId > -1 and m_userId == adminId;
}

QString UserModel::name() const {
    return m_name;
}

QString UserModel::phone() const {
    return m_phone;
}

QString UserModel::email() const {
    return m_email;
}
