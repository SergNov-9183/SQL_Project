#include "UserModel.h"

#include <QDebug>

#include "Definitions.h"
#include "Enqript.h"

UserModel::UserModel(DbConnection& db, QObject* parent)
    : QObject(parent), m_db(db),  m_userInfo(NOT_SIGNED_IN), m_isAuthorized(false), m_userId(-1), m_name(QString()), m_phone(QString()), m_email(QString()) {
}

void UserModel::login(const QString& login, const QString& password) {
    qDebug() << "login: " << login << "; password: " << password;
    if (auto query = m_db.execQuery(sqlManager::sqlUser(m_db.dbType(), SQLUser::Get).arg(login))) {
        if (query->next()) {
            auto phone = m_db.toString(query, FIELD_PEOPLE_PHONE);
            if (phone == login && m_db.toString(query, FIELD_PEOPLE_PASSWORD) == encrypt(password)) {
                m_phone         = phone;
                auto suname     = m_db.toString(query, FIELD_PEOPLE_SURNAME);
                m_name          = m_db.toString(query, FIELD_PEOPLE_NAME);
                auto patronymic = m_db.toString(query, FIELD_PEOPLE_PARTRONYMIC);
                m_email         = m_db.toString(query, FIELD_PEOPLE_EMAIL);
                m_userInfo      = LOGGED_IN.arg(suname, m_name, patronymic, login, m_email);
                m_isAuthorized  = true;
                m_userId        = m_db.toInt(query, FIELD_ID);
                emit userChanged();
            }
        }
    }
}

void UserModel::addUserAndLogin(const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password) {
    int id;
    if (m_db.addUser(m_db.dbType(), id, suname, name, patronymic, phone, email, password)) {
        m_userInfo     = LOGGED_IN.arg(suname, name, patronymic, phone, email);
        m_isAuthorized = true;
        m_userId       = id;
        m_name         = name;
        m_phone        = phone;
        m_email        = email;
        emit userChanged();
    }

    qDebug() << "suname: " << suname << "; name: " << name << "; patronymic: " << patronymic << "; phone: " << phone << "; email: " << email << "; password: " << password << ".";
    if (auto query = m_db.execQuery(sqlManager::sqlUser(m_db.dbType(), SQLUser::Get).arg(phone))) {
        if (!query->next() && m_db.getId(TABLE_PEOPLE, id) && m_db.execute(sqlManager::sqlUser(m_db.dbType(), SQLUser::Add).arg(id).arg(suname, name, patronymic, phone, email, encrypt(password)))) {
            qDebug() << "id for new user: " << id;
         }
   }
}

void UserModel::logout() {
    m_userInfo     = NOT_SIGNED_IN;
    m_isAuthorized = false;
    m_userId       = -1;
    m_name         = QString();
    m_phone        = QString();
    m_email        = QString();
    emit userChanged();
}

int UserModel::userId() const {
    return m_userId;
}

QString UserModel::userInfo() const {
    return m_userInfo;
}

bool UserModel::isAuthorized() const {
    return m_isAuthorized;
}

bool UserModel::isAdmin() const {
    auto adminId = m_db.adminId();
    return adminId > -1 and m_userId == adminId;
}

QString UserModel::name() const {
    return m_name;
}

QString UserModel::phone() const {
    return m_phone;
}

QString UserModel::email() const {
    return m_email;
}
