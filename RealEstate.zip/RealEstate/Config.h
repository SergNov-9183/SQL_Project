#ifndef CONFIG_H
#define CONFIG_H

#include "DbConnection.h"

void loadConfig(DbConnection& db);
void saveConfig(const DbConnection& db);


#endif // CONFIG_H
