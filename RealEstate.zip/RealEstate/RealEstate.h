#ifndef REALESTATE_H
#define REALESTATE_H

#include <QtWidgets/QMainWindow>

#include "ViewModel.h"

// Главное окно приложения
class RealEstate : public QMainWindow {
    Q_OBJECT
public:
    RealEstate(QWidget *parent = nullptr);
    ~RealEstate();
private:
    // модель отображения для Qml содежимого окна
    ViewModel* m_viewModel;
};

#endif // REALESTATE_H
