#include "SqlManager.h"

#include "DbConnection.h"
#include "pgSqlQuery.h"
#include "sqliteQuery.h"

const QString& sqlManager::dbType(DbType dbType) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::dbType();
    case DbType::SQLite:     return sqliteQuery::dbType();
    }
    return EMPTY_STRING;
}

const QString& sqlManager::sql(DbType dbType, RecordType recordType, SQLType sqlType) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::sql(recordType, sqlType);
    case DbType::SQLite:     return sqliteQuery::sql(recordType, sqlType);
    }
    return EMPTY_STRING;
}

const QString& sqlManager::sqlUser(DbType dbType, SQLUser sqlUser) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::sqlUser(sqlUser);
    case DbType::SQLite:     return sqliteQuery::sqlUser(sqlUser);
    }
    return EMPTY_STRING;
}

const QString& sqlManager::sqlInfo(DbType dbType, SQLInfo sqlInfo) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::sqlInfo(sqlInfo);
    case DbType::SQLite:     return sqliteQuery::sqlInfo(sqlInfo);
    }
    return EMPTY_STRING;
}

void sqlManager::idGenerator(DbType dbType, const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::idGenerator(tableName, sqlGetId, sqlSetId, fieldId);
    case DbType::SQLite:     return sqliteQuery::idGenerator(tableName, sqlGetId, sqlSetId, fieldId);
    }
}

QList<QString> sqlManager::clearSqls(DbType dbType) {
    switch (dbType) {
    case DbType::PostgreSQL: return pgSqlQuery::clearSqls();
    case DbType::SQLite:     return sqliteQuery::clearSqls();
    }
    return QList<QString>();
}

const QString sqlManager::selectQuery(DbType dbType, RecordType recordType, const QString& findString, int id, int userId) {
    auto query = sql(dbType, recordType, SQLType::Select).arg(findString);
    switch (recordType) {
    case RecordType::LocalityRecord:     return query;
    case RecordType::AnnouncementRecord: return query.arg(id).arg(userId);
    default:                             return query.arg(id);
    }
}
