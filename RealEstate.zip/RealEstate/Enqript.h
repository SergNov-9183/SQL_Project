#ifndef ENQRIPT_H
#define ENQRIPT_H

#include <QString>

QString encrypt(const QString& value);
QString decrypt(const QString& value);

#endif // ENQRIPT_H
