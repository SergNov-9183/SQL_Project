#ifndef DBUTILS_H
#define DBUTILS_H

#include <functional>
#include <memory>

#include <QSqlQuery>

class DbConnection;

struct Impl {
    const QString& dbType;
    const QString& connectionName;
    std::function<bool(DbConnection*, const QString&, int&)> getId;
    std::function<QList<QString>()> clearQueries;
    std::function<bool(DbConnection*, const QString&, const QString&, const QString&, const QString&, const QString&, const QString&)> createDatabase;
    std::function<bool(DbConnection*, const QString&, const QString&, const QString&, const QString&)> dropDatabase;
};

enum class DbType {
    PostgreSQL = 0,
    SQLite
};

QString toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
int toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
float toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
bool toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);

#endif // DBUTILS_H
