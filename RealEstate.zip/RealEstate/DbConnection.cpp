#include "DbConnection.h"

#include <QStringList>
#include <QDebug>
#include <QSqlError>

#include "Definitions.h"

DbType dbTypeFromInt(int value) {
    return value == 1 ? DbType::SQLite : DbType::PostgreSQL;
}

DbConnection::DbConnection(QObject *parent) : QObject(parent), m_adminId(-1), m_dbType(DbType::PostgreSQL), m_ip(QString()), m_databaseName(QString()), m_connectionUser(QString()), m_connectionPassword(QString()) {
}

void DbConnection::open(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    close();

    m_dbType             = dbTypeFromInt(dbType);
    m_ip                 = ip;
    m_databaseName       = databaseName;
    m_connectionUser     = connectionUser;
    m_connectionPassword = connectionPassword;

    if (m_dbType == DbType::PostgreSQL) {
        m_dbConnection = QSqlDatabase::addDatabase(QPSQL_DB_TYPE);
        m_dbConnection.setHostName(ip);
        m_dbConnection.setDatabaseName(databaseName);
        m_dbConnection.setUserName(connectionUser);
        m_dbConnection.setPassword(connectionPassword);
    }
    else {
        m_dbConnection = QSqlDatabase::addDatabase(SQLITE_DB_TYPE);
        m_dbConnection.setDatabaseName(databaseName);
    }
    m_dbConnection.open();

    auto info = dbType == 0 ? QString("database type: QPSQL; ip: %1; databaseName: %2; connection user: %3; connection password: %4").arg(ip, databaseName, connectionUser, connectionPassword)
                            : QString("database type: QSQLITE; database path: %1").arg(databaseName);
    qDebug() << info << (m_dbConnection.isOpen() ? "; database opened" : "; can't open database");

    emit connectionChanged();
}

void DbConnection::close() {
    if (isValid()) {
        m_dbConnection.close();
        m_adminId = -1;
        emit connectionChanged();
    }
}

std::shared_ptr<QSqlQuery> DbConnection::execQuery(const QString& query) {
    if (isValid()) {
        if (auto result = std::make_shared<QSqlQuery>(m_dbConnection)) {
            if (result->exec(query)) {
                return result;
            }
            else {
                qDebug()<<"Ошибка выполнения запроса (" << query << "): "  << result->lastError();
            }
        }
        else {
            qDebug()<<"Ошибка создания запроса: " << query;
        }
    }
    return nullptr;
}

// сохранение данных в БД
bool DbConnection::save(const QString& sql) {
    QSqlQuery query(m_dbConnection);
        auto result = query.exec(sql);
        if (!result) {
            qDebug()<<" Ошибка выполнения запроса: "<< sql << " "<<query.lastError();
        }
        return result && commit();
}

bool DbConnection::isValid() const {
    return m_dbConnection.isValid() && m_dbConnection.isOpen();
}

bool DbConnection::getId(const QString& tableName, int& id) {
    return m_dbType == DbType::PostgreSQL ? postgreSQLId(tableName, id) : sqliteId(tableName, id);
}

int DbConnection::adminId() {
    if (m_adminId < 0 && isValid()) {
        if (auto query = execQuery(SQL_MIN_USER)) {
            if (query->next()) {
                m_adminId = toInt(query, FIELD_ADMIN_ID);
            }
        }
    }
    return  m_adminId;
}

int DbConnection::dbType() const {
    return static_cast<int>(m_dbType);
}

QString DbConnection::ip() const {
    return m_ip;
}

QString DbConnection::databaseName() const {
    return m_databaseName;
}

QString DbConnection::connectionUser() const {
    return m_connectionUser;
}

QString DbConnection::connectionPassword() const {
    return m_connectionPassword;
}

QString DbConnection::toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toString();
}

int DbConnection::toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toInt();
}

float DbConnection::toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toFloat();
}

bool DbConnection::toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toBool();
}

bool DbConnection::postgreSQLId(const QString& tableName, int& id) {
    if (auto query = execQuery(SQL_GET_ID.arg(tableName))) {
        if (query->next()) {
            id = toInt(query, FIELD_NEXTVAL);
            return true;
        }
    }
    id = -1;
    return false;
}

bool DbConnection::sqliteId(const QString& tableName, int& id) {
    if (isValid()) {
        id = 0;
        if (auto query = execQuery(SQLITE_ID_GET.arg(tableName))) {
            if (query->next()) {
                id = query->value(SQLITE_ID_FLD).toInt();
             }
        }
        id += 1;
        save(SQLITE_ID_SET.arg(id).arg(tableName));
        return true;
    }
    id = -1;
    return false;
}

bool DbConnection::commit() {
    return m_dbType == DbType::PostgreSQL ? m_dbConnection.commit() : true;
}
