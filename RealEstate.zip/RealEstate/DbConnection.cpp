#include "DbConnection.h"

#include <QStringList>
#include <QDebug>
#include <QSqlError>

#include "Definitions.h"
#include "Enqript.h"
#include "pgSqlQuery.h"
#include "sqliteQuery.h"
#include "SqlManager.h"

DbType dbTypeFromInt(int value) {
    return value == 1 ? DbType::SQLite : DbType::PostgreSQL;
}

DbConnection::DbConnection(QObject *parent) : QObject(parent), m_adminId(-1), m_dbType(DbType::PostgreSQL), m_ip(QString()), m_databaseName(QString()), m_connectionUser(QString()), m_connectionPassword(QString()) {
}

void DbConnection::open(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    close();
    auto dbType = dbTypeFromInt(dbTypeAsInt);
    if (open(dbType, ip, databaseName, connectionUser, connectionPassword)) {
        m_dbType             = dbType;
        m_ip                 = ip;
        m_databaseName       = databaseName;
        m_connectionUser     = connectionUser;
        m_connectionPassword = connectionPassword;
        emit connectionChanged();
    }
}

void DbConnection::close() {
    if (isValid()) {
        m_dbConnection.close();
        m_adminId            = -1;
        m_ip                 = "";
        m_databaseName       = "";
        m_connectionUser     = "";
        m_connectionPassword = "";
        emit connectionChanged();
    }
    m_dbConnection.setDatabaseName("");
    m_dbConnection.setHostName("");
    m_dbConnection.setUserName("");
    m_dbConnection.setPassword("");
}

std::shared_ptr<QSqlQuery> DbConnection::execQuery(const QString& query) {
    if (isValid()) {
        if (auto result = std::make_shared<QSqlQuery>(m_dbConnection)) {
            if (result->exec(query)) {
                return result;
            }
            else {
                qDebug()<<"Ошибка выполнения запроса (" << query << "): "  << result->lastError();
            }
        }
        else {
            qDebug()<<"Ошибка создания запроса: " << query;
        }
    }
    return nullptr;
}

// сохранение данных в БД
bool DbConnection::execute(const QString& sql) {
    QSqlQuery query(m_dbConnection);
        auto result = query.exec(sql);
        if (!result) {
            qDebug()<<" Ошибка выполнения запроса: "<< sql << " "<<query.lastError();
        }
        return result && commit();
}

bool DbConnection::isValid() const {
    return m_dbConnection.isValid() && m_dbConnection.isOpen();
}

void DbConnection::clearDatabase() {
    qDebug() << "Clear database";
    auto sqls = sqlManager::clearSqls(m_dbType);
    for (auto i = 0; i < sqls.size(); ++i) {
        execute(sqls[i]);
    }
}

bool DbConnection::dropDatabase(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword) {
    auto dbType = dbTypeFromInt(dbTypeAsInt);
    if (dbType == DbType::PostgreSQL && open(dbType, ip, pgSqlQuery::masterTable(), masterUser, masterPassword)) {
        auto queries = pgSqlQuery::dropDatabaseQueries();
        for (auto i = 0; i < queries.size(); ++i) {
            if (!execute(queries[i].arg(databaseName))) {
                return false;
            }
        }
        return true;
    }
    return false;
}

bool DbConnection::createDatabase(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword) {
    auto dbType = dbTypeFromInt(dbTypeAsInt);
    if (dbType == DbType::PostgreSQL && open(dbType, ip, pgSqlQuery::masterTable(), masterUser, masterPassword) &&
        execute(pgSqlQuery::createDatabaseQuery().arg(databaseName)) && createDatabaseUser(dbType, databaseName, connectionUser, connectionPassword)) {
        int id;
        close();
        if (open(dbType, ip, databaseName, connectionUser, connectionPassword) &&
            execute(pgSqlQuery::createTabliesScript())) {
            close();
        }
        auto result = open(dbType, ip, databaseName, connectionUser, connectionPassword) &&
                      addUser(dbType, id, "", connectionUser, "", connectionUser, "", connectionPassword);
        close();
        return result;
    }
    return false;
}

bool DbConnection::getId(const QString& tableName, int& id) {
    QString sqlGetId, sqlSetId, fieldId;
    sqlManager::idGenerator(m_dbType, tableName, sqlGetId, sqlSetId, fieldId);
    return m_dbType == DbType::PostgreSQL ? postgreSQLId(sqlGetId, fieldId, id) : sqliteId(sqlGetId, sqlSetId, fieldId, id);
}

int DbConnection::adminId() {
    if (m_adminId < 0 && isValid()) {
        if (auto query = execQuery(sqlManager::sqlUser(m_dbType, SQLUser::Min))) {
            if (query->next()) {
                m_adminId = toInt(query, FIELD_ADMIN_ID);
            }
        }
    }
    return  m_adminId;
}

bool DbConnection::addUser(DbType dbType, int& id, const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password) {
    qDebug() << "suname: " << suname << "; name: " << name << "; patronymic: " << patronymic << "; phone: " << phone << "; email: " << email << "; password: " << password << ".";
    if (auto query = execQuery(sqlManager::sqlUser(m_dbType, SQLUser::Get).arg(phone))) {
        if (!query->next() && getId(TABLE_PEOPLE, id) && execute(sqlManager::sqlUser(dbType, SQLUser::Add).arg(id).arg(suname, name, patronymic, phone, email, encrypt(password)))) {
            qDebug() << "id for new user: " << id;
            return true;
        }
    }
    qDebug() << "can't add new user: " << name;
    return false;
}

DbType DbConnection::dbType() const {
    return m_dbType;
}

int DbConnection::dbTypeAsInt() const {
    return static_cast<int>(m_dbType);
}

QString DbConnection::ip() const {
    return m_ip;
}

QString DbConnection::databaseName() const {
    return m_databaseName;
}

QString DbConnection::connectionUser() const {
    return m_connectionUser;
}

QString DbConnection::connectionPassword() const {
    return m_connectionPassword;
}

QString DbConnection::toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toString();
}

int DbConnection::toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toInt();
}

float DbConnection::toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toFloat();
}

bool DbConnection::toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toBool();
}

bool DbConnection::postgreSQLId(const QString& sqlGetId, const QString& fieldId, int& id) {
    if (auto query = execQuery(sqlGetId)) {
        if (query->next()) {
            id = toInt(query, fieldId);
            return true;
        }
    }
    id = -1;
    return false;
}

bool DbConnection::sqliteId(const QString& sqlGetId, const QString& sqlSetId, const QString& fieldId, int& id) {
    if (isValid()) {
        id = 0;
        if (auto query = execQuery(sqlGetId)) {
            if (query->next()) {
                id = toInt(query, fieldId);
             }
        }
        id += 1;
        execute(sqlSetId.arg(id));
        return true;
    }
    id = -1;
    return false;
}

bool DbConnection::open(DbType dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    close();
    //m_dbConnection = QSqlDatabase::addDatabase(sqlManager::dbType(dbType), CONNECTION_NAME);
    m_dbConnection = QSqlDatabase::addDatabase(sqlManager::dbType(dbType));

    m_dbConnection.setDatabaseName(databaseName);
    if (dbType == DbType::PostgreSQL) {
        m_dbConnection.setHostName(ip);
        m_dbConnection.setUserName(connectionUser);
        m_dbConnection.setPassword(connectionPassword);
    }
    auto result = m_dbConnection.open();

    auto info = dbType == DbType::PostgreSQL ? QString("database type: QPSQL; ip: %1; databaseName: %2; connection user: %3; connection password: %4").arg(ip, databaseName, connectionUser, connectionPassword)
                                             : QString("database type: QSQLITE; database path: %1").arg(databaseName);
    qDebug() << info << (m_dbConnection.isOpen() ? "; database opened" : QString("; can't open database: %1").arg(m_dbConnection.lastError().text()));

    return result;
}

bool DbConnection::createDatabaseUser(DbType dbType, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    if (dbType == DbType::PostgreSQL) {
        if (auto queryGetUser = execQuery(pgSqlQuery::dbUserQuery(DbUserQuery::Get).arg(connectionUser))) {
            if (queryGetUser->next() ? true : execute(pgSqlQuery::dbUserQuery(DbUserQuery::Create).arg(connectionUser, connectionPassword))) {
                return execute(pgSqlQuery::dbUserQuery(DbUserQuery::Privilegies).arg(databaseName, connectionUser));
            }
        }
    }
    return false;
}

bool DbConnection::commit() {
    return true;// m_dbType == DbType::PostgreSQL ? m_dbConnection.commit() : true;
}
