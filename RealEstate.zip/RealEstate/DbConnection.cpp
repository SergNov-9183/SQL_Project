#include "DbConnection.h"
#include <QStringList>
#include <QDebug>
#include <QSqlError>

#include "Definitions.h"

DbConnection::DbConnection(QObject *parent) : QObject(parent), m_ip(QString()), m_databaseName(QString()), m_connectionUser(QString()), m_connectionPassword(QString()) {
}

void DbConnection::open(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    close();

    m_ip                 = ip;
    m_databaseName       = databaseName;
    m_connectionUser     = connectionUser;
    m_connectionPassword = connectionPassword;
    m_dbConnection       = QSqlDatabase::addDatabase(QPSQL_DB_TYPE);

    m_dbConnection.setHostName(ip);
    m_dbConnection.setDatabaseName(databaseName);
    m_dbConnection.setUserName(connectionUser);
    m_dbConnection.setPassword(connectionPassword);
    m_dbConnection.open();

    emit connectionChanged();

    qDebug() << "ip: " << ip << "; databaseName: " << databaseName << "; connectionUser: " << connectionUser << "; connectionPassword: " << connectionPassword << (m_dbConnection.isOpen() ? "; database opened" : "; can't open database");
}

std::shared_ptr<QSqlQuery> DbConnection::execQuery(const QString& query) {
    if (isValid()) {
        if (auto result = std::make_shared<QSqlQuery>(m_dbConnection)) {
            if (result->exec(query)) {
                return result;
            }
            else {
                qDebug()<<"Ошибка выполнения запроса (" << query << "): "  << result->lastError();
            }
        }
        else {
            qDebug()<<"Ошибка создания запроса: " << query;
        }
    }
    return nullptr;
}

void DbConnection::close() {
    if (m_dbConnection.isOpen()) {
        m_dbConnection.close();
    }
}

// сохранение данных в БД
bool DbConnection::save(const QString& sql) {
    QSqlQuery query(m_dbConnection);
        auto result = query.exec(sql);
        if (!result) {
            qDebug()<<" Ошибка выполнения запроса: "<< sql << " "<<query.lastError();
        }
        return result && m_dbConnection.commit();
}

bool DbConnection::isValid() const {
    return true;// m_dbConnection.isValid() && m_dbConnection.isOpen();
}

bool DbConnection::getId(const QString& tableName, int& id) {
    if (auto query = execQuery(SQL_GET_ID.arg(tableName))) {
        if (query->next()) {
            id = toInt(query, FIELD_NEXTVAL);
            return true;
        }
    }
    id = -1;
    return false;
}

QString DbConnection::ip() const {
    return m_ip;
}

QString DbConnection::databaseName() const {
    return m_databaseName;
}

QString DbConnection::connectionUser() const {
    return m_connectionUser;
}

QString DbConnection::connectionPassword() const {
    return m_connectionPassword;
}

QString DbConnection::toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toString();
}

int DbConnection::toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toInt();
}

float DbConnection::toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
    return query->value(fieldName).toFloat();
}

bool DbConnection::toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName) {
        return query->value(fieldName).toBool();
}
