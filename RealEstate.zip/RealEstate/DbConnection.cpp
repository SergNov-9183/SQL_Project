#include "DbConnection.h"

#include <QDebug>
#include <QSqlError>

#include "Definitions.h"
#include "Enqript.h"
#include "PGSqlImpl.h"
#include "SQLiteImpl.h"

namespace {
    DbType dbTypeFromInt(int value) {
        return value == 1 ? DbType::SQLite : DbType::PostgreSQL;
    }
}

DbConnection::DbConnection(QObject *parent) : QObject(parent), m_adminId(-1), m_dbType(DbType::PostgreSQL) {
    m_impls   = {
        { DbType::PostgreSQL, { PGSqlImpl::DB_TYPE,  PGSqlImpl::CONNECTION_NAME,  PGSqlImpl::getId,  PGSqlImpl::clearQueries,  PGSqlImpl::createDatabase,  PGSqlImpl::dropDatabase  } },
        { DbType::SQLite,     { SQLiteImpl::DB_TYPE, SQLiteImpl::CONNECTION_NAME, SQLiteImpl::getId, SQLiteImpl::clearQueries, SQLiteImpl::createDatabase, SQLiteImpl::dropDatabase } }
    };
    m_tables  = {
        { Table::announcement, TABLE_ANNOUNCEMENTS },
        { Table::houses,       TABLE_HOUSES        },
        { Table::localities,   TABLE_LOCALITIES    },
        { Table::people,       TABLE_PEOPLE        },
        { Table::streets,      TABLE_STREETS       }
    };
    m_queries = {
        { DbType::PostgreSQL, {
              { Query::addUser,              PGSqlImpl::QUERY_ADD_USER              },
              { Query::getUser,              PGSqlImpl::QUERY_GET_USER              },
              { Query::minUser,              PGSqlImpl::QUERY_MIN_USER              },
              { Query::deleteLocality,       PGSqlImpl::QUERY_DELETE_LOCALITY       },
              { Query::insertLocality,       PGSqlImpl::QUERY_INSERT_LOCALITY       },
              { Query::selectLocalities,     PGSqlImpl::QUERY_SELECT_LOCALITIES     },
              { Query::updateLocality,       PGSqlImpl::QUERY_UPDATE_LOCALITY       },
              { Query::deleteStreet,         PGSqlImpl::QUERY_DELETE_STREET         },
              { Query::insertStreet,         PGSqlImpl::QUERY_INSERT_STREET         },
              { Query::selectStreets,        PGSqlImpl::QUERY_SELECT_STREETS        },
              { Query::updateStreet,         PGSqlImpl::QUERY_UPDATE_STREET         },
              { Query::deleteHouse,          PGSqlImpl::QUERY_DELETE_HOUSE          },
              { Query::insertHouse,          PGSqlImpl::QUERY_INSERT_HOUSE          },
              { Query::selectHouses,         PGSqlImpl::QUERY_SELECT_HOUSES         },
              { Query::updateHouse,          PGSqlImpl::QUERY_UPDATE_HOUSE          },
              { Query::deleteAnnouncement,   PGSqlImpl::QUERY_DELETE_ANNOUNCEMENT   },
              { Query::insertAnnouncement,   PGSqlImpl::QUERY_INSERT_ANNOUNCEMENT   },
              { Query::selectAnnouncements,  PGSqlImpl::QUERY_SELECT_ANNOUNCEMENTS  },
              { Query::updateAnnouncement,   PGSqlImpl::QUERY_UPDATE_ANNOUNCEMENT   },
              { Query::houseInfo,            PGSqlImpl::QUERY_HOUSE_INFO            },
              { Query::localityInfo,         PGSqlImpl::QUERY_LOCALITY_INFO         }
          } },
        { DbType::SQLite, {
              { Query::addUser,              SQLiteImpl::QUERY_ADD_USER             },
              { Query::getUser,              SQLiteImpl::QUERY_GET_USER             },
              { Query::minUser,              SQLiteImpl::QUERY_MIN_USER             },
              { Query::deleteLocality,       SQLiteImpl::QUERY_DELETE_LOCALITY      },
              { Query::insertLocality,       SQLiteImpl::QUERY_INSERT_LOCALITY      },
              { Query::selectLocalities,     SQLiteImpl::QUERY_SELECT_LOCALITIES    },
              { Query::updateLocality,       SQLiteImpl::QUERY_UPDATE_LOCALITY      },
              { Query::deleteStreet,         SQLiteImpl::QUERY_DELETE_STREET        },
              { Query::insertStreet,         SQLiteImpl::QUERY_INSERT_STREET        },
              { Query::selectStreets,        SQLiteImpl::QUERY_SELECT_STREETS       },
              { Query::updateStreet,         SQLiteImpl::QUERY_UPDATE_STREET        },
              { Query::deleteHouse,          SQLiteImpl::QUERY_DELETE_HOUSE         },
              { Query::insertHouse,          SQLiteImpl::QUERY_INSERT_HOUSE         },
              { Query::selectHouses,         SQLiteImpl::QUERY_SELECT_HOUSES        },
              { Query::updateHouse,          SQLiteImpl::QUERY_UPDATE_HOUSE         },
              { Query::deleteAnnouncement,   SQLiteImpl::QUERY_DELETE_ANNOUNCEMENT  },
              { Query::insertAnnouncement,   SQLiteImpl::QUERY_INSERT_ANNOUNCEMENT  },
              { Query::selectAnnouncements,  SQLiteImpl::QUERY_SELECT_ANNOUNCEMENTS },
              { Query::updateAnnouncement,   SQLiteImpl::QUERY_UPDATE_ANNOUNCEMENT  },
              { Query::houseInfo,            SQLiteImpl::QUERY_HOUSE_INFO           },
              { Query::localityInfo,         SQLiteImpl::QUERY_LOCALITY_INFO        }
          } }
    };
    m_db      = QSqlDatabase();
}

bool DbConnection::open(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    qDebug() << "_____03";
    if (setConnectionProperties(ip, databaseName, connectionUser, connectionPassword)) {
        if (m_db.open()) {
            qDebug() << "Database opened successfully. Current properties of connection:\n" << m_db;
            emit connectionChanged();
            return true;
        }
        qDebug() << "Can't open database: " << databaseName << ". Current properties of connection:\n" << m_db << "\nError message:\n" << m_db.lastError();
    }
    return false;
}

bool DbConnection::open(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    return changeDatabase(dbType) && open(ip, databaseName, connectionUser, connectionPassword);
}

void DbConnection::close() {
    qDebug() << "_____05";
    if (isValid()) {
        qDebug() << "_____06";
        m_db.close();
        m_adminId = -1;
        emit connectionChanged();
    }
}

bool DbConnection::dropDatabase(int dbType, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword) {
    return changeDatabase(dbType) && impl().dropDatabase(this, ip, databaseName, masterUser, masterPassword);
}

bool DbConnection::createDatabase(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword) {
    qDebug() << "_____01";
    return changeDatabase(dbType) && impl().createDatabase(this, ip, databaseName, connectionUser, connectionPassword, masterUser, masterPassword);
}

const QString& DbConnection::operator[](const Query query) const {
    return queries(query);
}

bool DbConnection::call(const QString& command) {
    auto result{false};
    if (isValid()) {
        QSqlQuery query(m_db);
        result = query.exec(command);
        if (!result) {
            qDebug()<<"Command execution error: "<< command << "\nError message:\n" << query.lastError();
        }
    }
    return result;
}

std::shared_ptr<QSqlQuery> DbConnection::exec(const QString& query) {
    if (isValid()) {
        if (auto result = std::make_shared<QSqlQuery>(m_db)) {
            if (result->exec(query)) {
                return result;
            }
            else {
                qDebug()<<"Query execution error: "<< query << "\nError message:\n" << result->lastError();
            }
        }
        else {
            qDebug()<<"Query creation error: " << query;
        }
    }
    return nullptr;
}

void DbConnection::clearDatabase() {
    qDebug() << "Clear database";
    auto queries = impl().clearQueries();
    for (auto i = 0; i < queries.size(); ++i) {
        call(queries[i]);
    }
}

bool DbConnection::getId(Table table, int& id) {
    return isValid() && impl().getId(this, m_tables.at(table), id);
}

int DbConnection::dbTypeAsInt() const {
    return static_cast<int>(m_dbType);
}

const QString DbConnection::ip() const {
    return m_db.hostName();
}

const QString DbConnection::databaseName() const {
    return m_db.databaseName();
}

const QString DbConnection::connectionUser() const {
    return m_db.userName();
}

const QString DbConnection::connectionPassword() const {
    return m_db.password();
}

int DbConnection::adminId() {
    if (m_adminId < 0 && isValid()) {
        if (auto query = exec(queries(Query::minUser))) {
            if (query->next()) {
                m_adminId = toInt(query, FIELD_ADMIN_ID);
            }
        }
    }
    return  m_adminId;
}

bool DbConnection::addUser(int& id, const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password) {
    qDebug() << "suname: " << suname << "; name: " << name << "; patronymic: " << patronymic << "; phone: " << phone << "; email: " << email << "; password: " << password << ".";
    if (auto query = exec(queries(Query::getUser).arg(phone))) {
        if (!query->next() && getId(Table::people, id) && call(queries(Query::addUser).arg(id).arg(suname, name, patronymic, phone, email, encrypt(password)))) {
            qDebug() << "id for new user: " << id;
            return true;
        }
    }
    qDebug() << "can't add new user: " << name;
    return false;
}

bool DbConnection::setConnectionProperties(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword) {
    if (isValid()) {
        qDebug() << "Can't set properties for database connection. Connection is open. Current values: " << m_db;
        return false;
    }
    else {
        m_db.setDatabaseName(databaseName);
        m_db.setHostName(ip);
        m_db.setUserName(connectionUser);
        m_db.setPassword(connectionPassword);
        qDebug() << "Properties for database connection set successfully. New values: " << m_db;
        return true;
    }
}

bool DbConnection::changeDatabase(int dbTypeAsInt) {
    qDebug() << "_____04";
    close();
    auto dbType = dbTypeFromInt(dbTypeAsInt);
    if (dbType != m_dbType || !QSqlDatabase::contains(impl().connectionName)) {
        qDebug() << "_____07";
        m_db = QSqlDatabase();
        if (QSqlDatabase::contains(impl().connectionName)) {
            QSqlDatabase::removeDatabase(impl().connectionName);
        }
        m_dbType = dbType;
        m_db     = QSqlDatabase::addDatabase(impl().dbType, impl().connectionName);
        if (m_db.isValid()) {
            qDebug() << "_____08";
            return true;
        }
        m_db = QSqlDatabase();
        QSqlDatabase::removeDatabase(impl().connectionName);
        qDebug() << "Can't change database type to: " << impl().dbType << ". Connection isn't valid";
        return false;
    }
    return true;
}

bool DbConnection::isValid() {
    return m_db.isValid() && m_db.isOpen();
}

const Impl& DbConnection::impl() const {
    return m_impls.at(m_dbType);
}

const QString& DbConnection::queries(const Query query) const {
    return m_queries.at(m_dbType).at(query);
}
