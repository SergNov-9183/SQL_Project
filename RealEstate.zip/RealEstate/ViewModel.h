#ifndef VIEWMODEL_H
#define VIEWMODEL_H

#include <QObject>

#include "DbConnection.h"
#include "UserModel.h"
#include "ListModel.h"

class ViewModel : public QObject {
    Q_OBJECT

    Q_PROPERTY(QObject* db READ db CONSTANT)
    Q_PROPERTY(QObject* userModel READ userModel CONSTANT)

    Q_PROPERTY(QAbstractListModel* localities READ localities CONSTANT)
    Q_PROPERTY(QAbstractListModel* streets READ streets CONSTANT)
    Q_PROPERTY(QAbstractListModel* houses READ houses CONSTANT)

    Q_PROPERTY(QAbstractListModel* announcements READ announcements CONSTANT)

public:
    ViewModel(QObject* parent = nullptr);

    void prepareForDeletion() const;
    void clearListModel() const;

    Q_INVOKABLE QList<QVariant> houseInfo(int id);
    Q_INVOKABLE QList<QVariant> localityInfo(int id);


public slots:
    void connectionChanged();

private:
    DbConnection* m_db = nullptr;
    UserModel* m_userModel = nullptr;
    ListModel* m_localities = nullptr;
    ListModel* m_streets = nullptr;
    ListModel* m_houses = nullptr;
    ListModel* m_announcements = nullptr;

    QObject* db() const;
    QObject* userModel() const;
    QAbstractListModel* localities() const;
    QAbstractListModel* streets() const;
    QAbstractListModel* houses() const;
    QAbstractListModel* announcements() const;
};

#endif // VIEWMODEL_H
