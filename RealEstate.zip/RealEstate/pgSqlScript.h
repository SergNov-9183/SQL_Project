#ifndef PGSQLSCRIPT_H
#define PGSQLSCRIPT_H

#include <QString>

const QString PGSQL_SQL_CREATE_TABLES_SCRIPT = "\
SET statement_timeout = 0; \
SET lock_timeout = 0; \
SET idle_in_transaction_session_timeout = 0; \
SET client_encoding = 'UTF8'; \
SET standard_conforming_strings = on; \
SELECT pg_catalog.set_config('search_path', '', false); \
SET check_function_bodies = false; \
SET xmloption = content; \
SET client_min_messages = warning; \
SET row_security = off; \
 \
CREATE FUNCTION public.add_user(id integer, surname text, name text, patronymic text, phone text, email text, password text) RETURNS void \
    LANGUAGE sql \
    AS $$ \
insert into people (id, surname, name, patronymic, phone, email, password) values (add_user.id, add_user.surname, add_user.name, add_user.patronymic, add_user.phone, add_user.email, add_user.password) \
$$; \
 \
CREATE FUNCTION public.ads_history_after() RETURNS trigger \
    LANGUAGE plpgsql \
    AS $$ \
begin \
  if (new.type = 0 or new.type = 2) then \
    insert into ads_history \
    select new.id, TG_OP, P.surname, P.name, P.patronymic, P.phone, new.type, new.publication_or_update_time, H.settlements_name, H.street_name, H.number, H.housing_number, new.price   \
    from get_house_info(new.house_id) H \
    left join people P on P.id=new.people_id; \
  else \
    insert into ads_history \
    select new.id, TG_OP, P.surname, P.name, P.patronymic, P.phone, new.type, new.publication_or_update_time, L.name, null, null, null, new.price \
    from get_settlement_info(new.settlement_id) L \
    left join people P on P.id=new.people_id; \
  end if; \
  return new; \
end; \
$$; \
 \
CREATE FUNCTION public.ads_history_before() RETURNS trigger \
    LANGUAGE plpgsql \
    AS $$ \
begin \
  if (old.type = 0 or old.type = 2) then \
    insert into ads_history \
    select old.id, TG_OP, P.surname, P.name, P.patronymic, P.phone, old.type, old.publication_or_update_time, H.settlements_name, H.street_name, H.number, H.housing_number, old.price  \
    from get_house_info(old.house_id) H \
    left join people P on P.id=old.people_id; \
  else \
    insert into ads_history \
    select old.id, TG_OP, P.surname, P.name, P.patronymic, P.phone, old.type, old.publication_or_update_time, L.name, null, null, null, old.price  \
    from get_settlement_info(old.settlement_id) L \
    left join people P on P.id=old.people_id; \
  end if; \
  return old; \
end; \
$$; \
 \
CREATE FUNCTION public.calculate_sq_m_price_ins() RETURNS trigger \
    LANGUAGE plpgsql \
    AS $$ \
BEGIN \
    IF ((NEW.total_area IS NOT NULL) AND (NEW.total_area <> 0)) THEN \
        UPDATE ads SET price_per_sq_m = round((NEW.price / NEW.total_area)::numeric, 1) \
            WHERE (id = NEW.id); \
    END IF; \
    RETURN NEW; \
END; \
$$; \
 \
CREATE FUNCTION public.calculate_sq_m_price_upd() RETURNS trigger \
    LANGUAGE plpgsql \
    AS $$ \
BEGIN \
    IF ((NEW.total_area IS NOT NULL) AND (NEW.total_area <> 0)) THEN \
        NEW.price_per_sq_m = round((NEW.price / NEW.total_area)::numeric, 1); \
    END IF; \
    RETURN NEW; \
END; \
$$; \
 \
CREATE FUNCTION public.get_house_info(id integer) RETURNS TABLE(type integer, number text, housing_number text, land_area integer, street_name text, settlements_name text, settlements_type integer) \
    LANGUAGE sql \
    AS $$ \
select H.type, H.number, H.housing_number, H.land_area,  \
       S.name as street_name, L.name as settlements_name, L.type as settlements_type  \
from houses H  \
left join streets S on S.id=H.street_id  \
left join settlements L on L.id=S.settlement_id  \
where H.id=get_house_info.id \
$$; \
 \
CREATE FUNCTION public.get_settlement_info(id integer) RETURNS TABLE(id integer, type integer, name text) \
    LANGUAGE sql \
    AS $$ \
select id, type, name from settlements where id=get_settlement_info.id \
$$; \
 \
CREATE FUNCTION public.get_user(phone text) RETURNS TABLE(id integer, surname text, name text, patronymic text, phone text, email text, password text) \
    LANGUAGE sql \
    AS $$select * from people where phone=get_user.phone$$; \
 \
CREATE FUNCTION public.insert_ads(id integer, people_id integer, house_id integer, settlement_id integer, type integer, rooms_count integer, total_area double precision, living_area double precision, kitchen_area double precision, water_pipes boolean, gas boolean, sewerage boolean, bathroom_type integer, ads_text text, price integer, publication_or_update_time text, addition_information text, settlement_house_type integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
insert into ads (id, people_id, house_id, settlement_id, type, rooms_count, total_area, living_area, kitchen_area, water_pipes, gas,  \
                 sewerage, bathroom_type, ads_text, price, publication_or_update_time, addition_information, settlement_house_type)  \
        values (insert_ads.id, insert_ads.people_id, case when insert_ads.house_id < 1 then null else insert_ads.house_id end,  \
                case when insert_ads.settlement_id < 1 then null else insert_ads.settlement_id end, insert_ads.type, insert_ads.rooms_count,  \
                insert_ads.total_area, insert_ads.living_area, insert_ads.kitchen_area, insert_ads.water_pipes, insert_ads.gas, insert_ads.sewerage,  \
                insert_ads.bathroom_type, insert_ads.ads_text, insert_ads.price, insert_ads.publication_or_update_time, insert_ads.addition_information,  \
                insert_ads.settlement_house_type) \
$$; \
 \
CREATE FUNCTION public.insert_houses(id integer, street_id integer, type integer, number text, housing_number text, land_area integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
insert into houses (id, street_id, type, number, housing_number, land_area) values (insert_houses.id, insert_houses.street_id, insert_houses.type, insert_houses.number, insert_houses.housing_number, insert_houses.land_area) \
$$; \
 \
CREATE FUNCTION public.insert_settlements(id integer, type integer, name text) RETURNS void \
    LANGUAGE sql \
    AS $$ \
insert into settlements (id, type, name) values (insert_settlements.id, insert_settlements.type, insert_settlements.name) \
$$; \
 \
CREATE FUNCTION public.insert_streets(id integer, settlement_id integer, name text) RETURNS void \
    LANGUAGE sql \
    AS $$ \
insert into streets (id, settlement_id, name) values (insert_streets.id, insert_streets.settlement_id, insert_streets.name) \
$$; \
 \
CREATE FUNCTION public.min_user() RETURNS TABLE(adminid integer) \
    LANGUAGE sql \
    AS $$ \
select min(id) as adminId from people \
$$; \
 \
CREATE FUNCTION public.remove_ads(id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
delete from ads where id=remove_ads.id \
$$; \
 \
CREATE FUNCTION public.remove_houses(id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
delete from houses where id=remove_houses.id \
$$; \
 \
CREATE FUNCTION public.remove_settlements(id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
delete from settlements where id=remove_settlements.id \
$$; \
 \
CREATE FUNCTION public.remove_streets(id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
delete from streets where id=remove_streets.id \
$$; \
 \
CREATE FUNCTION public.select_ads(name_filter text, type integer, user_id integer) RETURNS TABLE(id integer, people_id integer, house_id integer, settlement_id integer, rooms_count integer, total_area double precision, living_area double precision, kitchen_area double precision, water_pipes boolean, gas boolean, sewerage boolean, bathroom_type integer, type integer, ads_text text, price double precision, publication_or_update_time text, addition_information text, settlement_house_type integer, price_per_sq_m double precision, user_name text, phone text, email text, house_type integer, number text, housing_number text, land_area integer, settlements_type_buy integer, settlements_name_buy text, streets_name text, settlements_type integer, settlements_name text) \
    LANGUAGE sql \
    AS $$ \
select A.*, \
    B.name as user_name, B.phone, B.email, \
    C.type as house_type, C.number, C.housing_number, C.land_area, \
    D.type as settlements_type_buy, D.name as settlements_name_buy, \
    E.name as streets_name, \
    F.type as settlements_type, F.name as settlements_name \
from ads A \
left join people B on B.id=A.people_id \
left join houses C on C.id=A.house_id \
left join settlements D on D.id=A.settlement_id \
left join streets E on E.id=C.street_id \
left join settlements F on F.id=E.settlement_id \
where (F.name like select_ads.name_filter || '%' or D.name like select_ads.name_filter || '%') and A.type=select_ads.type and (select_ads.user_id<1 or select_ads.user_id=A.people_id or select_ads.user_id=(select min(id) as adminId from people)) \
order by F.name, D.name \
$$; \
 \
CREATE FUNCTION public.select_houses(name_filter text, street_id integer) RETURNS TABLE(id integer, street_id integer, type integer, number text, housing_number text, land_area integer) \
    LANGUAGE sql \
    AS $$ \
select id, street_id, type, number, housing_number, land_area  \
from houses  \
where number like select_houses.name_filter and street_id=select_houses.street_id \
order by number \
$$; \
 \
CREATE FUNCTION public.select_settlements(name_filter text) RETURNS TABLE(id integer, type integer, name text) \
    LANGUAGE sql \
    AS $$ \
select id, type, name  \
from settlements  \
where name like select_settlements.name_filter \
order by name \
$$; \
 \
CREATE FUNCTION public.select_streets(name_filter text, settlement_id integer) RETURNS TABLE(id integer, settlement_id integer, name text) \
    LANGUAGE sql \
    AS $$ \
select id, settlement_id, name  \
from streets  \
where name like  select_streets.name_filter and settlement_id=select_streets.settlement_id \
order by name \
$$; \
 \
CREATE FUNCTION public.update_ads(house_id integer, settlement_id integer, rooms_count integer, total_area double precision, living_area double precision, kitchen_area double precision, water_pipes boolean, gas boolean, sewerage boolean, bathroom_type integer, ads_text text, price integer, publication_or_update_time text, addition_information text, settlement_house_type integer, id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
update ads set house_id=case when update_ads.house_id < 1 then null else update_ads.house_id end,  \
               settlement_id=case when update_ads.settlement_id < 1 then null else update_ads.settlement_id end,  \
               rooms_count=update_ads.rooms_count,  \
               total_area=update_ads.total_area,  \
               living_area=update_ads.living_area,  \
               kitchen_area=update_ads.kitchen_area,  \
               water_pipes=update_ads.water_pipes,  \
               gas=update_ads.gas,  \
               sewerage=update_ads.sewerage,  \
               bathroom_type=update_ads.bathroom_type,  \
               ads_text=update_ads.ads_text,  \
               price=update_ads.price,  \
               publication_or_update_time=update_ads.publication_or_update_time,  \
               addition_information=update_ads.addition_information,  \
               settlement_house_type=update_ads.settlement_house_type  \
where id=id \
$$; \
 \
CREATE FUNCTION public.update_houses(type integer, number text, housing_number text, land_area integer, id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
update houses set type=update_houses.type, number=update_houses.number, housing_number=update_houses.housing_number, land_area=update_houses.land_area where id=update_houses.id \
$$; \
 \
CREATE FUNCTION public.update_settlements(type integer, name text, id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
update settlements set type=update_settlements.type, name=update_settlements.name where id=update_settlements.id \
$$; \
 \
CREATE FUNCTION public.update_streets(name text, id integer) RETURNS void \
    LANGUAGE sql \
    AS $$ \
update streets set name=update_streets.name where id=update_streets.id \
$$; \
 \
SET default_tablespace = ''; \
 \
SET default_table_access_method = heap; \
 \
CREATE TABLE public.ads ( \
    id integer NOT NULL, \
    people_id integer NOT NULL, \
    house_id integer, \
    settlement_id integer, \
    rooms_count integer DEFAULT 1 NOT NULL, \
    total_area double precision DEFAULT 0 NOT NULL, \
    living_area double precision DEFAULT 0 NOT NULL, \
    kitchen_area double precision DEFAULT 0 NOT NULL, \
    water_pipes boolean DEFAULT true NOT NULL, \
    gas boolean DEFAULT true NOT NULL, \
    sewerage boolean DEFAULT true NOT NULL, \
    bathroom_type integer DEFAULT 0 NOT NULL, \
    type integer DEFAULT 0 NOT NULL, \
    ads_text text, \
    price integer DEFAULT 0 NOT NULL, \
    publication_or_update_time text, \
    addition_information text, \
    settlement_house_type integer DEFAULT 0 NOT NULL, \
    price_per_sq_m double precision DEFAULT 0 NOT NULL \
); \
 \
CREATE TABLE public.ads_history ( \
    id integer NOT NULL, \
    action text NOT NULL, \
    surname text, \
    name text, \
    patronymic text, \
    phone text, \
    ads_type integer, \
    date_time text NOT NULL, \
    settlements_name text, \
    street_name text, \
    house_number text, \
    housing_number text, \
    price integer \
); \
 \
CREATE SEQUENCE public.ads_id_seq \
    AS integer \
    START WITH 1 \
    INCREMENT BY 1 \
    NO MINVALUE \
    NO MAXVALUE \
    CACHE 1; \
 \
ALTER SEQUENCE public.ads_id_seq OWNED BY public.ads.id; \
 \
CREATE TABLE public.houses ( \
    id integer NOT NULL, \
    street_id integer NOT NULL, \
    type integer DEFAULT 0 NOT NULL, \
    number text DEFAULT 1 NOT NULL, \
    housing_number text, \
    land_area double precision DEFAULT 0 NOT NULL \
); \
 \
CREATE SEQUENCE public.houses_id_seq \
    AS integer \
    START WITH 1 \
    INCREMENT BY 1 \
    NO MINVALUE \
    NO MAXVALUE \
    CACHE 1; \
 \
ALTER SEQUENCE public.houses_id_seq OWNED BY public.houses.id; \
 \
CREATE TABLE public.people ( \
    id integer NOT NULL, \
    surname text, \
    name text, \
    patronymic text, \
    phone text NOT NULL, \
    email text, \
    password text \
); \
 \
CREATE SEQUENCE public.people_id_seq \
    AS integer \
    START WITH 1 \
    INCREMENT BY 1 \
    NO MINVALUE \
    NO MAXVALUE \
    CACHE 1; \
 \
ALTER SEQUENCE public.people_id_seq OWNED BY public.people.id; \
 \
CREATE TABLE public.settlements ( \
    id integer NOT NULL, \
    type integer DEFAULT 0 NOT NULL, \
    name text NOT NULL \
); \
 \
CREATE SEQUENCE public.settlements_id_seq \
    AS integer \
    START WITH 1 \
    INCREMENT BY 1 \
    NO MINVALUE \
    NO MAXVALUE \
    CACHE 1; \
 \
ALTER SEQUENCE public.settlements_id_seq OWNED BY public.settlements.id; \
 \
CREATE TABLE public.streets ( \
    id integer NOT NULL, \
    settlement_id integer NOT NULL, \
    name text NOT NULL \
); \
 \
CREATE SEQUENCE public.streets_id_seq \
    AS integer \
    START WITH 1 \
    INCREMENT BY 1 \
    NO MINVALUE \
    NO MAXVALUE \
    CACHE 1; \
 \
ALTER SEQUENCE public.streets_id_seq OWNED BY public.streets.id; \
 \
ALTER TABLE ONLY public.ads ALTER COLUMN id SET DEFAULT nextval('public.ads_id_seq'::regclass); \
 \
ALTER TABLE ONLY public.houses ALTER COLUMN id SET DEFAULT nextval('public.houses_id_seq'::regclass); \
 \
ALTER TABLE ONLY public.people ALTER COLUMN id SET DEFAULT nextval('public.people_id_seq'::regclass); \
 \
ALTER TABLE ONLY public.settlements ALTER COLUMN id SET DEFAULT nextval('public.settlements_id_seq'::regclass); \
 \
ALTER TABLE ONLY public.streets ALTER COLUMN id SET DEFAULT nextval('public.streets_id_seq'::regclass); \
 \
ALTER TABLE ONLY public.ads \
    ADD CONSTRAINT ads_pkey PRIMARY KEY (id); \
 \
ALTER TABLE ONLY public.houses \
    ADD CONSTRAINT houses_pkey PRIMARY KEY (id); \
 \
ALTER TABLE ONLY public.people \
    ADD CONSTRAINT people_pkey PRIMARY KEY (id); \
 \
ALTER TABLE ONLY public.settlements \
    ADD CONSTRAINT settlements_pkey PRIMARY KEY (id); \
 \
ALTER TABLE ONLY public.streets \
    ADD CONSTRAINT streets_pkey PRIMARY KEY (id); \
 \
CREATE INDEX ads_id ON public.ads USING btree (id); \
 \
CREATE INDEX houses_find ON public.houses USING btree (number); \
 \
CREATE INDEX houses_id ON public.houses USING btree (id); \
 \
CREATE INDEX people_id ON public.people USING btree (id); \
 \
CREATE INDEX settlements_find ON public.settlements USING btree (name); \
 \
CREATE INDEX settlements_id ON public.settlements USING btree (id); \
 \
CREATE INDEX streets_find ON public.streets USING btree (name); \
 \
CREATE INDEX streets_id ON public.streets USING btree (id); \
 \
CREATE TRIGGER ads_history_after_trigger AFTER INSERT OR UPDATE ON public.ads FOR EACH ROW EXECUTE FUNCTION public.ads_history_after(); \
 \
CREATE TRIGGER ads_history_before_trigger BEFORE DELETE ON public.ads FOR EACH ROW EXECUTE FUNCTION public.ads_history_before(); \
 \
CREATE TRIGGER tr_sq_m_price_ins AFTER INSERT ON public.ads FOR EACH ROW EXECUTE FUNCTION public.calculate_sq_m_price_ins(); \
 \
CREATE TRIGGER tr_sq_m_price_upd BEFORE UPDATE ON public.ads FOR EACH ROW EXECUTE FUNCTION public.calculate_sq_m_price_upd(); \
 \
ALTER TABLE ONLY public.ads \
    ADD CONSTRAINT ads_house_id_fkey FOREIGN KEY (house_id) REFERENCES public.houses(id) ON DELETE SET NULL NOT VALID; \
 \
ALTER TABLE ONLY public.ads \
    ADD CONSTRAINT ads_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id) ON DELETE CASCADE NOT VALID; \
 \
ALTER TABLE ONLY public.ads \
    ADD CONSTRAINT ads_settlement_id_fkey FOREIGN KEY (settlement_id) REFERENCES public.settlements(id) ON DELETE SET NULL NOT VALID; \
 \
ALTER TABLE ONLY public.houses \
    ADD CONSTRAINT houses_street_id_fkey FOREIGN KEY (street_id) REFERENCES public.streets(id) ON DELETE CASCADE; \
 \
ALTER TABLE ONLY public.streets \
    ADD CONSTRAINT streets_settlement_id_fkey FOREIGN KEY (settlement_id) REFERENCES public.settlements(id) ON DELETE CASCADE; \
";

#endif // PGSQLSCRIPT_H
