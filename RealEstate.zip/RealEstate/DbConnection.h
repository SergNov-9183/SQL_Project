#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include <memory>

#include <QObject>
#include <QSqlDatabase>
#include <QString>
#include <QSqlQuery>

enum class DbType {
    PostgreSQL = 0,
    SQLite
};

class DbConnection : public QObject
{
    Q_OBJECT

    Q_PROPERTY(int dbType READ dbType NOTIFY connectionChanged)
    Q_PROPERTY(QString ip READ ip NOTIFY connectionChanged)
    Q_PROPERTY(QString databaseName READ databaseName NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionUser READ connectionUser NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionPassword READ connectionPassword NOTIFY connectionChanged)

    Q_PROPERTY(bool isValid READ isValid NOTIFY connectionChanged)

public:
    DbConnection(QObject *parent = nullptr);

    Q_INVOKABLE void open(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    Q_INVOKABLE void close();

    std::shared_ptr<QSqlQuery> execQuery(const QString& query);
    bool save(const QString& sql);
    bool isValid() const;

    bool getId(const QString& tableName, int &id);
    int adminId();

    int dbType() const;
    QString ip() const;
    QString databaseName() const;
    QString connectionUser() const;
    QString connectionPassword() const;

    static QString toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static int toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static float toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static bool toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);

private:
    int m_adminId;
    DbType m_dbType;
    QString m_ip;
    QString m_databaseName;
    QString m_connectionUser;
    QString m_connectionPassword;

    QSqlDatabase m_dbConnection;

    bool postgreSQLId(const QString& tableName, int& id);
    bool sqliteId(const QString& tableName, int& id);

    bool commit();

signals:
    void connectionChanged();
};

#endif // DBCONNECTION_H
