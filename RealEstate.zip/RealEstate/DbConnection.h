#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include <memory>

#include <QObject>
#include <QSqlDatabase>
#include <QString>
#include <QSqlQuery>

class DbConnection : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString ip READ ip NOTIFY connectionChanged)
    Q_PROPERTY(QString databaseName READ databaseName NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionUser READ connectionUser NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionPassword READ connectionPassword NOTIFY connectionChanged)

    Q_PROPERTY(bool isValid READ isValid NOTIFY connectionChanged)

public:
    DbConnection(QObject *parent = nullptr);

    Q_INVOKABLE void open(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);

    std::shared_ptr<QSqlQuery> execQuery(const QString& query);
    void close();
    bool save(const QString& sql);
    bool isValid() const;

    bool getId(const QString& tableName, int &id);

    QString ip() const;
    QString databaseName() const;
    QString connectionUser() const;
    QString connectionPassword() const;

    static QString toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static int toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static float toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static bool toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);

private:
    QString m_ip;
    QString m_databaseName;
    QString m_connectionUser;
    QString m_connectionPassword;

    QSqlDatabase m_dbConnection;

signals:
    void connectionChanged();
};

#endif // DBCONNECTION_H
