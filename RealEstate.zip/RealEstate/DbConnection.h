#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include <memory>
#include <map>

#include <QObject>
#include <QSqlQuery>

#include "DBUtils.h"

enum class Table {
    announcement = 0,
    houses,
    localities,
    people,
    streets,
};

enum class Query {
        addUser = 0,
        getUser,
        minUser,
        deleteLocality,
        insertLocality,
        selectLocalities,
        updateLocality,
        deleteStreet,
        insertStreet,
        selectStreets,
        updateStreet,
        deleteHouse,
        insertHouse,
        selectHouses,
        updateHouse,
        deleteAnnouncement,
        insertAnnouncement,
        selectAnnouncements,
        updateAnnouncement,
        houseInfo,
        localityInfo
};

class DbConnection : public QObject {
    Q_OBJECT

    Q_PROPERTY(int     dbType             READ dbTypeAsInt        NOTIFY connectionChanged)
    Q_PROPERTY(QString ip                 READ ip                 NOTIFY connectionChanged)
    Q_PROPERTY(QString databaseName       READ databaseName       NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionUser     READ connectionUser     NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionPassword READ connectionPassword NOTIFY connectionChanged)
    Q_PROPERTY(bool    isValid            READ isValid            NOTIFY connectionChanged)

public:
    explicit DbConnection(QObject *parent = nullptr);

    bool open(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    Q_INVOKABLE bool open(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    Q_INVOKABLE void close();

    Q_INVOKABLE bool dropDatabase(int dbType, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword);
    Q_INVOKABLE bool createDatabase(int dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword);

    const QString& operator[] (const Query query) const;

    bool call(const QString& command);
    std::shared_ptr<QSqlQuery> exec(const QString& query);

    void clearDatabase();
    bool getId(Table table, int& id);

    int dbTypeAsInt() const;
    const QString ip() const;
    const QString databaseName() const;
    const QString connectionUser() const;
    const QString connectionPassword() const;

    int adminId();
    bool addUser(int& id, const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password);

private:
    int m_adminId;
    DbType m_dbType;
    std::map<DbType, Impl> m_impls;
    std::map<Table, const QString&> m_tables;
    std::map<DbType, std::map<Query, const QString&>> m_queries;
    QSqlDatabase m_db;

    bool setConnectionProperties(const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    bool changeDatabase(int dbTypeAsInt);

    bool isValid();
    const Impl& impl() const;
    const QString& queries(const Query query) const;

signals:
    void connectionChanged();
};

#endif // DBCONNECTION_H
