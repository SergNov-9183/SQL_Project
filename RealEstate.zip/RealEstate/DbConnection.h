#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include <memory>

#include <QObject>
#include <QSqlDatabase>
#include <QString>
#include <QSqlQuery>

#include "SqlManager.h"

class DbConnection : public QObject
{
    Q_OBJECT

    Q_PROPERTY(int dbType READ dbTypeAsInt NOTIFY connectionChanged)
    Q_PROPERTY(QString ip READ ip NOTIFY connectionChanged)
    Q_PROPERTY(QString databaseName READ databaseName NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionUser READ connectionUser NOTIFY connectionChanged)
    Q_PROPERTY(QString connectionPassword READ connectionPassword NOTIFY connectionChanged)

    Q_PROPERTY(bool isValid READ isValid NOTIFY connectionChanged)

public:
    DbConnection(QObject *parent = nullptr);

    Q_INVOKABLE void open(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    Q_INVOKABLE void close();

    Q_INVOKABLE bool dropDatabase(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword);
    Q_INVOKABLE bool createDatabase(int dbTypeAsInt, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword);

    std::shared_ptr<QSqlQuery> execQuery(const QString& query);
    bool execute(const QString& sql);
    bool isValid() const;
    void clearDatabase();
    bool getId(const QString& tableName, int &id);
    int adminId();
    bool addUser(DbType dbType, int& id, const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password);

    DbType dbType() const;
    int dbTypeAsInt() const;
    QString ip() const;
    QString databaseName() const;
    QString connectionUser() const;
    QString connectionPassword() const;

    static QString toString(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static int toInt(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static float toFloat(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);
    static bool toBool(const std::shared_ptr<QSqlQuery>& query, const QString& fieldName);

private:
    int m_adminId;
    DbType m_dbType;
    QString m_ip;
    QString m_databaseName;
    QString m_connectionUser;
    QString m_connectionPassword;

    QSqlDatabase m_dbConnection;

    bool postgreSQLId(const QString& sqlGetId, const QString& fieldId, int& id);
    bool sqliteId(const QString& sqlGetId, const QString& sqlSetId, const QString& fieldId, int& id);

    bool open(DbType dbType, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    bool createDatabaseUser(DbType dbType, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword);
    bool commit();

signals:
    void connectionChanged();
};

#endif // DBCONNECTION_H
