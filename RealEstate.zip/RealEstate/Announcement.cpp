#include "Announcement.h"

#include <QDebug>

#include "Definitions.h"

enum AnnouncementRoles {
    announcementPeopleId                = Qt::DisplayRole,
    announcementHouseId                 = Qt::UserRole + 1,
    announcementSettlementId            = Qt::UserRole + 2,
    announcementType                    = Qt::UserRole + 3,
    announcementRoomsCount              = Qt::UserRole + 4,
    announcementTotalArea               = Qt::UserRole + 5,
    announcementLivingArea              = Qt::UserRole + 6,
    announcementKitchenArea             = Qt::UserRole + 7,
    announcementWaterPipes              = Qt::UserRole + 8,
    announcementGas                     = Qt::UserRole + 9,
    announcementSewerage                = Qt::UserRole + 10,
    announcementBathroomType            = Qt::UserRole + 11,
    announcementAnnouncementText        = Qt::UserRole + 12,
    announcementPrice                   = Qt::UserRole + 13,
    announcementPublicationOrUpdateTime = Qt::UserRole + 14,
    announcementAdditionInformation     = Qt::UserRole + 15,
    announcementSettlementHouseType     = Qt::UserRole + 16,

    announcementUserName           = Qt::UserRole + 17,
    announcementPhone              = Qt::UserRole + 18,
    announcementEmail              = Qt::UserRole + 19,
    announcementHouseType          = Qt::UserRole + 20,
    announcementNumber             = Qt::UserRole + 21,
    announcementHousingNumber      = Qt::UserRole + 22,
    announcementLandArea           = Qt::UserRole + 23,
    announcementSettlementsTypeBuy = Qt::UserRole + 24,
    announcementSettlementsNameBuy = Qt::UserRole + 25,
    announcementStreetsName        = Qt::UserRole + 26,
    announcementSettlementsType    = Qt::UserRole + 27,
    announcementSettlementsName    = Qt::UserRole + 28
};


QString boolAsString(bool value) {
    return QString(value ? "true" : "false");
}

Announcement::Announcement(int id) : Record(id) {
}

Announcement::~Announcement() {
}

QString Announcement::insertQuery() {
    return SQL_INSERT_ANNOUNCEMENT.arg(id()).arg(m_people_id).arg(m_house_id).arg(m_settlement_id).arg(m_type).arg(m_rooms_count)
            .arg(m_total_area).arg(m_living_area).arg(m_kitchen_area).arg(boolAsString(m_water_pipes), boolAsString(m_gas), boolAsString(m_sewerage)).arg(m_bathroom_type)
            .arg(m_announcement_text).arg(m_price).arg(m_publication_or_update_time, m_addition_information).arg(m_settlementHouseType);
}

QString Announcement::removeQuery() {
    return SQL_REMOVE_ANNOUNCEMENT.arg(id());
}

QString Announcement::updateQuery() {
    return SQL_UPDATE_ANNOUNCEMENT.arg(m_house_id).arg(m_settlement_id).arg(m_rooms_count).arg(m_total_area).arg(m_living_area)
            .arg(m_kitchen_area).arg(boolAsString(m_water_pipes), boolAsString(m_gas), boolAsString(m_sewerage)).arg(m_bathroom_type).arg(m_announcement_text)
            .arg(m_price).arg(m_publication_or_update_time, m_addition_information).arg(m_settlementHouseType).arg(id());
}

bool Announcement::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_ANNOUNCEMENT &&
            (values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID].toInt()                     != m_people_id ||
             values[DATA_INDEX_ANNOUNCEMENT_HOUSE_ID].toInt()                      != m_house_id ||
             values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID].toInt()                 != m_settlement_id ||
             values[DATA_INDEX_ANNOUNCEMENT_TYPE].toInt()                          != m_type ||
             values[DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT].toInt()                   != m_rooms_count ||
             values[DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA].toFloat()                  != m_total_area ||
             values[DATA_INDEX_ANNOUNCEMENT_LIVING_AREA].toFloat()                 != m_living_area ||
             values[DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA].toFloat()                != m_kitchen_area ||
             values[DATA_INDEX_ANNOUNCEMENT_WATER_PIPES].toBool()                  != m_water_pipes ||
             values[DATA_INDEX_ANNOUNCEMENT_GAS].toBool()                          != m_gas ||
             values[DATA_INDEX_ANNOUNCEMENT_SEWERAGE].toBool()                     != m_sewerage ||
             values[DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE].toInt()                 != m_bathroom_type ||
             values[DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT].toString()          != m_announcement_text ||
             values[DATA_INDEX_ANNOUNCEMENT_PRICE].toInt()                         != m_price ||
             values[DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME].toString() != m_publication_or_update_time ||
             values[DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION].toString()       != m_addition_information ||
             values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE].toInt()         != m_settlementHouseType);
}

void Announcement::update(const std::shared_ptr<QSqlQuery>& query) {
    m_people_id                   = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_PEOPLE_ID);
    m_house_id                    = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_HOUSE_ID);
    m_settlement_id               = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_SETTLEMENT_ID);
    m_type                        = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_TYPE);
    m_rooms_count                 = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_ROOMS_COUNT);
    m_total_area                  = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_TOTAL_AREA);
    m_living_area                 = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_LIVING_AREA);
    m_kitchen_area                = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_KITCHEN_AREA);
    m_water_pipes                 = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_WATER_PIPES);
    m_gas                         = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_GAS);
    m_sewerage                    = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_SEWERAGE);
    m_bathroom_type               = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_BATHROOM_TYPE);
    m_announcement_text           = DbConnection::toString(query, FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT);
    m_price                       = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_PRICE);
    m_publication_or_update_time  = DbConnection::toString(query, FIELD_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME);
    m_addition_information        = DbConnection::toString(query, FIELD_ANNOUNCEMENT_ADDITION_INFORMATION);
    m_settlementHouseType         = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE);

    m_userName           = DbConnection::toString(query, FIELD_ANNOUNCEMENT_PEOPLE_NAME);
    m_phone              = DbConnection::toString(query, FIELD_ANNOUNCEMENT_PEOPLE_PHONE);
    m_email              = DbConnection::toString(query, FIELD_ANNOUNCEMENT_PEOPLE_EMAIL);
    m_houseType          = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_HOUSE_TYPE);
    m_number             = DbConnection::toString(query, FIELD_ANNOUNCEMENT_HOUSE_NUMBER);
    m_housingNumber      = DbConnection::toString(query, FIELD_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER);
    m_landArea           = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_HOUSE_LAND_AREA);
    m_settlementsTypeBuy = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_LOCALITY_BUY_TYPE);
    m_settlementsNameBuy = DbConnection::toString(query, FIELD_ANNOUNCEMENT_LOCALITY_BUY_NAME);
    m_streetsName        = DbConnection::toString(query, FIELD_ANNOUNCEMENT_STREET_NAME);
    m_settlementsType    = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_LOCALITY_TYPE);
    m_settlementsName    = DbConnection::toString(query, FIELD_ANNOUNCEMENT_LOCALITY_NAME);
}

void Announcement::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_people_id                  = values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID].toInt();
        m_house_id                   = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_ID].toInt();
        m_settlement_id              = values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID].toInt();
        m_type                       = values[DATA_INDEX_ANNOUNCEMENT_TYPE].toInt();
        m_rooms_count                = values[DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT].toInt();
        m_total_area                 = values[DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA].toFloat();
        m_living_area                = values[DATA_INDEX_ANNOUNCEMENT_LIVING_AREA].toFloat();
        m_kitchen_area               = values[DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA].toFloat();
        m_water_pipes                = values[DATA_INDEX_ANNOUNCEMENT_WATER_PIPES].toBool();
        m_gas                        = values[DATA_INDEX_ANNOUNCEMENT_GAS].toBool();
        m_sewerage                   = values[DATA_INDEX_ANNOUNCEMENT_SEWERAGE].toBool();
        m_bathroom_type              = values[DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE].toInt();
        m_announcement_text          = values[DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT].toString();
        m_price                      = values[DATA_INDEX_ANNOUNCEMENT_PRICE].toInt();
        m_publication_or_update_time = values[DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME].toString();
        m_addition_information       = values[DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION].toString();
        m_settlementHouseType        = values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE].toInt();

        m_userName           = values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_NAME].toString();
        m_phone              = values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_PHONE].toString();
        m_email              = values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_EMAIL].toString();
        m_houseType          = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_TYPE].toInt();
        m_number             = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_NUMBER].toString();
        m_housingNumber      = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER].toString();
        m_landArea           = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_LAND_AREA].toInt();
        m_settlementsTypeBuy = values[DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_TYPE].toInt();
        m_settlementsNameBuy = values[DATA_INDEX_ANNOUNCEMENT_LOCALITY_BUY_NAME].toString();
        m_streetsName        = values[DATA_INDEX_ANNOUNCEMENT_STREET_NAME].toString();
        m_settlementsType    = values[DATA_INDEX_ANNOUNCEMENT_LOCALITY_TYPE].toInt();
        m_settlementsName    = values[DATA_INDEX_ANNOUNCEMENT_LOCALITY_NAME].toString();
    }
}

QVariant Announcement::value(int role) const {
    switch (role) {
    case announcementPeopleId:                return QVariant(m_people_id);
    case announcementHouseId:                 return QVariant(m_house_id);
    case announcementSettlementId:            return QVariant(m_settlement_id);
    case announcementType:                    return QVariant(m_type);
    case announcementRoomsCount:              return QVariant(m_rooms_count);
    case announcementTotalArea:               return QVariant(m_total_area);
    case announcementLivingArea:              return QVariant(m_living_area);
    case announcementKitchenArea:             return QVariant(m_kitchen_area);
    case announcementWaterPipes:              return QVariant(m_water_pipes);
    case announcementGas:                     return QVariant(m_gas);
    case announcementSewerage:                return QVariant(m_sewerage);
    case announcementBathroomType:            return QVariant(m_bathroom_type);
    case announcementAnnouncementText:        return QVariant(m_announcement_text);
    case announcementPrice:                   return QVariant(m_price);
    case announcementPublicationOrUpdateTime: return QVariant(m_publication_or_update_time);
    case announcementAdditionInformation:     return QVariant(m_addition_information);
    case announcementSettlementHouseType:     return QVariant(m_settlementHouseType);

    case announcementUserName:           return QVariant(m_userName);
    case announcementPhone:              return QVariant(m_phone);
    case announcementEmail:              return QVariant(m_email);
    case announcementHouseType:          return QVariant(m_houseType);
    case announcementNumber:             return QVariant(m_number);
    case announcementHousingNumber:      return QVariant(m_housingNumber);
    case announcementLandArea:           return QVariant(m_landArea);
    case announcementSettlementsTypeBuy: return QVariant(m_settlementsTypeBuy);
    case announcementSettlementsNameBuy: return QVariant(m_settlementsNameBuy);
    case announcementStreetsName:        return QVariant(m_streetsName);
    case announcementSettlementsType:    return QVariant(m_settlementsType);
    case announcementSettlementsName:    return QVariant(m_settlementsName);

    default: return QVariant();
    }
}

QList<QVariant> Announcement::values() const {
    return QList<QVariant>({m_people_id, m_house_id, m_settlement_id, m_type, m_rooms_count, m_total_area, m_living_area, m_kitchen_area,
                            m_water_pipes, m_gas, m_sewerage, m_bathroom_type, m_announcement_text, m_price, m_publication_or_update_time, m_addition_information, m_settlementHouseType,
                            m_userName, m_phone, m_email, m_houseType, m_number, m_housingNumber, m_landArea, m_settlementsTypeBuy, m_settlementsNameBuy, m_streetsName, m_settlementsType, m_settlementsName});
}

void Announcement::print() const {
    qDebug() << FIELD_ANNOUNCEMENT_PEOPLE_ID << ": " << m_people_id << "; " << FIELD_ANNOUNCEMENT_TYPE << ": " << m_type << FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT << ": " << m_announcement_text;
}

int Announcement::generateId(DbConnection& db) {
    int id;
    return db.getId(TABLE_ANNOUNCEMENTS, id) ? id : -1;
}

QHash<int, QByteArray> Announcement::roleNames() {
    QHash<int, QByteArray> roles;
    roles[announcementPeopleId]                = ROLE_ANNOUNCEMENT_PEOPLE_ID;
    roles[announcementHouseId]                 = ROLE_ANNOUNCEMENT_HOUSE_ID;
    roles[announcementSettlementId]            = ROLE_ANNOUNCEMENT_SETTLEMENT_ID;
    roles[announcementType]                    = ROLE_ANNOUNCEMENT_TYPE;
    roles[announcementRoomsCount]              = ROLE_ANNOUNCEMENT_ROOMS_COUNT;
    roles[announcementTotalArea]               = ROLE_ANNOUNCEMENT_TOTAL_AREA;
    roles[announcementLivingArea]              = ROLE_ANNOUNCEMENT_LIVING_AREA;
    roles[announcementKitchenArea]             = ROLE_ANNOUNCEMENT_KITCHEN_AREA;
    roles[announcementWaterPipes]              = ROLE_ANNOUNCEMENT_WATER_PIPES;
    roles[announcementGas]                     = ROLE_ANNOUNCEMENT_GAS;
    roles[announcementSewerage]                = ROLE_ANNOUNCEMENT_SEWERAGE;
    roles[announcementBathroomType]            = ROLE_ANNOUNCEMENT_BATHROOM_TYPE;
    roles[announcementAnnouncementText]        = ROLE_ANNOUNCEMENT_ANNOUNCEMENT_TEXT;
    roles[announcementPrice]                   = ROLE_ANNOUNCEMENT_PRICE;
    roles[announcementPublicationOrUpdateTime] = ROLE_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME;
    roles[announcementAdditionInformation]     = ROLE_ANNOUNCEMENT_ADDITION_INFORMATION;
    roles[announcementSettlementHouseType]     = ROLE_ANNOUNCEMENT_SETTLEMENT_HOUSE_TYPE;

    roles[announcementUserName]           = ROLE_ANNOUNCEMENT_PEOPLE_NAME;
    roles[announcementPhone]              = ROLE_ANNOUNCEMENT_PEOPLE_PHONE;
    roles[announcementEmail]              = ROLE_ANNOUNCEMENT_PEOPLE_EMAIL;
    roles[announcementHouseType]          = ROLE_ANNOUNCEMENT_HOUSE_TYPE;
    roles[announcementNumber]             = ROLE_ANNOUNCEMENT_HOUSE_NUMBER;
    roles[announcementHousingNumber]      = ROLE_ANNOUNCEMENT_HOUSE_HOUSING_NUMBER;
    roles[announcementLandArea]           = ROLE_ANNOUNCEMENT_HOUSE_LAND_AREA;
    roles[announcementSettlementsTypeBuy] = ROLE_ANNOUNCEMENT_LOCALITY_BUY_TYPE;
    roles[announcementSettlementsNameBuy] = ROLE_ANNOUNCEMENT_LOCALITY_BUY_NAME;
    roles[announcementStreetsName]        = ROLE_ANNOUNCEMENT_STREET_NAME;
    roles[announcementSettlementsType]    = ROLE_ANNOUNCEMENT_LOCALITY_TYPE;
    roles[announcementSettlementsName]    = ROLE_ANNOUNCEMENT_LOCALITY_NAME;
    return roles;
}

QString Announcement::selectQuery(int id) {
    return SQL_SELECT_ANNOUNCEMENTS.arg(id);
}
