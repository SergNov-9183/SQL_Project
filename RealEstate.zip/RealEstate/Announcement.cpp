#include "Announcement.h"

#include <QDebug>

#include "Definitions.h"

enum AnnouncementRoles {
    announcementPeopleId                = Qt::DisplayRole,
    announcementHouseId                 = Qt::UserRole + 1,
    announcementSettlementId            = Qt::UserRole + 2,
    announcementType                    = Qt::UserRole + 3,
    announcementRoomsCount              = Qt::UserRole + 4,
    announcementTotalArea               = Qt::UserRole + 5,
    announcementLivingArea              = Qt::UserRole + 6,
    announcementKitchenArea             = Qt::UserRole + 7,
    announcementWaterPipes              = Qt::UserRole + 8,
    announcementGas                     = Qt::UserRole + 9,
    announcementSewerage                = Qt::UserRole + 10,
    announcementBathroomType            = Qt::UserRole + 11,
    announcementAnnouncementText        = Qt::UserRole + 12,
    announcementPrice                   = Qt::UserRole + 13,
    announcementPublicationOrUpdateTime = Qt::UserRole + 14,
    announcementAdditionInformation     = Qt::UserRole + 15
};


Announcement::Announcement(int id) : Record(id) {
}

Announcement::~Announcement() {
}

QString Announcement::insertQuery() {
    return SQL_INSERT_ANNOUNCEMENT.arg(id()).arg(m_people_id).arg(m_house_id).arg(m_settlement_id).arg(m_type).arg(m_rooms_count)
            .arg(m_total_area).arg(m_living_area).arg(m_kitchen_area).arg(m_water_pipes).arg(m_gas).arg(m_sewerage).arg(m_bathroom_type)
            .arg(m_announcement_text).arg(m_price).arg(m_publication_or_update_time, m_addition_information);
}

QString Announcement::removeQuery() {
    return SQL_REMOVE_ANNOUNCEMENT.arg(id());
}

QString Announcement::updateQuery() {
    return SQL_UPDATE_ANNOUNCEMENT.arg(m_house_id).arg(m_settlement_id).arg(m_rooms_count).arg(m_total_area).arg(m_living_area)
            .arg(m_kitchen_area).arg(m_water_pipes).arg(m_gas).arg(m_sewerage).arg(m_bathroom_type).arg(m_announcement_text)
            .arg(m_price).arg(m_publication_or_update_time, m_addition_information).arg(id());
}

bool Announcement::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_ANNOUNCEMENT &&
            (values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID].toInt()                     != m_people_id ||
             values[DATA_INDEX_ANNOUNCEMENT_HOUSE_ID].toInt()                      != m_house_id ||
             values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID].toInt()                 != m_settlement_id ||
             values[DATA_INDEX_ANNOUNCEMENT_TYPE].toInt()                          != m_type ||
             values[DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT].toInt()                   != m_rooms_count ||
             values[DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA].toFloat()                  != m_total_area ||
             values[DATA_INDEX_ANNOUNCEMENT_LIVING_AREA].toFloat()                 != m_living_area ||
             values[DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA].toFloat()                != m_kitchen_area ||
             values[DATA_INDEX_ANNOUNCEMENT_WATER_PIPES].toBool()                  != m_water_pipes ||
             values[DATA_INDEX_ANNOUNCEMENT_GAS].toBool()                          != m_gas ||
             values[DATA_INDEX_ANNOUNCEMENT_SEWERAGE].toBool()                     != m_sewerage ||
             values[DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE].toInt()                 != m_bathroom_type ||
             values[DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT].toString()          != m_announcement_text ||
             values[DATA_INDEX_ANNOUNCEMENT_PRICE].toInt()                         != m_price ||
             values[DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME].toString() != m_publication_or_update_time ||
             values[DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION].toString()       != m_addition_information);
}

void Announcement::update(const std::shared_ptr<QSqlQuery>& query) {
    m_people_id                   = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_PEOPLE_ID);
    m_house_id                    = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_HOUSE_ID);
    m_settlement_id               = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_SETTLEMENT_ID);
    m_type                        = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_TYPE);
    m_rooms_count                 = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_ROOMS_COUNT);
    m_total_area                  = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_TOTAL_AREA);
    m_living_area                 = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_LIVING_AREA);
    m_kitchen_area                = DbConnection::toFloat(query, FIELD_ANNOUNCEMENT_KITCHEN_AREA);
    m_water_pipes                 = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_WATER_PIPES);
    m_gas                         = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_GAS);
    m_sewerage                    = DbConnection::toBool(query, FIELD_ANNOUNCEMENT_SEWERAGE);
    m_bathroom_type               = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_BATHROOM_TYPE);
    m_announcement_text           = DbConnection::toString(query, FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT);
    m_price                       = DbConnection::toInt(query, FIELD_ANNOUNCEMENT_PRICE);
    m_publication_or_update_time  = DbConnection::toString(query, FIELD_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME);
    m_addition_information        = DbConnection::toString(query, FIELD_ANNOUNCEMENT_ADDITION_INFORMATION);
}

void Announcement::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_people_id                  = values[DATA_INDEX_ANNOUNCEMENT_PEOPLE_ID].toInt();
        m_house_id                   = values[DATA_INDEX_ANNOUNCEMENT_HOUSE_ID].toInt();
        m_settlement_id              = values[DATA_INDEX_ANNOUNCEMENT_SETTLEMENT_ID].toInt();
        m_type                       = values[DATA_INDEX_ANNOUNCEMENT_TYPE].toInt();
        m_rooms_count                = values[DATA_INDEX_ANNOUNCEMENT_ROOMS_COUNT].toInt();
        m_total_area                 = values[DATA_INDEX_ANNOUNCEMENT_TOTAL_AREA].toFloat();
        m_living_area                = values[DATA_INDEX_ANNOUNCEMENT_LIVING_AREA].toFloat();
        m_kitchen_area               = values[DATA_INDEX_ANNOUNCEMENT_KITCHEN_AREA].toFloat();
        m_water_pipes                = values[DATA_INDEX_ANNOUNCEMENT_WATER_PIPES].toBool();
        m_gas                        = values[DATA_INDEX_ANNOUNCEMENT_GAS].toBool();
        m_sewerage                   = values[DATA_INDEX_ANNOUNCEMENT_SEWERAGE].toBool();
        m_bathroom_type              = values[DATA_INDEX_ANNOUNCEMENT_BATHROOM_TYPE].toInt();
        m_announcement_text          = values[DATA_INDEX_ANNOUNCEMENT_ANNOUNCEMENT_TEXT].toString();
        m_price                      = values[DATA_INDEX_ANNOUNCEMENT_PRICE].toInt();
        m_publication_or_update_time = values[DATA_INDEX_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME].toString();
        m_addition_information       = values[DATA_INDEX_ANNOUNCEMENT_ADDITION_INFORMATION].toString();
    }
}

QVariant Announcement::value(int role) const {
    switch (role) {
    case announcementPeopleId:                return QVariant(m_people_id);
    case announcementHouseId:                 return QVariant(m_house_id);
    case announcementSettlementId:            return QVariant(m_settlement_id);
    case announcementType:                    return QVariant(m_type);
    case announcementRoomsCount:              return QVariant(m_rooms_count);
    case announcementTotalArea:               return QVariant(m_total_area);
    case announcementLivingArea:              return QVariant(m_living_area);
    case announcementKitchenArea:             return QVariant(m_kitchen_area);
    case announcementWaterPipes:              return QVariant(m_water_pipes);
    case announcementGas:                     return QVariant(m_gas);
    case announcementSewerage:                return QVariant(m_sewerage);
    case announcementBathroomType:            return QVariant(m_bathroom_type);
    case announcementAnnouncementText:        return QVariant(m_announcement_text);
    case announcementPrice:                   return QVariant(m_price);
    case announcementPublicationOrUpdateTime: return QVariant(m_publication_or_update_time);
    case announcementAdditionInformation:     return QVariant(m_addition_information);
    default:                                  return QVariant();
    }
}

QList<QVariant> Announcement::values() const {
    return QList<QVariant>({m_people_id, m_house_id, m_settlement_id, m_type, m_rooms_count, m_total_area, m_living_area, m_kitchen_area,
                            m_water_pipes, m_gas, m_sewerage, m_bathroom_type, m_announcement_text, m_price, m_publication_or_update_time, m_addition_information});
}

void Announcement::print() const {
    qDebug() << FIELD_ANNOUNCEMENT_PEOPLE_ID << ": " << m_people_id << "; " << FIELD_ANNOUNCEMENT_TYPE << ": " << m_type << FIELD_ANNOUNCEMENT_ANNOUNCEMENT_TEXT << ": " << m_announcement_text;
}

int Announcement::generateId(DbConnection& db) {
    int id;
    return db.getId(TABLE_ANNOUNCEMENTS, id) ? id : -1;
}

QHash<int, QByteArray> Announcement::roleNames() {
    QHash<int, QByteArray> roles;
    roles[announcementPeopleId]                = ROLE_ANNOUNCEMENT_PEOPLE_ID;
    roles[announcementHouseId]                 = ROLE_ANNOUNCEMENT_HOUSE_ID;
    roles[announcementSettlementId]            = ROLE_ANNOUNCEMENT_SETTLEMENT_ID;
    roles[announcementType]                    = ROLE_ANNOUNCEMENT_TYPE;
    roles[announcementRoomsCount]              = ROLE_ANNOUNCEMENT_ROOMS_COUNT;
    roles[announcementTotalArea]               = ROLE_ANNOUNCEMENT_TOTAL_AREA;
    roles[announcementLivingArea]              = ROLE_ANNOUNCEMENT_LIVING_AREA;
    roles[announcementKitchenArea]             = ROLE_ANNOUNCEMENT_KITCHEN_AREA;
    roles[announcementWaterPipes]              = ROLE_ANNOUNCEMENT_WATER_PIPES;
    roles[announcementGas]                     = ROLE_ANNOUNCEMENT_GAS;
    roles[announcementSewerage]                = ROLE_ANNOUNCEMENT_SEWERAGE;
    roles[announcementBathroomType]            = ROLE_ANNOUNCEMENT_BATHROOM_TYPE;
    roles[announcementAnnouncementText]        = ROLE_ANNOUNCEMENT_ANNOUNCEMENT_TEXT;
    roles[announcementPrice]                   = ROLE_ANNOUNCEMENT_PRICE;
    roles[announcementPublicationOrUpdateTime] = ROLE_ANNOUNCEMENT_PUBLICATION_OR_UPDATE_TIME;
    roles[announcementAdditionInformation]     = ROLE_ANNOUNCEMENT_ADDITION_INFORMATION;
    return roles;
}

QString Announcement::selectQuery(int id) {
    return SQL_SELECT_ANNOUNCEMENTS.arg(id);
}
