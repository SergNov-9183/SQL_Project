#include "House.h"

#include <QDebug>

#include "Definitions.h"

enum LocalityRoles {
    houseStreetId      = Qt::DisplayRole,
    houseType          = Qt::UserRole + 1,
    houseNumber        = Qt::UserRole + 2,
    houseHousingNumber = Qt::UserRole + 3,
    houseLandArea      = Qt::UserRole + 4
};

House::House(int id, const DbConnection& db) : Record(id, db) {
}

House::~House() {
}

QString House::insertQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::HouseRecord, SQLType::Insert);
    return sql.arg(id()).arg(m_street_id).arg(m_type).arg(m_number, m_housing_number).arg(m_land_area);
}

QString House::removeQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::HouseRecord, SQLType::Remove);
    return sql.arg(id());
}

QString House::updateQuery() {
    const auto& sql = sqlManager::sql(m_db.dbType(), RecordType::HouseRecord, SQLType::Update);
    return sql.arg(m_type).arg(m_number, m_housing_number).arg(m_land_area).arg(id());
}

bool House::dataChanged(const QList<QVariant>& values) const {
    return values.size() == DATA_COUNT_HOUSE &&
           (values[DATA_INDEX_HOUSE_STREET_ID].toInt()         != m_street_id ||
            values[DATA_INDEX_HOUSE_TYPE].toInt()              != m_type ||
            values[DATA_INDEX_HOUSE_NUMBER].toString()         != m_number ||
            values[DATA_INDEX_HOUSE_HOUSING_NUMBER].toString() != m_housing_number ||
            values[DATA_INDEX_HOUSE_LAND_AREA].toInt()         != m_land_area);
}

void House::update(const std::shared_ptr<QSqlQuery>& query) {
    m_street_id      = DbConnection::toInt(query, FIELD_HOUSE_STREET_ID);
    m_type           = DbConnection::toInt(query, FIELD_HOUSE_TYPE);
    m_number         = DbConnection::toString(query, FIELD_HOUSE_NUMBER);
    m_housing_number = DbConnection::toString(query, FIELD_HOUSE_HOUSING_NUMBER);
    m_land_area      = DbConnection::toInt(query, FIELD_HOUSE_LAND_AREA);

}

void House::update(const QList<QVariant>& values) {
    if (dataChanged(values)) {
        m_street_id      = values[DATA_INDEX_HOUSE_STREET_ID].toInt();
        m_type           = values[DATA_INDEX_HOUSE_TYPE].toInt();
        m_number         = values[DATA_INDEX_HOUSE_NUMBER].toString();
        m_housing_number = values[DATA_INDEX_HOUSE_HOUSING_NUMBER].toString();
        m_land_area      = values[DATA_INDEX_HOUSE_LAND_AREA].toInt();
    }
}

QVariant House::value(int role) const {
    switch (role) {
    case houseStreetId:      return QVariant(m_street_id);
    case houseType:          return QVariant(m_type);
    case houseNumber:        return QVariant(m_number);
    case houseHousingNumber: return QVariant(m_housing_number);
    case houseLandArea:      return QVariant(m_land_area);
    default:                 return QVariant();
    }
}

QList<QVariant> House::values() const {
    return QList<QVariant>({m_street_id, m_type, m_number, m_housing_number, m_land_area});
}

void House::print() const {
    qDebug() << FIELD_HOUSE_TYPE << ": " << m_type << "; " << FIELD_HOUSE_NUMBER << ": " << m_number;
}

int House::generateId(DbConnection& db) {
    int id;
    return db.getId(TABLE_HOUSES, id) ? id : -1;
}

QHash<int, QByteArray> House::roleNames() {
    QHash<int, QByteArray> roles;
    roles[houseStreetId]      = ROLE_HOUSES_STREET_ID;
    roles[houseType]          = ROLE_HOUSES_TYPE;
    roles[houseNumber]        = ROLE_HOUSES_NUMBER;
    roles[houseHousingNumber] = ROLE_HOUSES_HOUSING_NUMBER;
    roles[houseLandArea]      = ROLE_HOUSES_LAND_AREA;
    return roles;
}
