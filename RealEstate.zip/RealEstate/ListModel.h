#ifndef LISTMODEL_H
#define LISTMODEL_H

#include <QAbstractListModel>

#include "DbConnection.h"
#include "Record.h"

class ListModel : public QAbstractListModel {

    Q_OBJECT

public:
    explicit ListModel(RecordType recordType, DbConnection& db, QObject *parent = nullptr);

    void clear();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE void reload(int id = -1);
    Q_INVOKABLE void append(const QList<QVariant>& values, int id = 0);
    Q_INVOKABLE void remove(int index);
    Q_INVOKABLE void update(const QList<QVariant>& values, int index);
    Q_INVOKABLE QList<QVariant> values(int index);
    Q_INVOKABLE int idForIndex(int index);

private:
    RecordType m_recordType;
    DbConnection& m_db;
    QList<Record*> m_list; // непосредственно данные

    bool indexIsValid(int index) const;
};

#endif // LISTMODEL_H
