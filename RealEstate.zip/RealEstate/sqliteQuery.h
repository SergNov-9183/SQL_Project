#ifndef SQLITEQUERY_H
#define SQLITEQUERY_H

#include "SqlManager.h"

namespace sqliteQuery {
    const QString& dbType();
    const QString& sql(RecordType recordType, SQLType sqlType);
    const QString& sqlUser(SQLUser sqlUser);
    const QString& sqlInfo(SQLInfo sqlInfo);
    void idGenerator(const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId);
    QList<QString> clearSqls();
};

#endif // SQLITEQUERY_H
