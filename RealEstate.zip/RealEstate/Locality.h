#ifndef LOCALITY_H
#define LOCALITY_H

#include "Record.h"

class Locality : public Record {

public:
    Locality(int id, const DbConnection& db);
    ~Locality();

    QString insertQuery() override;
    QString removeQuery() override;
    QString updateQuery() override;

    bool dataChanged(const QList<QVariant>& values) const override;
    void update(const std::shared_ptr<QSqlQuery>& query) override;
    void update(const QList<QVariant>& values) override;
    QVariant value(int role = Qt::DisplayRole) const override;
    QList<QVariant> values() const override;

    void print() const override;

    static QHash<int, QByteArray> roleNames();

private:
    int m_type;
    QString m_name;
};

#endif // LOCALITY_H
