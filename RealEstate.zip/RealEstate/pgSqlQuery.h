﻿#ifndef PGSQLQUERY_H
#define PGSQLQUERY_H

#include "SqlManager.h"

enum class DbUserQuery {
    Get = 0,
    Create,
    Privilegies
};

namespace pgSqlQuery {
    const QString& dbType();
    const QString& sql(RecordType recordType, SQLType sqlType);
    const QString& sqlUser(SQLUser sqlUser);
    const QString& sqlInfo(SQLInfo sqlInfo);
    void idGenerator(const QString& tableName, QString& sqlGetId, QString& sqlSetId, QString& fieldId);
    QList<QString> clearSqls();
    QList<QString> dropDatabaseQueries();
    const QString& createDatabaseQuery();
    const QString& masterTable();
    const QString& createTabliesScript();
    const QString& dbUserQuery(DbUserQuery dbUserQuery);
};

#endif // PGSQLQUERY_H
