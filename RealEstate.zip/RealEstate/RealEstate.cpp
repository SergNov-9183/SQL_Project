#include "RealEstate.h"

#include <QQuickView>
#include <QQmlContext>
#include <QtQml>

#include "Config.h"

RealEstate::RealEstate(QWidget *parent)	: QMainWindow(parent) {
    // создаем модель отображения для Qml содежимого окна
    m_viewModel = new  ViewModel();

    // создаем контейнер для Qml
    QQuickView *view = new QQuickView();
    // устанавливаем главную контекстную модель-представление для Qml
    view->rootContext()->setContextObject(m_viewModel);
    // создаем Widget контейнер для Qml
    QWidget *container = QWidget::createWindowContainer(view, this);
    // устанавливаем режим изменения размера для Qml: принять размеры главного Widget окна
    view->setResizeMode(QQuickView::SizeRootObjectToView);
    // говорим, что Qml может плучать фокус
    container->setFocusPolicy(Qt::TabFocus);
    // Регистрируем qml файл через указание его пути.
    qmlRegisterSingletonType(QUrl("qrc:///Utils.qml"), "Utils", 1, 0, "Utils");
    // назначаем Qml контейнеру содержимое
    view->setSource(QUrl(QStringLiteral("qrc:///main.qml")));
    setCentralWidget(container);
    resize(1024, 768);
    setMinimumSize(1024, 768);
    setWindowTitle(tr("Недвижимость"));
}

RealEstate::~RealEstate() {
    m_viewModel->prepareForDeletion();
    m_viewModel->deleteLater();
}
