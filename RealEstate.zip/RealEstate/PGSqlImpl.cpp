#include "PGSqlImpl.h"

#include <QDebug>

#include "DbConnection.h"
#include "DBUtils.h"
#include "pgSqlScript.h"

namespace {
    // master table
    const QString DB_MASTER       = "postgres";

    // generate id
    const QString FIELD_GET_ID = "nextval";
    const QString QUERY_GET_ID = "select nextval('%1_ID_seq'::regclass)";

    // clear database
    const QString QUERY_CLEAR_LOCALITIES = "delete from settlements";
    const QString QUERY_CLEAR_PEOPLE     = "delete from people";

    // drop database
    const QString QUERY_DROP_DB_1 = "update pg_database set datallowconn = 'false' where datname = '%1';";
    const QString QUERY_DROP_DB_2 = "select pg_terminate_backend(pg_stat_activity.pid) from pg_stat_activity where pg_stat_activity.datname = '%1' and pid <> pg_backend_pid();";
    const QString QUERY_DROP_DB_3 = "drop database %1;";

    // create database
    const QString QUERY_CREATE_DB = "CREATE DATABASE %1;";

    // create database user
    const QString QUERY_DB_USER_GET        = "SELECT usename FROM pg_user where usename='%1';";
    const QString QUERY_DB_USER_CREATE     = "CREATE USER %1 WITH PASSWORD '%2';";
    const QString QUERY_DB_USER_PRIVILEGES = "GRANT ALL PRIVILEGES ON DATABASE %1 to %2;";
}

bool PGSqlImpl::getId(DbConnection* db, const QString& tableName, int& id) {
    if (auto query = db->exec(QUERY_GET_ID.arg(tableName))) {
        if (query->next()) {
            id = toInt(query, FIELD_GET_ID);
            return true;
        }
    }
    id = -1;
    return false;
}

QList<QString> PGSqlImpl::clearQueries() {
    return QList<QString>({QUERY_CLEAR_LOCALITIES, QUERY_CLEAR_PEOPLE});
}

bool PGSqlImpl::createDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& connectionUser, const QString& connectionPassword, const QString& masterUser, const QString& masterPassword) {
    qDebug() << "_____02";
    if (db->open(ip, DB_MASTER, masterUser, masterPassword)) {
        auto createDatabaseUser = [db, &databaseName, &connectionUser, &connectionPassword](){
            if (auto queryGetUser = db->exec(QUERY_DB_USER_GET.arg(connectionUser))) {
                if (queryGetUser->next() ? true : db->call(QUERY_DB_USER_CREATE.arg(connectionUser, connectionPassword))) {
                    return db->call(QUERY_DB_USER_PRIVILEGES.arg(databaseName, connectionUser));
                }
            }
            return false;
        };
        auto result = db->call(QUERY_CREATE_DB.arg(databaseName)) && createDatabaseUser();
        db->close();
        int id;
        result = result && db->open(ip, databaseName, connectionUser, connectionPassword) &&
                 db->call(PGSQL_SQL_CREATE_TABLES_SCRIPT.join('\n'));
        db->close();
        result = result && db->open(ip, databaseName, connectionUser, connectionPassword) &&
                 db->addUser(id, "", connectionUser, "", connectionUser, "", connectionPassword);
        db->close();
        return result;
    }
    return false;
}

bool PGSqlImpl::dropDatabase(DbConnection* db, const QString& ip, const QString& databaseName, const QString& masterUser, const QString& masterPassword) {
    if (db->open(ip, DB_MASTER, masterUser, masterPassword)) {
        auto result = db->call(QUERY_DROP_DB_1.arg(databaseName)) &&
                      db->call(QUERY_DROP_DB_2.arg(databaseName)) &&
                      db->call(QUERY_DROP_DB_3.arg(databaseName));
        db->close();
        return result;
    }
    return false;
}
