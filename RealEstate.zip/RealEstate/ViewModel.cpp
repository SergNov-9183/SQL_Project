#include "ViewModel.h"

#include "Config.h"

ViewModel::ViewModel(QObject* parent) : QObject(parent) {
    m_db            = new DbConnection(this);
    m_userModel     = new UserModel(*m_db, this);
    m_localities    = new ListModel(RecordType::LocalityRecord, *m_db, this);
    m_streets       = new ListModel(RecordType::StreetRecord, *m_db, this);
    m_houses        = new ListModel(RecordType::HouseRecord, *m_db, this);
    m_announcements = new ListModel(RecordType::AnnouncementRecord, *m_db, this);

    QObject::connect(m_db, &DbConnection::connectionChanged, this, &ViewModel::connectionChanged);

    loadConfig(*m_db);
}

void ViewModel::prepareForDeletion() const {
    saveConfig(*m_db);
    clearListModel();
    m_db->close();
}

void ViewModel::clearListModel() const {
    m_announcements->clear();
    m_houses->clear();
    m_streets->clear();
    m_localities->clear();
}

void ViewModel::connectionChanged() {
    clearListModel();
}

QObject* ViewModel::db() const {
    return m_db;
}

QObject* ViewModel::userModel() const {
    return m_userModel;
}

QAbstractListModel* ViewModel::localities() const {
    return m_localities;
}

QAbstractListModel* ViewModel::streets() const {
    return m_streets;
}

QAbstractListModel* ViewModel::houses() const {
    return m_houses;
}

QAbstractListModel* ViewModel::announcements() const {
    return m_announcements;
}

