#include "ViewModel.h"

#include <QDebug>
#include <QFile>
#include <QProcess>

#include "Config.h"
#include "Definitions.h"

ViewModel::ViewModel(QObject* parent) : QObject(parent) {
    m_db            = new DbConnection(this);
    m_userModel     = new UserModel(*m_db, this);
    m_localities    = new ListModel(Table::localities, *m_db, this);
    m_streets       = new ListModel(Table::streets, *m_db, this);
    m_houses        = new ListModel(Table::houses, *m_db, this);
    m_announcements = new ListModel(Table::announcement, *m_db, this);

    QObject::connect(m_db, &DbConnection::connectionChanged, this, &ViewModel::connectionChanged);

    loadConfig(*m_db);
}

void ViewModel::prepareForDeletion() const {
    saveConfig(*m_db);
    clearListModel();
    m_db->close();
}

void ViewModel::clearListModel() const {
    m_announcements->clear();
    m_houses->clear();
    m_streets->clear();
    m_localities->clear();
}

QList<QVariant> ViewModel::houseInfo(int id) {
    if (auto query = m_db->exec((*m_db)[Query::houseInfo].arg(id))) {
        if (query->next()) {
            return QList<QVariant>({
                        toInt(query, FIELD_ADS_GET_HOUSE_INFO_TYPE),
                        toString(query, FIELD_ADS_GET_HOUSE_INFO_NUMBER),
                        toString(query, FIELD_ADS_GET_HOUSE_INFO_HOUSING_NUMBER),
                        toInt(query, FIELD_ADS_GET_HOUSE_INFO_LAND_AREA),
                        toString(query, FIELD_ADS_GET_HOUSE_STREET_NAME),
                        toString(query, FIELD_ADS_GET_HOUSE_LOCALITY_NAME),
                        toInt(query, FIELD_ADS_GET_HOUSE_LOCALITY_TYPE)});
        }
    }
    return QList<QVariant>();
}

QList<QVariant> ViewModel::localityInfo(int id) {
    if (auto query = m_db->exec((*m_db)[Query::localityInfo].arg(id).arg(id))) {
        if (query->next()) {
            return QList<QVariant>({
                        toInt(query, FIELD_ADS_GET_LOCALITY_LOCALITY_TYPE),
                        toString(query, FIELD_ADS_GET_LOCALITY_LOCALITY_NAME)});
        }
    }
    return QList<QVariant>();
}

void ViewModel::clearDatabase() {
    clearListModel();
    m_db->clearDatabase();
}

void ViewModel::connectionChanged() {
    clearListModel();
}

QObject* ViewModel::db() const {
    return m_db;
}

QObject* ViewModel::userModel() const {
    return m_userModel;
}

QAbstractListModel* ViewModel::localities() const {
    return m_localities;
}

QAbstractListModel* ViewModel::streets() const {
    return m_streets;
}

QAbstractListModel* ViewModel::houses() const {
    return m_houses;
}

QAbstractListModel* ViewModel::announcements() const {
    return m_announcements;
}
