#include "ListModel.h"

#include <QDebug>

#include "Definitions.h"

ListModel::ListModel(RecordType recordType, DbConnection &db, QObject *parent) : QAbstractListModel(parent), m_recordType(recordType), m_db(db) {
}

void ListModel::clear() {
    while (m_list.size() > 0) {
        beginRemoveRows(QModelIndex(), 0, 0);
        delete m_list[0];
        m_list.removeAt(0);
        endRemoveRows();
    }
}

int ListModel::rowCount(const QModelIndex&) const {
    return m_list.size();
}

QVariant ListModel::data(const QModelIndex& index, int role) const {
    return indexIsValid(index.row()) ? m_list.at(index.row())->value(role) : QVariant();
}

QHash<int, QByteArray> ListModel::roleNames() const {
    return Record::roleNames(m_recordType);
}

void ListModel::reload(int id) {
    clear();
    if (auto query = m_db.execQuery(Record::selectQuery(m_recordType, id))) {
        while (query->next()) {
            auto item = Record::get(m_recordType, m_db.toInt(query, FIELD_ID));
            item->update(query);
            item->print();
            beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
            m_list.append(item);
            endInsertRows();
         }
    }
    if (m_recordType == RecordType::LocalityRecord) {
        auto item = Record::get(m_recordType, 1);
        item->update({1, QString("n1")});
        item->print();
        beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
        m_list.append(item);
        endInsertRows();
        item = Record::get(m_recordType, 2);
        item->update({2, QString("n2")});
        item->print();
        beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
        m_list.append(item);
        endInsertRows();
        item = Record::get(m_recordType, 3);
        item->update({3, QString("n3")});
        item->print();
        beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
        m_list.append(item);
        endInsertRows();
    }
}

void ListModel::append(const QList<QVariant>& values, int id) {
    qDebug() << "Append values: " << values;
    auto item = Record::get(m_recordType, id < 1 ? Record::generateId(m_db, m_recordType) : id);
    item->update(values);
    if (id < 1) {
        m_db.save(item->insertQuery());
    }
    beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
    m_list.append(item);
    endInsertRows();
}

void ListModel::remove(int index) {
    qDebug() << "Remove record with index: " << index;
    if (indexIsValid(index)) {
        beginRemoveRows(QModelIndex(), index, index);
        auto item = m_list[index];
        auto id   = item->id();
        if (id > 0) {
            m_db.save(item->removeQuery());
        }
        delete m_list[index];
        m_list.removeAt(index);
        endRemoveRows();
        qDebug() << "Record removed for ID: " << id;
    }
    else qDebug() << "Error index for removing data: " << index;
}

void ListModel::update(const QList<QVariant>& values, const int index) {
    qDebug() << "Update values (" << values << ") for index: " << index;
    if(indexIsValid(index)) {
       auto& item = m_list[index];
       if (item->dataChanged(values)) {
           item->update(values);
           m_db.save(item->updateQuery());
           auto modelIndex = createIndex(index, 0);
           emit dataChanged(modelIndex, modelIndex);
           qDebug() << "Record changed for ID: " << item->id();
       }
    }
    else qDebug() << "Error index for updating data: " << index;
}

QList<QVariant> ListModel::values(const int index) {
    if (indexIsValid(index)) {
        auto& item = m_list[index];
        return item->values();
    }
    return QList<QVariant>();
}

int ListModel::idForIndex(const int index) {
    qDebug() << "Read ID for index: " << index;
    if (indexIsValid(index)) {
        auto& item = m_list[index];
        qDebug() << "Read ID (" << item->id() << ") for index: " << index;
        return item->id();
    }
    return -1;
}

bool ListModel::indexIsValid(int index) const {
    return index >= 0 && index < m_list.size();
}
