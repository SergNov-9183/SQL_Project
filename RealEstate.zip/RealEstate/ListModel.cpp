#include "ListModel.h"

#include <QDebug>

#include "Definitions.h"

ListModel::ListModel(RecordType recordType, DbConnection &db, QObject *parent) : QAbstractListModel(parent), m_recordType(recordType), m_db(db) {
}

void ListModel::clear() {
    while (m_list.size() > 0) {
        beginRemoveRows(QModelIndex(), 0, 0);
        delete m_list[0];
        m_list.removeAt(0);
        endRemoveRows();
    }
}

int ListModel::rowCount(const QModelIndex&) const {
    return m_list.size();
}

QVariant ListModel::data(const QModelIndex& index, int role) const {
    return indexIsValid(index.row()) ? m_list.at(index.row())->value(role) : QVariant();
}

QHash<int, QByteArray> ListModel::roleNames() const {
    return Record::roleNames(m_recordType);
}

void ListModel::reload(const QString& findString, int id, int userId) {
    qDebug() << "reload: findString = " << findString << ", id = " << id << ", userId = " << userId;
    clear();
    if (auto query = m_db.execQuery(sqlManager::selectQuery(m_db.dbType(), m_recordType, findString, id, userId))) {
        while (query->next()) {
            auto item = Record::get(m_recordType, m_db.toInt(query, FIELD_ID), m_db);
            item->update(query);
            item->print();
            beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
            m_list.append(item);
            endInsertRows();
         }
    }
}

void ListModel::append(const QList<QVariant>& values, int id) {
    qDebug() << "Append values: " << values;
    auto item = Record::get(m_recordType, id < 1 ? Record::generateId(m_db, m_recordType) : id, m_db);
    item->update(values);
    if (id < 1) {
        m_db.execute(item->insertQuery());
    }
    beginInsertRows(QModelIndex(), m_list.size(), m_list.size());
    m_list.append(item);
    endInsertRows();
}

void ListModel::remove(int index) {
    qDebug() << "Remove record with index: " << index;
    if (indexIsValid(index)) {
        beginRemoveRows(QModelIndex(), index, index);
        auto item = m_list[index];
        auto id   = item->id();
        if (id > 0) {
            m_db.execute(item->removeQuery());
        }
        delete m_list[index];
        m_list.removeAt(index);
        endRemoveRows();
        qDebug() << "Record removed for ID: " << id;
    }
    else qDebug() << "Error index for removing data: " << index;
}

void ListModel::update(const QList<QVariant>& values, int index) {
    qDebug() << "Update values (" << values << ") for index: " << index;
    if(indexIsValid(index)) {
       auto& item = m_list[index];
       if (item->dataChanged(values)) {
           qDebug() << "Data changed for index: " << index;
           item->update(values);
           m_db.execute(item->updateQuery());
           auto modelIndex = createIndex(index, 0);
           emit dataChanged(modelIndex, modelIndex);
           qDebug() << "Record changed for ID: " << item->id();
       }
    }
    else qDebug() << "Error index for updating data: " << index;
}

QList<QVariant> ListModel::values(int index) {
    if (indexIsValid(index)) {
        auto& item = m_list[index];
        return item->values();
    }
    return QList<QVariant>();
}

int ListModel::idForIndex(int index) {
    qDebug() << "Read ID for index: " << index;
    if (indexIsValid(index)) {
        auto& item = m_list[index];
        qDebug() << "Read ID (" << item->id() << ") for index: " << index;
        return item->id();
    }
    return -1;
}

bool ListModel::indexIsValid(int index) const {
    return index >= 0 && index < m_list.size();
}
