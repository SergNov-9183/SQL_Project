#ifndef RECORD_H
#define RECORD_H

#include <memory>

#include <QByteArray>
#include <QSqlQuery>
#include <QVariant>

#include "DbConnection.h"

class Record {
public:
    Record(int id, const DbConnection& db);
    virtual ~Record();

    int id() const;

    virtual QString insertQuery();
    virtual QString removeQuery();
    virtual QString updateQuery();

    virtual bool dataChanged(const QList<QVariant>& values) const;
    virtual void update(const std::shared_ptr<QSqlQuery>& query);
    virtual void update(const QList<QVariant>& values);
    virtual QVariant value(int role = Qt::DisplayRole) const;
    virtual QList<QVariant> values() const;

    virtual void print() const;

    static const QString& selectQuery(Table table, const DbConnection& db);
    static Record* get(Table table, DbConnection& db, int id = -1);
    static QHash<int, QByteArray> roleNames(Table table);

protected:
    const DbConnection& m_db;

private:
    int m_id;
};

#endif // RECORD_H
