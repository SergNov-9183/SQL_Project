#ifndef USERMODEL_H
#define USERMODEL_H

#include <QObject>

#include "DbConnection.h"

class UserModel : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString userInfo READ userInfo NOTIFY userChanged)
    Q_PROPERTY(bool isAuthorized READ isAuthorized NOTIFY userChanged)
    Q_PROPERTY(bool isAdmin READ isAdmin NOTIFY userChanged)
    Q_PROPERTY(int userId READ userId NOTIFY userChanged)
    Q_PROPERTY(QString name READ name NOTIFY userChanged)
    Q_PROPERTY(QString phone READ phone NOTIFY userChanged)
    Q_PROPERTY(QString email READ email NOTIFY userChanged)

public:
    explicit UserModel(DbConnection& db, QObject* parent = nullptr);

    Q_INVOKABLE void login(const QString& login, const QString& password);
    Q_INVOKABLE void addUserAndLogin(const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password);
    Q_INVOKABLE void logout();

    int userId() const;

private:
    DbConnection& m_db;
    QString m_userInfo;
    bool m_isAuthorized;
    int m_userId;
    QString m_name;
    QString m_phone;
    QString m_email;

    QString userInfo() const;
    bool isAuthorized() const;
    bool isAdmin() const;
    QString name() const;
    QString phone() const;
    QString email() const;

signals:
    void userChanged();

};

#endif // USERMODEL_H
