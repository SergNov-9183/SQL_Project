#ifndef USERMODEL_H
#define USERMODEL_H

#include <QObject>

#include "DbConnection.h"

class UserModel : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString userInfo READ userInfo NOTIFY userChanged)
    Q_PROPERTY(bool isAuthorized READ isAuthorized NOTIFY userChanged)
    Q_PROPERTY(bool canEdit READ canEdit NOTIFY userChanged)
    Q_PROPERTY(bool isAdmin READ isAdmin NOTIFY userChanged)

public:
    explicit UserModel(DbConnection& db, QObject* parent = nullptr);

    Q_INVOKABLE void login(const QString& login, const QString& password);
    Q_INVOKABLE void addUserAndLogin(const QString& suname, const QString& name, const QString& patronymic, const QString& phone, const QString& email, const QString& password);
    Q_INVOKABLE void logout();

    int userId() const;

private:
    DbConnection& m_db;
    QString m_userInfo;
    bool m_isAuthorized;
    int m_userId;

    QString userInfo() const;
    bool isAuthorized() const;
    bool canEdit() const;
    bool isAdmin() const;

signals:
    void userChanged();

};

#endif // USERMODEL_H
