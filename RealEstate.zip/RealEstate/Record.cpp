#include "Record.h"

#include "Locality.h"
#include "Street.h"
#include "House.h"
#include "Announcement.h"

Record::Record(int id, const DbConnection &db) : m_db(db), m_id(id) {
}

Record::~Record() {

}

int Record::id() const {
    return m_id;
}

QString Record::insertQuery() {
    return QString();
}

QString Record::removeQuery() {
    return QString();
}

QString Record::updateQuery() {
    return QString();
}

bool Record::dataChanged(const QList<QVariant>&) const {
    return false;
}

void Record::update(const std::shared_ptr<QSqlQuery>&) {
}

void Record::update(const QList<QVariant>&) {
}

QVariant Record::value(int) const {
    return QVariant();
}

QList<QVariant> Record::values() const {
    return QList<QVariant>();
}

void Record::print() const {
}

int Record::generateId(DbConnection& db, RecordType recordType) {
    switch (recordType) {
    case RecordType::LocalityRecord:        return Locality::generateId(db);
    case RecordType::StreetRecord:          return Street::generateId(db);
    case RecordType::HouseRecord:           return House::generateId(db);
    case RecordType::AnnouncementRecord:    return Announcement::generateId(db);
    }
    return -1;
}

Record* Record::get(RecordType recordType, int id, const DbConnection& db) {
    switch (recordType) {
    case RecordType::LocalityRecord:        return new Locality(id, db);
    case RecordType::StreetRecord:          return new Street(id, db);
    case RecordType::HouseRecord:           return new House(id, db);
    case RecordType::AnnouncementRecord:    return new Announcement(id, db);


    }
    return nullptr;
}

QHash<int, QByteArray> Record::roleNames(RecordType recordType) {
    switch (recordType) {
    case RecordType::LocalityRecord:        return Locality::roleNames();
    case RecordType::StreetRecord:          return Street::roleNames();
    case RecordType::HouseRecord:           return House::roleNames();
    case RecordType::AnnouncementRecord:    return Announcement::roleNames();
    }
    return QHash<int, QByteArray>();
}
