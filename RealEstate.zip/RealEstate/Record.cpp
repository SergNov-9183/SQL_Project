#include "Record.h"

#include "Definitions.h"
#include "Locality.h"
#include "Street.h"
#include "House.h"
#include "Announcement.h"

Record::Record(int id, const DbConnection& db) : m_db(db), m_id(id) {
}

Record::~Record() {

}

int Record::id() const {
    return m_id;
}

QString Record::insertQuery() {
    return QString();
}

QString Record::removeQuery() {
    return QString();
}

QString Record::updateQuery() {
    return QString();
}

bool Record::dataChanged(const QList<QVariant>&) const {
    return false;
}

void Record::update(const std::shared_ptr<QSqlQuery>&) {
}

void Record::update(const QList<QVariant>&) {
}

QVariant Record::value(int) const {
    return QVariant();
}

QList<QVariant> Record::values() const {
    return QList<QVariant>();
}

void Record::print() const {
}

const QString& Record::selectQuery(Table table, const DbConnection& db) {
    switch (table) {
    case Table::localities:   return db[Query::selectLocalities];
    case Table::streets:      return db[Query::selectStreets];
    case Table::houses:       return db[Query::selectHouses];
    case Table::announcement: return db[Query::selectAnnouncements];
    default:                  return QUERY_NOT_DEFINED;
    }
}

Record* Record::get(Table table, DbConnection& db, int id) {
    if (id > 0 || db.getId(table, id)) {
        switch (table) {
        case Table::localities:   return new Locality(id, db);
        case Table::streets:      return new Street(id, db);
        case Table::houses:       return new House(id, db);
        case Table::announcement: return new Announcement(id, db);
        default:                  return nullptr;
        }
    }
    return nullptr;
}

QHash<int, QByteArray> Record::roleNames(Table table) {
    switch (table) {
    case Table::localities:   return Locality::roleNames();
    case Table::streets:      return Street::roleNames();
    case Table::houses:       return House::roleNames();
    case Table::announcement: return Announcement::roleNames();
    default:                  return QHash<int, QByteArray>();
    }
}
